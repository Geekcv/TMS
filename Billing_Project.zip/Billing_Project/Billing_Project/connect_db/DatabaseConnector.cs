﻿
using System;
using System.IO;
using Newtonsoft.Json.Linq;
using Npgsql;


namespace Billing_Project.connect_db
{
    public class DatabaseConnector
    {
        private static readonly string ConnectionString;
        private static readonly NpgsqlDataSource DataSource;

        static DatabaseConnector()
        {
            try
            {
                // Read the JSON configuration file
                string json = File.ReadAllText("E:\\Dot-net\\WPF\\Project-template\\Billing_Project\\Billing_Project\\connect_db\\appsettings.json");
                JObject config = JObject.Parse(json);
                var dbConfig = config["Database"];

                string host = dbConfig["Host"]?.ToString();
                string port = dbConfig["Port"]?.ToString();
                string user = dbConfig["User"]?.ToString();
                string password = dbConfig["Password"]?.ToString();
                string database = dbConfig["Name"]?.ToString();

                // Log configuration values (for debugging purposes)
                Console.WriteLine($"Host: {host}, Port: {port}, User: {user}, Database: {database}");

                // Create connection string with pooling
                ConnectionString = $"Host={host};Port={port};Username={user};Password={password};Database={database};Pooling=true;MinPoolSize=1;MaxPoolSize=20;";

                // Initialize connection pooling
                DataSource = NpgsqlDataSource.Create(ConnectionString);

                Console.WriteLine("Database connection pooling initialized!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading database config: {ex.Message}");
            }
        }

        // Method to get a pooled connection
        public static NpgsqlConnection GetConnection()
        {
            try
            {
                // Check if DataSource is initialized
                if (DataSource == null)
                {
                    Console.WriteLine("DataSource is null. Please check the configuration.");
                    return null;
                }

                NpgsqlConnection conn = DataSource.OpenConnection();
                Console.WriteLine("Database connection established!");
                return conn;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Database connection failed: {ex.Message}");
                return null;
            }
        }

    }
}
