﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Billing_Project.connect_db
{
    public class DatabaseHelper
    {
        private static readonly string ConnectionString =
            "Host=localhost;Port=5432;Username=postgres;Password=Admin;Database=TestDB;Pooling=true;MinPoolSize=1;MaxPoolSize=20;";

        public static bool CreateTable(string schema, string table, List<Dictionary<string, object>> data)
        {
            try
            {
                using (var conn = new NpgsqlConnection(ConnectionString))
                {
                    conn.Open();

                    // Start building the SQL string
                    var colString = "id SERIAL NOT NULL, row_id TEXT NOT NULL PRIMARY KEY, cr_on TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(), up_on TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(), ";

                    // Get the last key in the data list
                    var lastKey = data[data.Count - 1];

                    // Loop through the data to create column definitions
                    for (var k = 0; k < data.Count; k++)
                    {
                        var colname = data[k]["id"].ToString().Replace(" ", "");
                        var coltype = data[k]["fdtype"].ToString();
                        var colNull = (bool)data[k]["required"] ? "NOT NULL" : "NULL";

                        // Add column to the colString
                        if (data[k]["id"].ToString() != lastKey["id"].ToString())
                        {
                            colString += $"{colname} {coltype} {colNull}, ";
                        }
                        else
                        {
                            colString += $"{colname} {coltype} {colNull} ";
                        }
                    }

                    // Final SQL query string
                    var sqlString = $"CREATE TABLE IF NOT EXISTS {schema}.{table} ({colString})";
                    Console.WriteLine($"SQL: {sqlString}");

                    // Execute the SQL query
                    using (var cmd = new NpgsqlCommand(sqlString, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }

                    Console.WriteLine("Table created successfully.");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating table: {ex.Message}");
                return false;
            }
        }


        public static bool InsertData(string tableName, Dictionary<string, object> columns)
        {
            try
            {
                using (var conn = new NpgsqlConnection(ConnectionString))
                {
                    conn.Open();

                    // Build the column string
                    StringBuilder colString = new StringBuilder("(");
                    StringBuilder valString = new StringBuilder("(");
                    var lastKey = new List<string>(columns.Keys).Last(); // Get the last key in columns

                    foreach (var column in columns)
                    {
                        if (column.Value != null)
                        {
                            colString.Append(column.Key);
                            valString.Append(FormatValue(column.Value));

                            if (column.Key != lastKey)
                            {
                                colString.Append(",");
                                valString.Append(",");
                            }
                        }
                    }
                    colString.Append(")");
                    valString.Append(")");

                    // Construct the SQL query
                    // var sqlString = $"INSERT INTO {schema}.{tableName} {colString} VALUES {valString} ON CONFLICT(row_id) DO NOTHING RETURNING row_id;";
                    var sqlString = $"INSERT INTO {tableName} {colString} VALUES {valString} ON CONFLICT(row_id) DO NOTHING RETURNING row_id;";
                    Console.WriteLine("Generated SQL Query: " + sqlString);

                    // Execute the SQL query
                    using (var cmd = new NpgsqlCommand(sqlString, conn))
                    {
                        var result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            Console.WriteLine($"Inserted row with ID: {result}");
                            return true;
                        }
                        else
                        {
                            Console.WriteLine("Insert failed.");
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inserting data: {ex.Message}");
                return false;
            }
        }


        private static string FormatValue(object value)
        {
            // If the value is an array or list, convert it to a JSON-like format
            if (value is Array || value is List<object>)
            {
                return $"'{Newtonsoft.Json.JsonConvert.SerializeObject(value)}'";
            }
            else
            {
                return $"'{value.ToString().Replace("'", "`")}'";
            }
        }

        public static async Task<int> UpdateData(string tablename, Dictionary<string, object> columns, Dictionary<string, object> cond)
        {
            Console.WriteLine("columns");
            Console.WriteLine(columns);
            Console.WriteLine("cond");
            Console.WriteLine(cond);
            Console.WriteLine("tablename");
            Console.WriteLine(tablename);

            // Validate inputs
            if (columns == null || columns.Count == 0)
                throw new ArgumentException("Columns cannot be empty.");
            if (cond == null || cond.Count == 0)
                throw new ArgumentException("Condition cannot be empty.");

            // Build column set part of the SQL query
            StringBuilder setStringBuilder = new StringBuilder();
            List<NpgsqlParameter> parameters = new List<NpgsqlParameter>();
            int parameterIndex = 1;

            foreach (var column in columns)
            {
                if (column.Value != null)
                {
                    setStringBuilder.Append($"{column.Key} = @param{parameterIndex}, ");
                    parameters.Add(new NpgsqlParameter($"@param{parameterIndex}", column.Value));
                    parameterIndex++;
                }
            }

            // Remove the trailing comma and space
            setStringBuilder.Length -= 2;

            // Build the WHERE condition part of the query
            StringBuilder whereClauseBuilder = new StringBuilder();
            foreach (var condition in cond)
            {
                whereClauseBuilder.Append($"{condition.Key} = @param{parameterIndex} AND ");
                parameters.Add(new NpgsqlParameter($"@param{parameterIndex}", condition.Value));
                parameterIndex++;
            }

            // Remove the trailing "AND " from the WHERE clause
            if (whereClauseBuilder.Length > 0)
                whereClauseBuilder.Length -= 4;

            // Complete SQL string
            string sqlString = $"UPDATE {tablename} SET {setStringBuilder} WHERE {whereClauseBuilder};";
            Console.WriteLine("Generated SQL Query: " + sqlString);

            // Execute the query using Npgsql
            try
            {
                using (var connection = new NpgsqlConnection(ConnectionString))
                {
                    await connection.OpenAsync();
                    using (var cmd = new NpgsqlCommand(sqlString, connection))
                    {
                        // Add parameters to the command
                        cmd.Parameters.AddRange(parameters.ToArray());

                        int rowsAffected = await cmd.ExecuteNonQueryAsync();
                        Console.WriteLine("Rows affected: " + rowsAffected);
                        return rowsAffected;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error executing query: " + ex.Message);
                throw;
            }
        }


        public static async Task<string> FetchDataAsXmlAsync(string tablename, Dictionary<string, object> cond)
        {
            var result = new List<Dictionary<string, object>>();
            var sqlString = $"SELECT * FROM {tablename}";
            var conditions = new List<string>();
            var parameters = new List<NpgsqlParameter>();
            int parameterIndex = 1;

            // Validate conditions
            if (cond != null && cond.Count > 0)
            {
                // Handle OR conditions
                if (cond.ContainsKey("OR"))
                {
                    foreach (var item in (List<Dictionary<string, object>>)cond["OR"])
                    {
                        foreach (var key in item.Keys)
                        {
                            conditions.Add($"{key} = @param{parameterIndex}");
                            parameters.Add(new NpgsqlParameter($"@param{parameterIndex}", item[key]));
                            parameterIndex++;
                        }
                    }
                }

                // Handle AND conditions
                if (cond.ContainsKey("AND"))
                {
                    foreach (var item in (List<Dictionary<string, object>>)cond["AND"])
                    {
                        foreach (var key in item.Keys)
                        {
                            conditions.Add($"{key} = @param{parameterIndex}");
                            parameters.Add(new NpgsqlParameter($"@param{parameterIndex}", item[key]));
                            parameterIndex++;
                        }
                    }
                }

                // Handle ORDER BY clause
                if (cond.ContainsKey("ORDER"))
                {
                    var orderClauses = new List<string>();
                    foreach (var key in ((Dictionary<string, string>)cond["ORDER"]).Keys)
                    {
                        orderClauses.Add($"{key} {((Dictionary<string, string>)cond["ORDER"])[key].ToUpper()}");
                    }
                    if (orderClauses.Count > 0)
                    {
                        sqlString += " ORDER BY " + string.Join(", ", orderClauses);
                    }
                }

                // Handle LIMIT clause
                if (cond.ContainsKey("LIMIT"))
                {
                    sqlString += $" LIMIT {cond["LIMIT"]}";
                }

                // Append conditions to WHERE clause if any
                if (conditions.Count > 0)
                {
                    sqlString += " WHERE " + string.Join(" AND ", conditions);
                }
            }

            Console.WriteLine("Generated SQL Query: " + sqlString);

            // Execute query with parameterized values
            try
            {
                using (var connection = new NpgsqlConnection(ConnectionString))
                {
                    await connection.OpenAsync();
                    using (var cmd = new NpgsqlCommand(sqlString, connection))
                    {
                        // Add parameters to the command
                        cmd.Parameters.AddRange(parameters.ToArray());

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var row = new Dictionary<string, object>();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    row[reader.GetName(i)] = reader.GetValue(i);
                                }
                                result.Add(row);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error executing query: " + ex.Message);
            }

            // Convert result to XML
            return ConvertToXml(result);
        }

        // Convert the List of Dictionaries to XML string
        private static string ConvertToXml(List<Dictionary<string, object>> result)
        {
            var xmlDocument = new XmlDocument();
            XmlElement rootElement = xmlDocument.CreateElement("Results");
            xmlDocument.AppendChild(rootElement);

            foreach (var row in result)
            {
                XmlElement rowElement = xmlDocument.CreateElement("Row");
                rootElement.AppendChild(rowElement);

                foreach (var column in row)
                {
                    XmlElement columnElement = xmlDocument.CreateElement(column.Key);
                    columnElement.InnerText = column.Value.ToString();
                    rowElement.AppendChild(columnElement);
                }
            }

            return xmlDocument.OuterXml;
        }


    }

}
