﻿//using System;
//using System.Windows;
//using Billing_Project.connect_db;
//using Npgsql;

//namespace Billing_Project
//{
//    public partial class MainWindow : Window
//    {
//        public MainWindow()
//        {
//            InitializeComponent();
//        }

//        private void btnConnect_Click(object sender, RoutedEventArgs e)
//        {
//            // Update status text
//            txtConnectionStatus.Text = "Testing connection...";

//            // Test database connection
//            using (NpgsqlConnection conn = DatabaseConnector.GetConnection())
//            {
//                if (conn != null)
//                {
//                    txtConnectionStatus.Text = "Connection Status: Success!";
//                    conn.Close();
//                }
//                else
//                {
//                    txtConnectionStatus.Text = "Connection Status: Failed!";
//                }
//            }
//        }
//    }
//}


using Billing_Project.connect_db;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Xml.Linq;

namespace Billing_Project
{
    public class MyData
    {
        public string Name { get; set; }
        public int Age { get; set; }
        // Add other properties as needed
    }

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //private void btnCreateTable_Click(object sender, RoutedEventArgs e)
        //{
        //    // Define table columns and data (simulating your data input)
        //    var data = new List<Dictionary<string, object>>()
        //    {
        //        new Dictionary<string, object> { { "id", "name" }, { "fdtype", "TEXT" }, { "required", true } },
        //        new Dictionary<string, object> { { "id", "age" }, { "fdtype", "INTEGER" }, { "required", false } },
        //        new Dictionary<string, object> { { "id", "created_on" }, { "fdtype", "TIMESTAMP" }, { "required", true } }
        //    };

        //    // Call CreateTable method
        //    bool isCreated = DatabaseHelper.CreateTable("public", "my_table", data);

        //    // Update UI based on result
        //    txtTableStatus.Text = isCreated ? "Table created successfully!" : "Table creation failed!";
        //}


        //private void btnCreateTable_Click(object sender, RoutedEventArgs e)
        //{
        //    // Simulate columns data
        //    var columns = new Dictionary<string, object>
        //    {
        //        { "row_id", "12346" },
        //        { "name", "John123" },
        //        { "age", 30 },
        //        //{ "created_on", DateTime.Now },
        //        //{ "data_array", new List<int> { 1, 2, 3, 4 } }
        //    };

        //    //var mytable = "public" + ".my_table1";

        //    // Call InsertData method
        //    bool isInserted = DatabaseHelper.InsertData("public.my_table1", columns);

        //    // Update UI based on result
        //    txtTableStatus.Text = isInserted ? "Data inserted successfully!" : "Data insertion failed!";
        //}


        //    private async void btnCreateTable_Click(object sender, RoutedEventArgs e)
        //    {
        //        // Simulate columns data
        //        var columns = new Dictionary<string, object>
        //{
        //    { "name", "ABH1" },
        //    { "age", 30 },
        //    //{ "created_on", DateTime.Now },
        //    //{ "data_array", new List<int> { 1, 2, 3, 4 } }
        //};

        //        var cond = new Dictionary<string, object>
        //{
        //    { "row_id", "12346" }
        //};

        //        // Call UpdateData method asynchronously
        //        int rowsAffected = await DatabaseHelper.UpdateData("public.my_table1", columns, cond);

        //        // Update UI based on result
        //        txtTableStatus.Text = rowsAffected > 0 ? "Data updated successfully!" : "Data update failed!";
        //    }


        private async void btnCreateTable_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Define condition for the query
                var conditions = new Dictionary<string, object>
                {
                    { "AND", new List<Dictionary<string, object>> {
                        new Dictionary<string, object> { { "name", "ABH1" } },
                    }},
                };

                // Fetch data as XML
                string xmlResult = await DatabaseHelper.FetchDataAsXmlAsync("public.my_table1", conditions);

                // Display the XML in the TextBox
                //lblResult.Content = xmlResult;

                var dataList = ParseXmlToDataList(xmlResult);

                // Bind the result to the DataGrid
                dataGridResult.ItemsSource = dataList;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    

    private List<MyData> ParseXmlToDataList(string xml)
        {
            // Use LINQ to XML or other techniques to parse XML into a list of objects
            var dataList = new List<MyData>();

            // Assuming MyData is a class with properties matching the XML structure
            // For simplicity, here is a pseudo code to demonstrate how this could be done
            XDocument xdoc = XDocument.Parse(xml);
            foreach (var item in xdoc.Descendants("row"))
            {
                dataList.Add(new MyData
                {
                    Name = item.Element("name")?.Value,
                    Age = int.Parse(item.Element("age")?.Value ?? "0"),
                    // other properties
                });
            }

            return dataList;
        }
    }


}