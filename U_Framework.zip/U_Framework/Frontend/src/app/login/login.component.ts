import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private Apicontroller: ApicontrollerService,private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(3)]],
    });
  }

  async onSubmit() {
    if (this.loginForm.valid) {
      console.log('Form Submitted', this.loginForm.value);
      const resp = await this.Apicontroller.loginuser(this.loginForm.value);


      // Checking resp
      if (resp.status == '0') {
        localStorage.setItem('token', resp.data.token)
        setTimeout(() => {
          this.router.navigate(['/show-client'])
        }, 3000)
      } 
      
    }

  }
}
