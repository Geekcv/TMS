import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-client-add',
  templateUrl: './client-add.component.html',
  styleUrls: ['./client-add.component.css']
})
export class ClientAddComponent {
  clientForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.clientForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit() {
    if (this.clientForm.valid) {
      console.log(this.clientForm.value);
      // Handle form submission logic here
    }

  }


  onEdit() {
    console.log('Edit button clicked');
    // Logic to handle edit functionality
    // For example, you might want to populate the form with existing client data
    this.clientForm.patchValue({
      name: 'Existing Client Name',
      email: 'existing.client@example.com',
      phone: '1234567890'
    });
  }


}


