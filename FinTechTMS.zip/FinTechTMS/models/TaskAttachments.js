import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";
import Tasks from "./Tasks.js";

const TaskAttachments = sequelize.define("TaskAttachments", {
  attachment_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  task_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Tasks,
      key: "row_id",
    },
    onDelete: "CASCADE",
  },
  file_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  file_path: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  date_uploaded: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
});

export default TaskAttachments;
