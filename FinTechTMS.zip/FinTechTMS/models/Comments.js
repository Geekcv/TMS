import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";
import Users from "./Users.js";
import Tasks from "./Tasks.js";

const Comments = sequelize.define("Comments", {
  comment_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  task_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Tasks,
      key: "row_id",
    },
    onDelete: "CASCADE",
  },
  user_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Users,
      key: "user_id",
    },
    onDelete: "CASCADE",
  },
  comment_text: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  date_created: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
});

export default Comments;
