import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";
import Users from "./Users.js";

const Tasks = sequelize.define("Tasks", {
  row_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Users,
      key: "user_id",
    },
  },
  task_title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  task_description: {
    type: DataTypes.TEXT,
  },
  date_created: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  completion_date: {
    type: DataTypes.DATE,
  },
  completion_status: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  status_updated_by: {
    type: DataTypes.INTEGER,
    references: {
      model: Users,
      key: "user_id",
    },
  },
  priority: {
    type: DataTypes.INTEGER,
  },
});

export default Tasks;
