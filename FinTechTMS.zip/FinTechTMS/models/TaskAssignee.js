import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";
import Tasks from "./Tasks.js";
import Users from "./Users.js";

const TaskAssignee = sequelize.define("Task_Assignee", {
  row_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  task_row_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Tasks,
      key: "row_id",
    },
  },
  assigned_by: {
    type: DataTypes.INTEGER,
    references: {
      model: Users,
      key: "user_id",
    },
  },
  assigned_to: {
    type: DataTypes.INTEGER,
    references: {
      model: Users,
      key: "user_id",
    },
  },
});

export default TaskAssignee;
