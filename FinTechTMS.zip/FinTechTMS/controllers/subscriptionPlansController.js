import SubscriptionPlans from "../models/SubscriptionPlans.js";

// Create a new subscription plan
export const createSubscriptionPlan = async (req, res) => {
  try {
    const {
      activation_plan_id,
      activation_plan_name,
      user_count_allowed,
      price,
    } = req.body;
    const plan = await SubscriptionPlans.create({
      activation_plan_id,
      activation_plan_name,
      user_count_allowed,
      price,
    });
    res.status(201).json(plan);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all subscription plans
export const getSubscriptionPlans = async (req, res) => {
  try {
    const plans = await SubscriptionPlans.findAll();
    res.status(200).json(plans);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a subscription plan by ID
export const getSubscriptionPlanById = async (req, res) => {
  try {
    const { id } = req.params;
    const plan = await SubscriptionPlans.findByPk(id);
    if (plan) {
      res.status(200).json(plan);
    } else {
      res.status(404).json({ error: "Subscription Plan not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a subscription plan
export const updateSubscriptionPlan = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      activation_plan_id,
      activation_plan_name,
      user_count_allowed,
      price,
    } = req.body;
    const plan = await SubscriptionPlans.findByPk(id);
    if (plan) {
      plan.activation_plan_id = activation_plan_id;
      plan.activation_plan_name = activation_plan_name;
      plan.user_count_allowed = user_count_allowed;
      plan.price = price;
      await plan.save();
      res.status(200).json(plan);
    } else {
      res.status(404).json({ error: "Subscription Plan not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a subscription plan
export const deleteSubscriptionPlan = async (req, res) => {
  try {
    const { id } = req.params;
    const plan = await SubscriptionPlans.findByPk(id);
    if (plan) {
      await plan.destroy();
      res
        .status(200)
        .json({ message: "Subscription Plan deleted successfully" });
    } else {
      res.status(404).json({ error: "Subscription Plan not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
