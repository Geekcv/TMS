import User from "../models/Users.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Organisation from "../models/Organisation.js";

export const LoginUser = async (req, res) => {
  const { username, password } = req.body;
  try {
    console.log(req.body);
    const user = await User.findOne({ where: { username } });
    console.log(user);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ error: "Invalid credentials" });
    }

    // if (password == user.password) {
    //   return res.status(400).json({ error: "Invalid credentials" });
    // }
    const payload = {
      user_id: user.user_id,
      role: user.role,
      Organisation: user.organisation_id,
    };
    const token = jwt.sign(payload, "your_jwt_secret", { expiresIn: "1h" });
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ error: "Login failed" });
  }
};
