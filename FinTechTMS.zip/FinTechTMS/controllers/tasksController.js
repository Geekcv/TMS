import Tasks from "../models/Tasks.js";
import Comments from "../models/Comments.js";
import TaskAttachments from "../models/TaskAttachments.js";

// Create a new task
export const createTask = async (req, res) => {
  try {
    const {
      user_id,
      task_title,
      task_description,
      completion_status,
      status_updated_by,
      priority,
    } = req.body;
    const task = await Tasks.create({
      user_id,
      task_title,
      task_description,
      completion_status,
      status_updated_by,
      priority,
    });
    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all tasks
export const getTasks = async (req, res) => {
  try {
    const tasks = await Tasks.findAll();
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a task by ID
export const getTaskById = async (req, res) => {
  try {
    const { id } = req.params;
    const task = await Tasks.findByPk(id);
    if (task) {
      res.status(200).json(task);
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a task
export const updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      task_title,
      task_description,
      completion_status,
      status_updated_by,
      priority,
    } = req.body;
    const task = await Tasks.findByPk(id);
    if (task) {
      task.task_title = task_title;
      task.task_description = task_description;
      task.completion_status = completion_status;
      task.status_updated_by = status_updated_by;
      task.priority = priority;
      await task.save();
      res.status(200).json(task);
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a task
export const deleteTask = async (req, res) => {
  try {
    const { id } = req.params;
    const task = await Tasks.findByPk(id);
    if (task) {
      await task.destroy();
      res.status(200).json({ message: "Task deleted successfully" });
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const uploadAttachment = async (req, res) => {
  const { id } = req.params;

  console.log(req.file); // Log to check if file data is coming through

  try {
    // Check if the task exists
    const task = await Tasks.findByPk(id);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Handle file upload
    const file = req.file;
    if (!file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    // Create attachment entry in the database
    const attachment = await TaskAttachments.create({
      task_id: id,
      file_name: file.originalname,
      file_path: file.path, // File path where the file is saved on the server
    });

    return res
      .status(201)
      .json({ message: "Attachment uploaded successfully", attachment });
  } catch (error) {
    console.error(error); // Log the error for debugging purposes
    return res
      .status(500)
      .json({ message: "Error uploading attachment", error });
  }
};

// Controller to create a comment
export const createComment = async (req, res) => {
  const { taskId } = req.params;
  const { user_id, comment_text } = req.body;

  try {
    // Check if task exists
    const task = await Tasks.findByPk(taskId);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Create comment
    const comment = await Comments.create({
      task_id: taskId,
      user_id,
      comment_text,
    });

    res.status(201).json({ message: "Comment created", comment });
  } catch (error) {
    res.status(500).json({ message: "Error creating comment", error });
  }
};
