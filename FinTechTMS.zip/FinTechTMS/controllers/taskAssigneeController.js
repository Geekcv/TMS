import TaskAssignee from "../models/TaskAssignee.js";

// Assign a user to a task
export const assignTask = async (req, res) => {
  try {
    const { task_row_id, assigned_by, assigned_to } = req.body;
    const taskAssignee = await TaskAssignee.create({
      task_row_id,
      assigned_by,
      assigned_to,
    });
    res.status(201).json(taskAssignee);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all task assignments
export const getTaskAssignees = async (req, res) => {
  try {
    const taskAssignees = await TaskAssignee.findAll();
    res.status(200).json(taskAssignees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a task assignment by ID
export const getTaskAssigneeById = async (req, res) => {
  try {
    const { id } = req.params;
    const taskAssignee = await TaskAssignee.findByPk(id);
    if (taskAssignee) {
      res.status(200).json(taskAssignee);
    } else {
      res.status(404).json({ error: "Task Assignee not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a task assignment
export const updateTaskAssignee = async (req, res) => {
  try {
    const { id } = req.params;
    const { task_row_id, assigned_by, assigned_to } = req.body;
    const taskAssignee = await TaskAssignee.findByPk(id);
    if (taskAssignee) {
      taskAssignee.task_row_id = task_row_id;
      taskAssignee.assigned_by = assigned_by;
      taskAssignee.assigned_to = assigned_to;
      await taskAssignee.save();
      res.status(200).json(taskAssignee);
    } else {
      res.status(404).json({ error: "Task Assignee not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a task assignment
export const deleteTaskAssignee = async (req, res) => {
  try {
    const { id } = req.params;
    const taskAssignee = await TaskAssignee.findByPk(id);
    if (taskAssignee) {
      await taskAssignee.destroy();
      res.status(200).json({ message: "Task Assignee deleted successfully" });
    } else {
      res.status(404).json({ error: "Task Assignee not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
