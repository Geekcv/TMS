import Organisation from "../models/Organisation.js";

// Create a new organisation
export const createOrganisation = async (req, res) => {
  try {
    const {
      organisation_name,
      activation_plan_id,
      activation_status,
      expiry_date,
    } = req.body;
    const organisation = await Organisation.create({
      organisation_name,
      activation_plan_id,
      activation_status,
      expiry_date,
    });
    res.status(201).json(organisation);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all organisations
export const getOrganisations = async (req, res) => {
  try {
    const organisations = await Organisation.findAll();
    res.status(200).json(organisations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get an organisation by ID
export const getOrganisationById = async (req, res) => {
  try {
    const { id } = req.params;
    const organisation = await Organisation.findByPk(id);
    if (organisation) {
      res.status(200).json(organisation);
    } else {
      res.status(404).json({ error: "Organisation not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update an organisation
export const updateOrganisation = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      organisation_name,
      activation_plan_id,
      activation_status,
      expiry_date,
    } = req.body;
    const organisation = await Organisation.findByPk(id);
    if (organisation) {
      organisation.organisation_name = organisation_name;
      organisation.activation_plan_id = activation_plan_id;
      organisation.activation_status = activation_status;
      organisation.expiry_date = expiry_date;
      await organisation.save();
      res.status(200).json(organisation);
    } else {
      res.status(404).json({ error: "Organisation not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete an organisation
export const deleteOrganisation = async (req, res) => {
  try {
    const { id } = req.params;
    const organisation = await Organisation.findByPk(id);
    if (organisation) {
      await organisation.destroy();
      res.status(200).json({ message: "Organisation deleted successfully" });
    } else {
      res.status(404).json({ error: "Organisation not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
