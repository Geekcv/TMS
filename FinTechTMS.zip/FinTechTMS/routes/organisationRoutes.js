import express from "express";
import {
  createOrganisation,
  getOrganisations,
  getOrganisationById,
  updateOrganisation,
  deleteOrganisation,
} from "../controllers/organisationController.js";
import {
  authorizeRoles,
  ensureAuthenticated,
} from "../middlewares/authMiddlewave.js";

const router = express.Router();

router.post("/organisations", createOrganisation);
router.get("/organisations", ensureAuthenticated, getOrganisations);
router.get(
  "/organisations/:id",
  ensureAuthenticated,
  authorizeRoles("super admin", "admin"),
  getOrganisationById
);
router.put("/organisations/:id", updateOrganisation);
router.delete("/organisations/:id", deleteOrganisation);

export default router;
