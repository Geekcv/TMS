import express from "express";
import {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
  createComment,
  uploadAttachment,
} from "../controllers/tasksController.js";
import { ensureAuthenticated } from "../middlewares/authMiddlewave.js";
import multer from "multer"; // For handling file uploads

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const router = express.Router();

router.post("/tasks", createTask);
router.get("/tasks", ensureAuthenticated, getTasks);
router.get("/tasks/:id", getTaskById);
router.put("/tasks/:id", updateTask);
router.delete("/tasks/:id", deleteTask);

router.post("/tasks/:id", createComment);

// Manually define __dirname in ES modules
// const __filename = fileURLToPath(import.meta.url);
// const __dirname = path.dirname(__filename);

// // Ensure the uploads directory exists
// const uploadDir = path.join(__dirname, "uploads");
// if (!fs.existsSync(uploadDir)) {
//   fs.mkdirSync(uploadDir);
// }

// // Multer storage configuration
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, uploadDir); // Use the manually defined uploadDir
//   },
//   filename: function (req, file, cb) {
//     cb(null, Date.now() + "-" + file.originalname); // Ensure unique filenames
//   },
// });

// const upload = multer({ storage }).any(); // Accepts any file field

// router.post("/attachments/:id", upload, uploadAttachment);

const uploadDir = path.join(process.cwd(), "uploads");

// Check if the directory exists; if not, create it
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Set up Multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir); // Use the created directory
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname); // Ensure unique file names
  },
});

// Set up the Multer middleware
const upload = multer({ storage }).single("file"); // For single file upload

// Example route for handling file uploads
router.post("/attachments/:id", upload, uploadAttachment);
export default router;
