import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  type: string = '';
  links: string[] = [];
  credentials: { username: string; password: string }[] = [];
  files: { name: string }[] = [  { name: 'File1.pdf' },
  { name: 'File2.docx' },
  { name: 'File3.xlsx' }
];
  workLogs: string[] = [];

  // Edit States
  editLinks: boolean[] = [];
  editCredentials: boolean[] = [];
  editFiles: boolean[] = [];
  editWorkLogs: boolean[] = [];

  // Links
  addLink() {
    this.links.push('');
    this.editLinks.push(true); // Automatically enable editing for new links
  }

  removeLink(index: number) {
    this.links.splice(index, 1);
    this.editLinks.splice(index, 1);
  }

  toggleEditLink(index: number) {
    this.editLinks[index] = !this.editLinks[index];
  }

  // Credentials
  addCredential() {
    this.credentials.push({ username: '', password: '' });
    this.editCredentials.push(true); // Automatically enable editing for new credentials
  }

  removeCredential(index: number) {
    this.credentials.splice(index, 1);
    this.editCredentials.splice(index, 1);
  }

  toggleEditCredential(index: number) {
    this.editCredentials[index] = !this.editCredentials[index];
  }

  // Files
  downloadFile(file: { name: string }) {
    console.log(`Downloading file: ${file.name}`);
  }

  removeFile(file: { name: string }) {
    const index = this.files.indexOf(file);
    if (index > -1) {
      this.files.splice(index, 1);
      this.editFiles.splice(index, 1);
    }
  }

  toggleEditFile(index: number) {
    this.editFiles[index] = !this.editFiles[index];
  }

  // Work Logs
  addWorkLog() {
    this.workLogs.push('');
    this.editWorkLogs.push(true); // Automatically enable editing for new work logs
  }

  removeWorkLog(index: number) {
    this.workLogs.splice(index, 1);
    this.editWorkLogs.splice(index, 1);
  }

  toggleEditWorkLog(index: number) {
    this.editWorkLogs[index] = !this.editWorkLogs[index];
  }


}
