// import { provideHttpClient } from '@angular/common/http';
// import {
//     APP_INITIALIZER,
//     ApplicationConfig,
//     inject,
//     isDevMode,
//     provideAppInitializer,
// } from '@angular/core';
// import { LuxonDateAdapter } from '@angular/material-luxon-adapter';
// import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
// import { provideAnimations } from '@angular/platform-browser/animations';
// import { provideRouter, withInMemoryScrolling } from '@angular/router';
// import { provideFuse } from '@fuse';
// import { TranslocoService, provideTransloco } from '@jsverse/transloco';
// import { appRoutes } from 'app/app.routes';
// import { provideAuth } from 'app/core/auth/auth.provider';
// import { provideIcons } from 'app/core/icons/icons.provider';
// import { MockApiService } from 'app/mock-api';
// import { firstValueFrom } from 'rxjs';
// import { TranslocoHttpLoader } from './core/transloco/transloco.http-loader';
// import { ApicontrollerService } from './controller/apicontroller.service';
// import { WhatsappStatusCheckService } from './Services/whatsapp-status-check.service';

// //  Factory function to load role & permissions before app starts
// export function loadPermissionsOnInit(
//   apiController: ApicontrollerService,
//   whatsappStatus: WhatsappStatusCheckService
// ) {
//   return () =>
//     apiController.fetchApiRoleAndPermission().then((resp: any) => {
//       whatsappStatus.setRole(resp.data.role);
//     //   whatsappStatus.setPermissions(resp.data.permissions);
//     });
// }

// export const appConfig: ApplicationConfig = {
//     providers: [
//         provideAnimations(),
//         provideHttpClient(),
//         provideRouter(
//             appRoutes,
//             withInMemoryScrolling({ scrollPositionRestoration: 'enabled' })
//         ),
//         WhatsappStatusCheckService,
//     {
//       provide: APP_INITIALIZER,
//       useFactory: loadPermissionsOnInit,
//       deps: [ApicontrollerService, WhatsappStatusCheckService],
//       multi: true,
//     },


//         // Material Date Adapter
//         {
//             provide: DateAdapter,
//             useClass: LuxonDateAdapter,
//         },
//         {
//             provide: MAT_DATE_FORMATS,
//             useValue: {
//                 parse: {
//                     dateInput: 'D',
//                 },
//                 display: {
//                     dateInput: 'DDD',
//                     monthYearLabel: 'LLL yyyy',
//                     dateA11yLabel: 'DD',
//                     monthYearA11yLabel: 'LLLL yyyy',
//                 },
//             },
//         },

//         // Transloco Config
//         provideTransloco({
//             config: {
//                 availableLangs: [
//                     {
//                         id: 'en',
//                         label: 'English',
//                     },
//                     {
//                         id: 'tr',
//                         label: 'Turkish',
//                     },
//                 ],
//                 defaultLang: 'en',
//                 fallbackLang: 'en',
//                 reRenderOnLangChange: true,
//                 prodMode: !isDevMode(),
//             },
//             loader: TranslocoHttpLoader,
//         }),
//         provideAppInitializer(() => {
//             const translocoService = inject(TranslocoService);
//             const defaultLang = translocoService.getDefaultLang();
//             translocoService.setActiveLang(defaultLang);

//             return firstValueFrom(translocoService.load(defaultLang));
//         }),

//         // Fuse
//         provideAuth(),
//         provideIcons(),
//         provideFuse({
//             mockApi: {
//                 delay: 0,
//                 service: MockApiService,
//             },
//             fuse: {
//                 layout: 'classy',
//                 scheme: 'light',
//                 screens: {
//                     sm: '600px',
//                     md: '960px',
//                     lg: '1280px',
//                     xl: '1440px',
//                 },
//                 theme: 'theme-default',
//                 themes: [
//                     {
//                         id: 'theme-default',
//                         name: 'Default',
//                     },
//                     {
//                         id: 'theme-brand',
//                         name: 'Brand',
//                     },
//                     {
//                         id: 'theme-teal',
//                         name: 'Teal',
//                     },
//                     {
//                         id: 'theme-rose',
//                         name: 'Rose',
//                     },
//                     {
//                         id: 'theme-purple',
//                         name: 'Purple',
//                     },
//                     {
//                         id: 'theme-amber',
//                         name: 'Amber',
//                     },
//                 ],
//             },
//         }),
//     ],
// };








//** role and permisstion check error 
// */

// import { provideHttpClient } from '@angular/common/http';
// import {
//     APP_INITIALIZER,
//     ApplicationConfig,
//     inject,
//     isDevMode,
//     provideAppInitializer,
// } from '@angular/core';
// import { LuxonDateAdapter } from '@angular/material-luxon-adapter';
// import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
// import { provideAnimations } from '@angular/platform-browser/animations';
// import { provideRouter, withInMemoryScrolling } from '@angular/router';
// import { provideFuse } from '@fuse';
// import { TranslocoService, provideTransloco } from '@jsverse/transloco';
// import { appRoutes } from 'app/app.routes';
// import { provideAuth } from 'app/core/auth/auth.provider';
// import { provideIcons } from 'app/core/icons/icons.provider';
// import { MockApiService } from 'app/mock-api';
// import { firstValueFrom, of } from 'rxjs';
// import { catchError } from 'rxjs/operators';
// import { TranslocoHttpLoader } from './core/transloco/transloco.http-loader';
// import { ApicontrollerService } from './controller/apicontroller.service';
// import { WhatsappStatusCheckService } from './Services/whatsapp-status-check.service';

// export function loadPermissionsOnInit(
//     apiController: ApicontrollerService,
//     whatsappStatus: WhatsappStatusCheckService
// ) {
//     return () => {
//         //  Check if token exists in localStorage/sessionStorage
//         const token = localStorage.getItem('token');
//         if (!token) {
//             console.warn('No token found → defaulting to guest');
//             whatsappStatus.setRole('guest');
//             // whatsappStatus.setPermissions([]);
//             return Promise.resolve(); // Allow app bootstrap
//         }

//         //  Call backend if token exists
//         return apiController.fetchApiRoleAndPermission()
//             .then((resp: any) => {
//                 whatsappStatus.setRole(resp.data.role);
//                 // whatsappStatus.setPermissions(resp.data.permissions || []);
//             })
//             .catch((err) => {
//                 console.error('Role API failed → fallback guest', err);
//                 whatsappStatus.setRole('guest');
//                 // whatsappStatus.setPermissions([]);
//             });
//     };
// }

// export const appConfig: ApplicationConfig = {
//     providers: [
//         provideAnimations(),
//         provideHttpClient(),
//         provideRouter(
//             appRoutes,
//             withInMemoryScrolling({ scrollPositionRestoration: 'enabled' })
//         ),
//         WhatsappStatusCheckService,
//         {
//             provide: APP_INITIALIZER,
//             useFactory: loadPermissionsOnInit,
//             deps: [ApicontrollerService, WhatsappStatusCheckService],
//             multi: true,
//         },
//         {
//             provide: DateAdapter,
//             useClass: LuxonDateAdapter,
//         },
//         {
//             provide: MAT_DATE_FORMATS,
//             useValue: {
//                 parse: {
//                     dateInput: 'D',
//                 },
//                 display: {
//                     dateInput: 'DDD',
//                     monthYearLabel: 'LLL yyyy',
//                     dateA11yLabel: 'DD',
//                     monthYearA11yLabel: 'LLLL yyyy',
//                 },
//             },
//         },
//         provideTransloco({
//             config: {
//                 availableLangs: [
//                     { id: 'en', label: 'English' },
//                     { id: 'tr', label: 'Turkish' },
//                 ],
//                 defaultLang: 'en',
//                 fallbackLang: 'en',
//                 reRenderOnLangChange: true,
//                 prodMode: !isDevMode(),
//             },
//             loader: TranslocoHttpLoader,
//         }),
//         provideAppInitializer(() => {
//             const translocoService = inject(TranslocoService);
//             const defaultLang = translocoService.getDefaultLang();
//             translocoService.setActiveLang(defaultLang);
//             return firstValueFrom(translocoService.load(defaultLang));
//         }),
//         provideAuth(),
//         provideIcons(),
//         provideFuse({
//             mockApi: {
//                 delay: 0,
//                 service: MockApiService,
//             },
//             fuse: {
//                 layout: 'classy',
//                 scheme: 'light',
//                 screens: { sm: '600px', md: '960px', lg: '1280px', xl: '1440px' },
//                 theme: 'theme-default',
//                 themes: [
//                     { id: 'theme-default', name: 'Default' },
//                     { id: 'theme-brand', name: 'Brand' },
//                     { id: 'theme-teal', name: 'Teal' },
//                     { id: 'theme-rose', name: 'Rose' },
//                     { id: 'theme-purple', name: 'Purple' },
//                     { id: 'theme-amber', name: 'Amber' },
//                 ],
//             },
//         }),
//     ],
// };





import { provideHttpClient } from '@angular/common/http';
import {
    APP_INITIALIZER,
    ApplicationConfig,
    inject,
    isDevMode,
    provideAppInitializer,
} from '@angular/core';
import { LuxonDateAdapter } from '@angular/material-luxon-adapter';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter, withInMemoryScrolling } from '@angular/router';
import { provideFuse } from '@fuse';
import { TranslocoService, provideTransloco } from '@jsverse/transloco';
import { appRoutes } from 'app/app.routes';
import { provideAuth } from 'app/core/auth/auth.provider';
import { provideIcons } from 'app/core/icons/icons.provider';
import { MockApiService } from 'app/mock-api';
import { firstValueFrom } from 'rxjs';
import { TranslocoHttpLoader } from './core/transloco/transloco.http-loader';
import { ApicontrollerService } from './controller/apicontroller.service';
import { WhatsappStatusCheckService } from './Services/whatsapp-status-check.service';

//  Factory function: load role, permissions & WhatsApp status before app starts
export function loadAppDataOnInit(
  apiController: ApicontrollerService,
  whatsappStatus: WhatsappStatusCheckService
) {
  return async () => {
    const token = localStorage.getItem('token');

    // Case 1: No token → default guest
    if (!token) {
      console.warn('No token found → defaulting to guest');
      whatsappStatus.setRole('guest');
    //   whatsappStatus.setPermissions([]);
      whatsappStatus.setwhatsappStatus(false);
      return;
    }

    try {
      // Case 2: Token exists → fetch role & permissions
      const resp = await apiController.fetchApiRoleAndPermission();
      whatsappStatus.setRole(resp.data.role);
    //   whatsappStatus.setPermissions(resp.data.permissions || []);

      // Fetch WhatsApp connection status
      const userData = JSON.parse(localStorage.getItem('userDeatials'));
      console.log("userData---->",userData)
      if (userData?.organization_id) {
        const waResp = await apiController.fetchApiCredentials(userData.organization_id);
        const connected = waResp.data?.[0]?.connected ;
        whatsappStatus.setwhatsappStatus(connected);
        console.log('WhatsApp status on init →', connected);
      } else {
        console.warn('No organization_id found → skipping WhatsApp status');
        whatsappStatus.setwhatsappStatus(false);
      }

    } catch (err) {
      // Case 3: API fails → fallback guest
      console.error('App init failed → fallback guest', err);
      whatsappStatus.setRole('guest');
    //   whatsappStatus.setPermissions([]);
      whatsappStatus.setwhatsappStatus(false);
    }
  };
}

export const appConfig: ApplicationConfig = {
    providers: [
        provideAnimations(),
        provideHttpClient(),
        provideRouter(
            appRoutes,
            withInMemoryScrolling({ scrollPositionRestoration: 'enabled' })
        ),
        WhatsappStatusCheckService,

        {
            provide: APP_INITIALIZER,
            useFactory: loadAppDataOnInit,
            deps: [ApicontrollerService, WhatsappStatusCheckService],
            multi: true,
        },

        // Material Date Adapter
        {
            provide: DateAdapter,
            useClass: LuxonDateAdapter,
        },
        {
            provide: MAT_DATE_FORMATS,
            useValue: {
                parse: {
                    dateInput: 'D',
                },
                display: {
                    dateInput: 'DDD',
                    monthYearLabel: 'LLL yyyy',
                    dateA11yLabel: 'DD',
                    monthYearA11yLabel: 'LLLL yyyy',
                },
            },
        },

        // Transloco Config
        provideTransloco({
            config: {
                availableLangs: [
                    { id: 'en', label: 'English' },
                    { id: 'tr', label: 'Turkish' },
                ],
                defaultLang: 'en',
                fallbackLang: 'en',
                reRenderOnLangChange: true,
                prodMode: !isDevMode(),
            },
            loader: TranslocoHttpLoader,
        }),
        provideAppInitializer(() => {
            const translocoService = inject(TranslocoService);
            const defaultLang = translocoService.getDefaultLang();
            translocoService.setActiveLang(defaultLang);

            return firstValueFrom(translocoService.load(defaultLang));
        }),

        // Fuse
        provideAuth(),
        provideIcons(),
        provideFuse({
            mockApi: {
                delay: 0,
                service: MockApiService,
            },
            fuse: {
                layout: 'classy',
                scheme: 'light',
                screens: {
                    sm: '600px',
                    md: '960px',
                    lg: '1280px',
                    xl: '1440px',
                },
                theme: 'theme-default',
                themes: [
                    { id: 'theme-default', name: 'Default' },
                    { id: 'theme-brand', name: 'Brand' },
                    { id: 'theme-teal', name: 'Teal' },
                    { id: 'theme-rose', name: 'Rose' },
                    { id: 'theme-purple', name: 'Purple' },
                    { id: 'theme-amber', name: 'Amber' },
                ],
            },
        }),
    ],
};

