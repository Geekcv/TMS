export interface User {
    id: string;
    name: string;
    Phone: string;
    avatar?: string;
    status?: string;
}
