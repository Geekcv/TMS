import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-delete-account',
  imports: [  MatIconModule],
  templateUrl: './delete-account.component.html',
})
export class DeleteAccountComponent {

  constructor(
     
        private _matDialog: MatDialog
    ) { 
 
  
    }
  

 deletebtn(){
      
 }

}
