import { Routes } from '@angular/router';
import { ApiManagementComponent } from './api-management.component';

export default [
    {
        path: '',
        component: ApiManagementComponent,
    },
] as Routes;
