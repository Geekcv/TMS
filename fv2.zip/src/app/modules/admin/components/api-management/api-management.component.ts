import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { LucideAngularModule, Plus, Search, Key as KeyIcon, Code, Copy, Eye, EyeOff, Trash2, BarChart3, Clock, Shield, Globe, Terminal, Book, Download } from 'lucide-angular';

interface ApiKeyItem {
  id: string;
  name: string;
  key: string;
  maskedKey: string;
  type: 'live' | 'test' | 'server';
  permissions: string[];
  usageLimit: number;
  usageCount: number;
  lastUsed: string; // ISO
  createdAt: string; // YYYY-MM-DD
  expiresAt: string; // YYYY-MM-DD
  status: 'active' | 'disabled';
}

interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  category: string;
}
@Component({
  selector: 'app-api-management',
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatProgressBarModule,
    LucideAngularModule
  ],
  templateUrl: './api-management.component.html',
  styleUrl: './api-management.component.scss'
})
export class ApiManagementComponent {
  tabIndex = 0;
  searchTerm = '';
  selectedType: 'all' | 'live' | 'test' | 'server' = 'all';
  showCreate = false;
  visible = new Set<string>();

  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconKey = KeyIcon;
  readonly IconCode = Code;
  readonly IconCopy = Copy;
  readonly IconEye = Eye;
  readonly IconEyeOff = EyeOff;
  readonly IconTrash = Trash2;
  readonly IconBarChart = BarChart3;
  readonly IconClock = Clock;
  readonly IconShield = Shield;
  readonly IconGlobe = Globe;
  readonly IconTerminal = Terminal;
  readonly IconBook = Book;
  readonly IconDownload = Download;

  apiKeys: ApiKeyItem[] = [
    {
      id: '1',
      name: 'Production API Key',
      key: 'whatsapp_live_pk_1234567890abcdef',
      maskedKey: 'whatsapp_live_pk_****...cdef',
      type: 'live',
      permissions: ['messages.send', 'messages.read', 'webhooks.manage'],
      usageLimit: 10000,
      usageCount: 7500,
      lastUsed: '2024-01-15T10:30:00Z',
      createdAt: '2024-01-01',
      expiresAt: '2024-12-31',
      status: 'active'
    },
    {
      id: '2',
      name: 'Development API Key',
      key: 'whatsapp_test_pk_abcdef1234567890',
      maskedKey: 'whatsapp_test_pk_****...7890',
      type: 'test',
      permissions: ['messages.send', 'messages.read'],
      usageLimit: 1000,
      usageCount: 250,
      lastUsed: '2024-01-15T08:45:00Z',
      createdAt: '2024-01-10',
      expiresAt: '2024-06-30',
      status: 'active'
    },
    {
      id: '3',
      name: 'Webhook Integration',
      key: 'whatsapp_live_sk_fedcba0987654321',
      maskedKey: 'whatsapp_live_sk_****...4321',
      type: 'server',
      permissions: ['webhooks.read', 'webhooks.write'],
      usageLimit: 50000,
      usageCount: 12450,
      lastUsed: '2024-01-15T11:20:00Z',
      createdAt: '2023-12-15',
      expiresAt: '2024-12-15',
      status: 'active'
    }
  ];

  apiEndpoints: ApiEndpoint[] = [
    { method: 'POST', path: '/v1/messages', description: 'Send a message to a WhatsApp user', category: 'Messages' },
    { method: 'GET', path: '/v1/messages', description: 'Retrieve message history', category: 'Messages' },
    { method: 'POST', path: '/v1/media', description: 'Upload media files', category: 'Media' },
    { method: 'GET', path: '/v1/media/{media-id}', description: 'Download media files', category: 'Media' },
    { method: 'POST', path: '/v1/webhooks', description: 'Create webhook endpoint', category: 'Webhooks' },
    { method: 'GET', path: '/v1/business/profile', description: 'Get business profile information', category: 'Business' }
  ];

  permissions = [
    { id: 'messages.send', label: 'Send Messages', description: 'Send messages to users', _checked: false },
    { id: 'messages.read', label: 'Read Messages', description: 'Access message history', _checked: false },
    { id: 'media.upload', label: 'Upload Media', description: 'Upload images, videos, documents', _checked: false },
    { id: 'media.download', label: 'Download Media', description: 'Download media files', _checked: false },
    { id: 'webhooks.manage', label: 'Manage Webhooks', description: 'Create and manage webhooks', _checked: false },
    { id: 'webhooks.read', label: 'Read Webhooks', description: 'View webhook configurations', _checked: false },
    { id: 'webhooks.write', label: 'Write Webhooks', description: 'Create webhook endpoints', _checked: false },
    { id: 'business.read', label: 'Read Business Profile', description: 'Access business information', _checked: false },
    { id: 'business.write', label: 'Update Business Profile', description: 'Modify business information', _checked: false },
  ];

  newKey = {
    name: '',
    type: 'live' as 'live' | 'test' | 'server',
    usageLimit: 10000,
    expiresAt: '',
    autoRotate: false
  };

  get filteredKeys(): ApiKeyItem[] {
    return this.apiKeys.filter(k => {
      const matchesSearch = (k.name + ' ' + k.key).toLowerCase().includes(this.searchTerm.toLowerCase());
      const matchesType = this.selectedType === 'all' || k.type === this.selectedType;
      return matchesSearch && matchesType;
    });
  }

  get groupedEndpoints() {
    const map = new Map<string, ApiEndpoint[]>();
    for (const e of this.apiEndpoints) {
      const list = map.get(e.category) || [];
      list.push(e);
      map.set(e.category, list);
    }
    return Array.from(map.entries()).map(([category, endpoints]) => ({ category, endpoints }));
  }

  get stats() {
    const totalKeys = this.apiKeys.length;
    const activeKeys = this.apiKeys.filter(k => k.status === 'active').length;
    const totalUsage = this.apiKeys.reduce((sum, k) => sum + k.usageCount, 0);
    const avgUsage = Math.round(this.apiKeys.reduce((sum, k) => sum + (k.usageCount / k.usageLimit) * 100, 0) / Math.max(totalKeys, 1));
    return { totalKeys, activeKeys, totalUsage, avgUsage };
  }

  usagePct(k: ApiKeyItem) {
    return Math.round((k.usageCount / k.usageLimit) * 100);
  }

  isVisible(id: string) { return this.visible.has(id); }
  toggleKey(id: string) { this.visible.has(id) ? this.visible.delete(id) : this.visible.add(id); }
  copy(text: string) { if (navigator.clipboard) navigator.clipboard.writeText(text); }

  toggleCreate() { this.showCreate = !this.showCreate; }
  cancelCreate() { this.showCreate = false; }
  createKey() {
    const perms = this.permissions.filter(p => p._checked).map(p => p.id);
    const id = (this.apiKeys.length + 1).toString();
    const key = `${this.newKey.type === 'live' ? 'whatsapp_live' : 'whatsapp_test'}_${Math.random().toString(36).slice(2, 10)}_${Date.now().toString(36)}`;
    const maskedKey = key.replace(/(.{10}).+(.{4})/, '$1****...$2');
    const item: ApiKeyItem = {
      id,
      name: this.newKey.name || 'New API Key',
      key,
      maskedKey,
      type: this.newKey.type,
      permissions: perms.length ? perms : ['messages.send'],
      usageLimit: this.newKey.usageLimit || 1000,
      usageCount: 0,
      lastUsed: new Date().toISOString(),
      createdAt: new Date().toISOString().slice(0,10),
      expiresAt: this.newKey.expiresAt || '—',
      status: 'active'
    };
    this.apiKeys = [item, ...this.apiKeys];
    this.showCreate = false;
    // reset
    this.newKey = { name: '', type: 'live', usageLimit: 10000, expiresAt: '', autoRotate: false };
    this.permissions.forEach(p => p._checked = false);
  }
}