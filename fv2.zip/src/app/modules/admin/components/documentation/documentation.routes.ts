import { Routes } from '@angular/router';
import { DocumentationComponent } from './documentation.component';

export default [
    {
        path: '',
        component: DocumentationComponent,
    },
] as Routes;
