import { Routes } from '@angular/router';
import { BroadcastsComponent } from './broadcasts.component';

export default [
    {
        path: '',
        component: BroadcastsComponent,
    },
] as Routes;
