import { Routes } from '@angular/router';
import { MediaLibraryComponent } from 'app/modules/admin/components/media-library/media-library.component';

export default [
    {
        path: '',
        component: MediaLibraryComponent,
    },
] as Routes;
