import { Component, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { LucideAngularModule, Plus, Search, Bot, Play, Pause, Settings as Cog, Edit, Trash2, MessageSquare, Users, Zap, Brain, Activity, Clock } from 'lucide-angular';

type BotStatus = 'active' | 'paused' | 'draft';
type BotType = 'rule-based' | 'ai-powered' | 'hybrid';

interface Chatbot {
  id: string;
  name: string;
  description: string;
  status: BotStatus;
  type: BotType;
  totalConversations: number;
  successfulResolutions: number;
  averageResponseTime: string; // e.g., '0.5s'
  lastUpdated: string; // yyyy-mm-dd
  triggers: string[];
  confidence: number; // 0-100
}

@Component({
  selector: 'app-chatbot',
  imports: [
     CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDialogModule,
    MatChipsModule,
    LucideAngularModule
  ],
  templateUrl: './chatbot.component.html',
  styleUrl: './chatbot.component.scss'
})
export class ChatbotsComponent {
  // Icons
  readonly IconPlus = Plus; readonly IconSearch = Search; readonly IconBot = Bot; readonly IconPlay = Play; readonly IconPause = Pause;
  readonly IconCog = Cog; readonly IconEdit = Edit; readonly IconTrash2 = Trash2; readonly IconMessageSquare = MessageSquare; readonly IconUsers = Users;
  readonly IconZap = Zap; readonly IconBrain = Brain; readonly IconActivity = Activity; readonly IconClock = Clock;

  @ViewChild('createDialog') createDialogTpl!: TemplateRef<unknown>;

  searchTerm = '';
  selectedType: 'all' | BotType = 'all';
  selectedStatus: 'all' | BotStatus = 'all';

  newBot: { name: string; description: string; type: BotType; triggersCsv: string; active: boolean } = {
    name: '', description: '', type: 'rule-based', triggersCsv: '', active: true
  };

  botTypes: { value: BotType; label: string }[] = [
    { value: 'rule-based', label: 'Rule-Based' },
    { value: 'ai-powered', label: 'AI-Powered' },
    { value: 'hybrid', label: 'Hybrid' }
  ];

  bots: Chatbot[] = [
    { id: '1', name: 'Customer Support Bot', description: 'Handles common customer inquiries and support requests', status: 'active', type: 'rule-based', totalConversations: 3420, successfulResolutions: 2890, averageResponseTime: '0.5s', lastUpdated: '2024-01-15', triggers: ['support', 'help', 'issue', 'problem'], confidence: 92 },
    { id: '2', name: 'Order Assistant', description: 'Helps customers track orders and manage returns', status: 'active', type: 'ai-powered', totalConversations: 2150, successfulResolutions: 1950, averageResponseTime: '1.2s', lastUpdated: '2024-01-14', triggers: ['order', 'track', 'return', 'refund'], confidence: 88 },
    { id: '3', name: 'Product Recommendation Bot', description: 'Provides personalized product recommendations', status: 'draft', type: 'ai-powered', totalConversations: 0, successfulResolutions: 0, averageResponseTime: '0s', lastUpdated: '2024-01-13', triggers: ['recommend', 'suggest', 'product', 'buy'], confidence: 0 },
    { id: '4', name: 'FAQ Bot', description: 'Answers frequently asked questions automatically', status: 'paused', type: 'rule-based', totalConversations: 1680, successfulResolutions: 1580, averageResponseTime: '0.3s', lastUpdated: '2024-01-12', triggers: ['faq', 'question', 'info', 'about'], confidence: 95 }
  ];

  get stats() {
    const totalConversations = this.bots.reduce((s, b) => s + b.totalConversations, 0);
    const withConvos = this.bots.filter(b => b.totalConversations > 0);
    const avgSuccessRate = Math.round(
      (withConvos.reduce((s, b) => s + Math.round((b.successfulResolutions / b.totalConversations) * 100), 0)) / (withConvos.length || 1)
    );
    return {
      totalBots: this.bots.length,
      activeBots: this.bots.filter(b => b.status === 'active').length,
      totalConversations,
      avgSuccessRate
    };
  }

  get filteredBots(): Chatbot[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.bots.filter(b => {
      const matchesSearch = !term || b.name.toLowerCase().includes(term) || b.description.toLowerCase().includes(term);
      const matchesType = this.selectedType === 'all' || b.type === this.selectedType;
      const matchesStatus = this.selectedStatus === 'all' || b.status === this.selectedStatus;
      return matchesSearch && matchesType && matchesStatus;
    });
  }

  successRate(b: Chatbot): number {
    return b.totalConversations > 0 ? Math.round((b.successfulResolutions / b.totalConversations) * 100) : 0;
  }

  typeLabel(t: BotType): string { return this.botTypes.find(x => x.value === t)?.label ?? t; }
  typeClass(t: BotType): string { return `type ${t}`; }
  statusClass(s: BotStatus): string { return `badge ${s}`; }
  typeIcon(t: BotType) { return t === 'rule-based' ? this.IconCog : t === 'ai-powered' ? this.IconBrain : this.IconZap; }
  statusIcon(s: BotStatus) { return s === 'active' ? this.IconPlay : s === 'paused' ? this.IconPause : this.IconClock; }
  statusIconClass(s: BotStatus) { return s === 'active' ? 'text-green' : s === 'paused' ? 'text-yellow' : 'text-gray'; }

  openCreateDialog(tpl: TemplateRef<unknown>) { this.dialog.open(tpl, { width: '560px' }); }

  createBot() {
    const name = this.newBot.name.trim();
    if (!name) return;
    const triggers = this.newBot.triggersCsv.split(',').map(s => s.trim()).filter(Boolean);
    const id = (Math.max(0, ...this.bots.map(b => Number(b.id))) + 1).toString();
    const bot: Chatbot = {
      id,
      name,
      description: this.newBot.description.trim(),
      type: this.newBot.type,
      status: this.newBot.active ? 'active' : 'draft',
      totalConversations: 0,
      successfulResolutions: 0,
      averageResponseTime: '0s',
      lastUpdated: new Date().toISOString().slice(0, 10),
      triggers,
      confidence: 0
    };
    this.bots = [bot, ...this.bots];
    this.newBot = { name: '', description: '', type: 'rule-based', triggersCsv: '', active: true };
    this.dialog.closeAll();
  }

  constructor(private dialog: MatDialog) {}
}