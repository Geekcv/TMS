import { Routes } from '@angular/router';
import { WebhookDebuggerComponent } from './webhook-debugger.component';

export default [
    {
        path: '',
        component: WebhookDebuggerComponent,
    },
] as Routes;
