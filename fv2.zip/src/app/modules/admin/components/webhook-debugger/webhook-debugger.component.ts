import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { LucideAngularModule, Play, Bug, Code, CheckCircle, XCircle, Clock, RefreshCw, Terminal, Copy, Download } from 'lucide-angular';

interface WebhookLog {
  time: string;
  url: string;
  status: number;
  event: string;
}
@Component({
  selector: 'app-webhook-debugger',
  imports: [
     CommonModule,
    FormsModule,
    MatCardModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    LucideAngularModule
  ],
  templateUrl: './webhook-debugger.component.html',
  styleUrl: './webhook-debugger.component.scss'
})
export class WebhookDebuggerComponent {
  // Icons
  readonly IconPlay = Play;
  readonly IconBug = Bug;
  readonly IconCode = Code;
  readonly IconCheck = CheckCircle;
  readonly IconX = XCircle;
  readonly IconClock = Clock;
  readonly IconRefresh = RefreshCw;
  readonly IconTerm = Terminal;
  readonly IconCopy = Copy;
  readonly IconDownload = Download;

  testUrl = '';
  eventType = 'message_received';
  testPayload = JSON.stringify({
    object: 'whatsapp_business_account',
    entry: [{
      id: 'PHONE_NUMBER_ID',
      changes: [{
        value: {
          messaging_product: 'whatsapp',
          metadata: {
            display_phone_number: '15550123456',
            phone_number_id: 'PHONE_NUMBER_ID'
          },
          messages: [{
            from: '15551234567',
            id: 'wamid.XXX',
            timestamp: '1234567890',
            text: { body: 'Hello World!' },
            type: 'text'
          }]
        },
        field: 'messages'
      }]
    }]
  }, null, 2);

  responseStatus = 200;
  responseTime = 145;
  responseHeaders = [
    'Content-Type: application/json',
    'X-Response-Time: 145ms',
    'Server: nginx/1.18.0'
  ];
  responseBody = '{\n  "status": "success",\n  "message": "Webhook received",\n  "timestamp": "2024-01-15T10:30:00Z"\n}';

  logs: WebhookLog[] = [
    { time: '10:30:15', url: 'https://api.company.com/webhook', status: 200, event: 'message.received' },
    { time: '10:29:42', url: 'https://api.company.com/webhook', status: 500, event: 'message.status' },
    { time: '10:28:33', url: 'https://api.company.com/webhook', status: 200, event: 'button.clicked' }
  ];

  sendTest() {
    const start = performance.now();
    // Simulate request latency
    const duration = Math.floor(80 + Math.random() * 220);
    this.responseTime = duration;
    this.responseStatus = 200;
    this.responseHeaders = [
      'Content-Type: application/json',
      `X-Response-Time: ${duration}ms`,
      'Server: nginx/1.18.0'
    ];
    this.responseBody = JSON.stringify({ status: 'success', message: 'Webhook received', timestamp: new Date().toISOString() }, null, 2);

    // Push a log entry
    const now = new Date();
    const time = now.toTimeString().slice(0, 8);
    this.logs = [{ time, url: this.testUrl || 'https://your-app.com/webhook', status: this.responseStatus, event: this.eventType.replace('_', '.') }, ...this.logs];
  }
}