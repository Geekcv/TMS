import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { LucideAngularModule, Phone, Video, PhoneCall, Clock, Users, BarChart3, Settings, Code, AlertTriangle } from 'lucide-angular';

@Component({
  selector: 'app-calling-api',
  imports: [
        CommonModule, MatCardModule, MatTabsModule, MatChipsModule, LucideAngularModule

  ],
  templateUrl: './calling-api.component.html',
  styleUrl: './calling-api.component.scss'
})
export class CallingApiComponent {
  // Icons
  readonly IconPhone = Phone;
  readonly IconVideo = Video;
  readonly IconPhoneCall = PhoneCall;
  readonly IconClock = Clock;
  readonly IconUsers = Users;
  readonly IconChart = BarChart3;
  readonly IconSettings = Settings;
  readonly IconCode = Code;
  readonly IconAlert = AlertTriangle;

  // Code samples rendered safely as plain text
  readonly authHeaders = 'Authorization: Bearer YOUR_API_TOKEN\nContent-Type: application/json';

  readonly voicePayload = `{
  "to": "+1234567890",
  "from": "+1987654321",
  "callback_url": "https://your-app.com/webhook"
}`;

  readonly videoPayload = `{
  "to": "+1234567890",
  "from": "+1987654321",
  "video_enabled": true,
  "callback_url": "https://your-app.com/webhook"
}`;

  readonly jsExample = `const whatsapp = require('@whatsapp/calling-api');

const client = new whatsapp.CallClient({
  apiKey: 'YOUR_API_KEY'
});

// Initiate voice call
const call = await client.calls.create({
  to: '+1234567890',
  from: '+1987654321',
  type: 'voice'
});

console.log('Call ID:', call.id);`;

  readonly pyExample = `from whatsapp_calling import CallClient

client = CallClient(api_key='YOUR_API_KEY')

# Initiate video call
call = client.calls.create(
    to='+1234567890',
    from_='+1987654321',
    type='video',
    video_enabled=True
)

print(f"Call ID: {call.id}")`;

  readonly curlExample = `curl -X POST https://api.whatsapp.com/v1/calls/voice \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "to": "+1234567890",
    "from": "+1987654321",
    "callback_url": "https://your-app.com/webhook"
  }'`;
}
