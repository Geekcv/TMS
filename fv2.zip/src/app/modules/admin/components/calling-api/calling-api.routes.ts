import { Routes } from '@angular/router';
import { CallingApiComponent } from './calling-api.component';

export default [
    {
        path: '',
        component: CallingApiComponent,
    },
] as Routes;
