import { Component, Input, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LucideAngularModule, FileDown, Plus, Search, Phone, Mail, MoreHorizontal, Upload, FileText, MessageSquare, CheckCircle, Clock, XCircle, AlertCircle, Eye, Copy, Download } from 'lucide-angular';
import { User } from './user.model';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { WhatsappStatusCheckService } from 'app/Services/whatsapp-status-check.service';
import * as XLSX from 'xlsx';

type ContactStatus = 'Active' | 'Inactive';

interface Contact {
  row_id: string;
  first_name: string;
  last_name: string;
  phone_no: string;
  email?: string;
  tag: any;
  status: any;
  // lastMessage: string; // ISO date
}

@Component({
  selector: 'app-contacts',
  imports: [
     CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatTabsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatChipsModule,
    MatDialogModule,
    LucideAngularModule
  ],
  templateUrl: './contacts.component.html',
  styleUrl: './contacts.component.scss'
})


export class ContactsComponent {
  @Input() user: User | null = null;

  @ViewChild('addContactDialog') addContactDialogTpl!: TemplateRef<unknown>;

  selectedTabIndex = 0;
  searchTerm = '';
  filterStatus: 'all' | 1 | 0 = 'all';
  filterTag: 'all' | 1 | 2 | 3 | 4 = 'all';
  displayedColumns = ['name', 'phone', 'email', 'tags', 'status', 'actions'];
  selectedFileName: string | null = null;

  addContactForm!: FormGroup;
  userdata:any;
  organization_id:any
  role:any;

  // contacts: Contact[] = [
  //   { id: 1, firstName: 'John', lastName: 'Doe', phone: '+1234567890', email: 'john.doe@email.com', tags: ['Customer', 'VIP'], status: 'Active', lastMessage: '2024-06-15' },
  //   { id: 2, firstName: 'Jane', lastName: 'Smith', phone: '+1234567891', email: 'jane.smith@email.com', tags: ['Prospect'], status: 'Active', lastMessage: '2024-06-14' },
  //   { id: 3, firstName: 'Bob', lastName: 'Johnson', phone: '+1234567892', email: 'bob.johnson@email.com', tags: ['Customer'], status: 'Inactive', lastMessage: '2024-06-10' },
  //   { id: 4, firstName: 'Alice', lastName: 'Williams', phone: '+1234567893', email: 'alice.williams@email.com', tags: ['Lead', 'High Priority'], status: 'Active', lastMessage: '2024-06-13' }
  // ];

  contacts : Contact[] = []
    contactsToUpload: any[] = [];


  constructor(private fb: FormBuilder, private dialog: MatDialog,
    private Apicontroller: ApicontrollerService,private _whatsappStatus:WhatsappStatusCheckService
  ) {
    this.addContactForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', Validators.required],
      tag: ['', Validators.required],
      status: ['', Validators.required],

    });

        this.userdata = JSON.parse(localStorage.getItem("userDeatials"));
    this.organization_id = this.userdata.organization_id;

    this.role = _whatsappStatus.getRole()
    this.fetchUserContacts()



  }

  // Icons for template
  readonly IconFileDown = FileDown;
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconPhone = Phone;
  readonly IconMail = Mail;
  readonly IconMore = MoreHorizontal;
  readonly IconUpload = Upload;

    readonly icons = {
    plus: Plus,
    file: FileText,
    message: MessageSquare,
    approved: CheckCircle,
    pending: Clock,
    rejected: XCircle,
    draft: AlertCircle,
    search: Search,
    eye: Eye,
    copy: Copy,
    download: Download // Download sample file icon

  };

  // Computed stats to avoid complex template expressions
  get activeCount(): number {
    return this.contacts.filter(c => c.status === 1).length;
  }
  
  get InactiveCount(): number {
    return this.contacts.filter(c => c.status === 0).length;
  }
  get customersCount(): number {
    return this.contacts.filter(c => c.tag === 1).length;
  }
  get leadsCount(): number {
    return this.contacts.filter(c => c.tag === 2).length;
  }
   get ProspectCount(): number {
    return this.contacts.filter(c => c.tag === 3).length;
  }

   get VIPCount(): number {
    return this.contacts.filter(c => c.tag === 4).length;
  }

  get filteredContacts(): Contact[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.contacts.filter(c => {
      const matchesTerm = !term ||
        c.first_name.toLowerCase().includes(term) ||
        c.last_name.toLowerCase().includes(term) ||
        c.phone_no.includes(this.searchTerm) ||
        (c.email?.toLowerCase().includes(term));

      const matchesStatus = this.filterStatus === 'all' ||
        (this.filterStatus == 1 && c.status == 1) ||
        (this.filterStatus == 0 && c.status == 0);

      const matchesTag = this.filterTag === 'all' || c.tag == this.filterTag;

      return matchesTerm && matchesStatus && matchesTag;
    });
  }

  openAddDialog(template: TemplateRef<unknown>) {
    this.dialog.open(template, { width: '560px' });
  }

 async handleAddContact() {
    if (this.addContactForm.invalid) return;
    const value = this.addContactForm.value;
    console.log("value---",value)

    const organization_id = this.organization_id


    const resp = await this.Apicontroller.createContact({...value,organization_id});

    console.log("resp---",resp)


    this.addContactForm.reset();
    this.dialog.closeAll();
        this.fetchUserContacts()
  }

 async handleFileUpload(e: any) {
    


    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];

    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e: any) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });

      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      console.log("Parsed Contacts:", jsonData);
      this.contactsToUpload = jsonData; // Store for bulk upload
      this.uploadfile()
    };
    reader.readAsArrayBuffer(file);



  }

  onExport() {
    // Placeholder export: In a real app, trigger backend CSV generation
    console.log('Export contacts clicked',this.contacts);
  }


  async fetchUserContacts(){

        const resp = await this.Apicontroller.fetchUsersContacts(this.organization_id);
        this.contacts = resp.data

        console.log("my users data this.contacts ---->",this.filteredContacts)


  }

 async uploadfile(){

  const resp = await this.Apicontroller.bulkUserImport(this.contactsToUpload)

  console.log("bulk user import--->",resp)

  }
}