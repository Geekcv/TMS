export interface User {
  id: string;
  email: string;
  organizationName: string;
  role: string;
}