import { Routes } from '@angular/router';
import { CatalogComponent } from './catalog.component';

export default [
    {
        path: '',
        component: CatalogComponent,
    },
] as Routes;
