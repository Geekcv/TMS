import { Routes } from '@angular/router';
import { WalletComponent } from 'app/modules/admin/components/wallet/wallet.component';

export default [
    {
        path: '',
        component: WalletComponent,
    },
] as Routes;
