import { CommonModule } from '@angular/common';
import { Component, computed, signal } from '@angular/core';
import { LucideAngularModule, TrendingUp, TrendingDown, Send, Eye, MousePointer, Download, RefreshCw, Calendar } from 'lucide-angular';

interface OverviewStat {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: any;
  color: string;
}

interface ChartDatapoint {
  date: string;
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
}

interface CampaignPerformance {
  name: string;
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
  conversionRate: number;
}

interface DeviceBreakdownItem {
  name: string;
  value: number;
  color: string;
}

interface TimeAnalysisItem {
  hour: string;
  messages: number;
  engagement: number;
}

@Component({
  selector: 'app-analytics',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.css']
})
export class AnalyticsComponent {
  readonly dateRange = signal<'7d' | '30d' | '90d' | '1y'>('7d');
  readonly selectedMetric = signal<'messages' | 'engagement' | 'conversion'>('messages');
  readonly activeTab = signal<'campaigns' | 'timing' | 'engagement'>('campaigns');

  readonly overviewStats: OverviewStat[] = [
    {
      title: 'Messages Sent',
      value: '45,678',
      change: '+12.5%',
      trend: 'up',
      icon: Send,
      color: 'icon-blue'
    },
    {
      title: 'Delivery Rate',
      value: '96.8%',
      change: '+2.1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'icon-success'
    },
    {
      title: 'Open Rate',
      value: '74.2%',
      change: '-1.3%',
      trend: 'down',
      icon: Eye,
      color: 'icon-purple'
    },
    {
      title: 'Click Rate',
      value: '18.7%',
      change: '+3.2%',
      trend: 'up',
      icon: MousePointer,
      color: 'icon-warning'
    }
  ];

  readonly chartData: ChartDatapoint[] = [
    { date: '2024-06-01', sent: 1200, delivered: 1156, opened: 890, clicked: 234 },
    { date: '2024-06-02', sent: 1350, delivered: 1298, opened: 967, clicked: 278 },
    { date: '2024-06-03', sent: 1100, delivered: 1067, opened: 812, clicked: 189 },
    { date: '2024-06-04', sent: 1450, delivered: 1398, opened: 1087, clicked: 312 },
    { date: '2024-06-05', sent: 1600, delivered: 1552, opened: 1203, clicked: 356 },
    { date: '2024-06-06', sent: 1250, delivered: 1213, opened: 934, clicked: 267 },
    { date: '2024-06-07', sent: 1380, delivered: 1334, opened: 1024, clicked: 289 }
  ];

  readonly campaignPerformance: CampaignPerformance[] = [
    { name: 'Summer Sale 2024', sent: 3500, delivered: 3456, opened: 2890, clicked: 867, conversionRate: 24.8 },
    { name: 'Product Launch', sent: 2200, delivered: 2167, opened: 1734, clicked: 542, conversionRate: 24.6 },
    { name: 'Newsletter June', sent: 1800, delivered: 1776, opened: 1312, clicked: 298, conversionRate: 16.6 },
    { name: 'Welcome Series', sent: 1200, delivered: 1189, opened: 945, clicked: 267, conversionRate: 22.3 }
  ];

  readonly deviceBreakdown: DeviceBreakdownItem[] = [
    { name: 'Mobile', value: 78, color: '#8884d8' },
    { name: 'Desktop', value: 18, color: '#82ca9d' },
    { name: 'Tablet', value: 4, color: '#ffc658' }
  ];

  readonly timeAnalysis: TimeAnalysisItem[] = [
    { hour: '08:00', messages: 450, engagement: 0.68 },
    { hour: '09:00', messages: 720, engagement: 0.72 },
    { hour: '10:00', messages: 890, engagement: 0.78 },
    { hour: '11:00', messages: 1200, engagement: 0.81 },
    { hour: '12:00', messages: 1450, engagement: 0.75 },
    { hour: '13:00', messages: 1350, engagement: 0.69 },
    { hour: '14:00', messages: 1600, engagement: 0.83 },
    { hour: '15:00', messages: 1400, engagement: 0.79 },
    { hour: '16:00', messages: 1200, engagement: 0.74 },
    { hour: '17:00', messages: 980, engagement: 0.71 },
    { hour: '18:00', messages: 750, engagement: 0.66 },
    { hour: '19:00', messages: 520, engagement: 0.62 }
  ];

  readonly totalMessages = computed(() => this.chartData.reduce((sum, item) => sum + item.sent, 0));

  formatDate(value: string): string {
    return new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  setDateRange(range: '7d' | '30d' | '90d' | '1y') {
    this.dateRange.set(range);
  }

  setMetric(metric: 'messages' | 'engagement' | 'conversion') {
    this.selectedMetric.set(metric);
  }

  setActiveTab(tab: 'campaigns' | 'timing' | 'engagement') {
    this.activeTab.set(tab);
  }

  getTrendIcon(trend: 'up' | 'down') {
    return trend === 'up' ? TrendingUp : TrendingDown;
  }

  getCumulativeValue(index: number): number {
    return this.deviceBreakdown.slice(0, index).reduce((sum, item) => sum + item.value, 0);
  }

  readonly icons = {
    calendar: Calendar,
    download: Download,
    refresh: RefreshCw
  };
}
