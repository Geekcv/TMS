import { Component, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatChipsModule } from '@angular/material/chips';
import { LucideAngularModule, Plus, Search, Phone, CheckCircle, Clock, AlertCircle, Settings, Edit, Trash2, BarChart3, Globe, Shield, Users, MessageCircle } from 'lucide-angular';

type NumberStatus = 'verified' | 'pending' | 'rejected' | 'unknown';
type QualityRating = 'high' | 'medium' | 'low' | 'unknown';
type WhatsAppStatus = 'active' | 'pending_verification' | 'disabled';

interface PhoneNumberItem {
  id: string;
  number: string;
  displayName: string;
  businessName: string;
  status: NumberStatus;
  country: string;
  capabilities: Array<'voice' | 'sms' | 'whatsapp'>;
  whatsappStatus: WhatsAppStatus;
  messageLimit: number;
  messagesUsed: number;
  qualityRating: QualityRating;
  createdAt: string; // ISO date
  lastUsed: string | null; // ISO datetime
  webhookUrl: string;
  businessProfile: {
    verified: boolean;
    category: string;
    description: string;
  };
}
@Component({
  selector: 'app-phone-numbers-component',
  imports: [
      CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDialogModule,
    MatProgressBarModule,
    MatChipsModule,
    LucideAngularModule
  ],
  templateUrl: './phone-numbers-component.component.html',
  styleUrl: './phone-numbers-component.component.scss'
})
export class PhoneNumbersComponent {
  @ViewChild('addDialogTpl') addDialogTpl!: TemplateRef<unknown>;

  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconPhone = Phone;
  readonly IconCheck = CheckCircle;
  readonly IconClock = Clock;
  readonly IconAlert = AlertCircle;
  readonly IconSettings = Settings;
  readonly IconEdit = Edit;
  readonly IconTrash = Trash2;
  readonly IconChart = BarChart3;
  readonly IconGlobe = Globe;
  readonly IconShield = Shield;
  readonly IconUsers = Users;
  readonly IconMsg = MessageCircle;

  // Filters
  searchTerm = '';
  selectedStatus: 'all' | NumberStatus = 'all';
  selectedCountry: 'all' | string = 'all';

  // Add form
  addForm: FormGroup;

  // In-memory data mirroring React demo
  numbers: PhoneNumberItem[] = [
    {
      id: '1',
      number: '+1-555-0123',
      displayName: 'Main Support Line',
      businessName: 'TechStore Solutions',
      status: 'verified',
      country: 'United States',
      capabilities: ['voice', 'sms', 'whatsapp'],
      whatsappStatus: 'active',
      messageLimit: 1000,
      messagesUsed: 750,
      qualityRating: 'high',
      createdAt: '2024-01-10',
      lastUsed: '2024-01-15T10:30:00Z',
      webhookUrl: 'https://api.company.com/webhook',
      businessProfile: {
        verified: true,
        category: 'Technology',
        description: 'Customer support and sales inquiries'
      }
    },
    {
      id: '2',
      number: '+1-555-0456',
      displayName: 'Sales Department',
      businessName: 'TechStore Solutions',
      status: 'pending',
      country: 'United States',
      capabilities: ['voice', 'sms', 'whatsapp'],
      whatsappStatus: 'pending_verification',
      messageLimit: 250,
      messagesUsed: 0,
      qualityRating: 'unknown',
      createdAt: '2024-01-14',
      lastUsed: null,
      webhookUrl: 'https://api.company.com/webhook',
      businessProfile: {
        verified: false,
        category: 'Technology',
        description: 'Sales and product inquiries'
      }
    },
    {
      id: '3',
      number: '+44-20-7946-0958',
      displayName: 'UK Support',
      businessName: 'TechStore Solutions UK',
      status: 'verified',
      country: 'United Kingdom',
      capabilities: ['voice', 'sms', 'whatsapp'],
      whatsappStatus: 'active',
      messageLimit: 500,
      messagesUsed: 125,
      qualityRating: 'medium',
      createdAt: '2024-01-08',
      lastUsed: '2024-01-15T08:45:00Z',
      webhookUrl: 'https://api.company.com/webhook-uk',
      businessProfile: {
        verified: true,
        category: 'Technology',
        description: 'UK customer support'
      }
    }
  ];

  constructor(private fb: FormBuilder, private dialog: MatDialog) {
    this.addForm = this.fb.group({
      number: ['', Validators.required],
      displayName: ['', Validators.required],
      businessName: ['', Validators.required],
      country: ['United States', Validators.required],
      category: ['Technology', Validators.required],
      description: [''],
      webhookUrl: ['']
    });
  }

  // Stats
  get verifiedCount(): number { return this.numbers.filter(n => n.status === 'verified').length; }
  get totalMessageLimit(): number { return this.numbers.reduce((s, n) => s + n.messageLimit, 0); }
  get totalMessagesUsed(): number { return this.numbers.reduce((s, n) => s + n.messagesUsed, 0); }

  // Filters
  get filteredNumbers(): PhoneNumberItem[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.numbers.filter(n => {
      const matchesSearch = !term || n.number.includes(this.searchTerm) || n.displayName.toLowerCase().includes(term) || n.businessName.toLowerCase().includes(term);
      const matchesStatus = this.selectedStatus === 'all' || n.status === this.selectedStatus;
      const matchesCountry = this.selectedCountry === 'all' || n.country === this.selectedCountry;
      return matchesSearch && matchesStatus && matchesCountry;
    });
  }

  usagePct(n: PhoneNumberItem): number { return Math.round((n.messagesUsed / Math.max(1, n.messageLimit)) * 100); }
  lastUsedLocal(iso: string): string { return new Date(iso).toLocaleString(); }

  statusIcon(s: NumberStatus) { return s === 'verified' ? CheckCircle : s === 'pending' ? Clock : s === 'rejected' ? AlertCircle : Clock; }
  statusBadgeClass(s: NumberStatus): string {
    if (s === 'verified') return 'badge green';
    if (s === 'pending') return 'badge yellow';
    if (s === 'rejected') return 'badge red';
    return 'badge';
  }
  qualityBadgeClass(q: QualityRating): string {
    if (q === 'high') return 'green';
    if (q === 'medium') return 'yellow';
    if (q === 'low') return 'red';
    return '';
  }

  // Actions
  openAddDialog(tpl: TemplateRef<unknown>) { this.dialog.open(tpl, { width: '680px' }); }
  addNumber() {
    if (this.addForm.invalid) return;
    const v = this.addForm.value;
    const now = new Date();
    const newItem: PhoneNumberItem = {
      id: (Math.max(0, ...this.numbers.map(n => +n.id)) + 1).toString(),
      number: v.number!,
      displayName: v.displayName!,
      businessName: v.businessName!,
      status: 'pending',
      country: v.country!,
      capabilities: ['voice', 'sms', 'whatsapp'],
      whatsappStatus: 'pending_verification',
      messageLimit: 250,
      messagesUsed: 0,
      qualityRating: 'unknown',
      createdAt: now.toISOString().slice(0, 10),
      lastUsed: null,
      webhookUrl: v.webhookUrl || '',
      businessProfile: {
        verified: false,
        category: v.category!,
        description: v.description || ''
      }
    };
    this.numbers = [newItem, ...this.numbers];
    this.addForm.reset({ country: 'United States', category: 'Technology' });
    this.dialog.closeAll();
  }

  deleteNumber(n: PhoneNumberItem) { this.numbers = this.numbers.filter(x => x.id !== n.id); }
}