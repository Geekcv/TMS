import { Routes } from '@angular/router';
import { PhoneNumbersComponent } from './phone-numbers-component.component';

export default [
    {
        path: '',
        component: PhoneNumbersComponent,
    },
] as Routes;
