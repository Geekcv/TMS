import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { LucideAngularModule, Building, Smartphone, Users, Settings, Bell, Shield, Globe, Key, AlertCircle, CheckCircle, Copy, RefreshCw, Save, User as UserIcon } from 'lucide-angular';
import { User } from '../../components/contacts/user.model';

interface OrgSettings {
  name: string;
  description: string;
  website: string;
  industry: string;
  timezone: string;
  language: string;
}

interface WhatsAppSettings {
  phoneNumberId: string;
  accessToken: string;
  webhookUrl: string;
  verifyToken: string;
  businessAccountId: string;
}

interface NotificationSettings {
  emailReports: boolean;
  campaignAlerts: boolean;
  systemUpdates: boolean;
  billingNotifications: boolean;
  securityAlerts: boolean;
}

interface TeamMember {
  id: number;
  name: string;
  email: string;
  role: 'Admin' | 'Manager' | 'User';
  status: 'Active' | 'Pending';
}

@Component({
  selector: 'app-settings',
  imports: [CommonModule,
    FormsModule,
    MatCardModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatSlideToggleModule,
    MatDividerModule,
    LucideAngularModule,],
  templateUrl: './settings.component.html',
  styleUrl: './settings.component.scss'
})
export class SettingsComponent {
  @Input() user: User | null = null;

  // Icons
  readonly IconBuilding = Building;
  readonly IconSmartphone = Smartphone;
  readonly IconUsers = Users;
  readonly IconSettings = Settings;
  readonly IconBell = Bell;
  readonly IconShield = Shield;
  readonly IconGlobe = Globe;
  readonly IconKey = Key;
  readonly IconAlertCircle = AlertCircle;
  readonly IconCheck = CheckCircle;
  readonly IconCopy = Copy;
  readonly IconRefresh = RefreshCw;
  readonly IconSave = Save;
  readonly IconUser = UserIcon;

  orgSettings: OrgSettings = {
    name: this.user?.organizationName || 'Demo Organization',
    description: 'Leading e-commerce platform',
    website: 'https://company.com',
    industry: 'E-commerce',
    timezone: 'UTC-05:00',
    language: 'en_US'
  };

  whatsappSettings: WhatsAppSettings = {
    phoneNumberId: '123456789012345',
    accessToken: 'EAAG...***masked***',
    webhookUrl: 'https://yourapp.com/webhook',
    verifyToken: 'your_verify_token_123',
    businessAccountId: '987654321098765'
  };

  notifications: NotificationSettings = {
    emailReports: true,
    campaignAlerts: true,
    systemUpdates: false,
    billingNotifications: true,
    securityAlerts: true
  };

  teamMembers: TeamMember[] = [
    { id: 1, name: 'John Doe', email: 'john@company.com', role: 'Admin', status: 'Active' },
    { id: 2, name: 'Jane Smith', email: 'jane@company.com', role: 'Manager', status: 'Active' },
    { id: 3, name: 'Bob Johnson', email: 'bob@company.com', role: 'User', status: 'Pending' }
  ];

  saveOrgSettings() {
    console.log('Saving organization settings:', this.orgSettings);
  }

  saveWhatsAppSettings() {
    console.log('Saving WhatsApp settings:', this.whatsappSettings);
  }

  generateNewToken() {
    console.log('Generating new access token...');
  }

  testWebhook() {
    console.log('Testing webhook connection...');
  }

  copy(value: string) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(value);
    }
  }
}
