import { Routes } from '@angular/router';
import { CampaignsComponent } from 'app/modules/admin/components/campaign/campaign.component';

export default [
    {
        path: '',
        component: CampaignsComponent,
    },
] as Routes;
