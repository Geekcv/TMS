import { Component, inject, Input, signal, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { LucideAngularModule, Plus, Search, Users, Send, Play, BarChart3, Eye, Edit, Pause, FileText, MessageSquare, CheckCircle, Clock, XCircle, AlertCircle, Copy } from 'lucide-angular';
import { User } from '../../components/contacts/user.model';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatSnackBar } from '@angular/material/snack-bar';

type CampaignStatus = 'Active' | 'Completed' | 'Scheduled' | 'Draft' | 'Paused';



interface CapaignsData{
  campaign_id:string
  created_on:string
failed_count:string
campaign_name:string
sent_count:string
status:string
total_recipients:any
delivered_count:string
read_count:string
}

@Component({
  selector: 'app-campaign',
  imports: [
      CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatDialogModule,
    MatProgressBarModule,
    LucideAngularModule
  ],
  templateUrl: './campaign.component.html',
  styleUrl: './campaign.component.scss'
})
export class CampaignsComponent {
  @Input() user: User | null = null;
  @ViewChild('createDialog') createDialogTpl!: TemplateRef<unknown>;
    readonly messageText = signal('');
    readonly userText = signal('');

approvedTemplates: any[] = [];
ownUser: any[] = [];

      private _snackBar = inject(MatSnackBar);
  

  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconUsers = Users;
  readonly IconSend = Send;
  readonly IconPlay = Play;
  readonly IconBarChart = BarChart3;
  readonly IconEye = Eye;
  readonly IconEdit = Edit;
  readonly IconPause = Pause;

    readonly icons = {
    plus: Plus,
    file: FileText,
    message: MessageSquare,
    approved: CheckCircle,
    pending: Clock,
    rejected: XCircle,
    draft: AlertCircle,
    search: Search,
    eye: Eye,
    copy: Copy
  };


  searchTerm = '';
  displayedColumns = ['campaign', 'total_recipients', 'failed_count','read_count',  'created', ];

  createForm!: FormGroup;

  

  organization_id: any;
  userdata: any;
  createDialogRef: any;
  templateDialogRef: any;
  userDialogRef: any;


  constructor(private fb: FormBuilder, private dialog: MatDialog,private Apicontroller: ApicontrollerService,
    private dialog1: MatDialog
  ) {
    this.createForm = this.fb.group({
      name: ['', Validators.required],
    });

      this.userdata = JSON.parse(localStorage.getItem('userDeatials') || '{}');
    this.organization_id = this.userdata.organization_id;
  }

  ngOnInit(): void {
    this.fetchapprovedTemplates()
    this.fetchownuser()
    this.fetchOwnCampaigns()

  }

  
get totalMessages(): number {
  return this.Campaigns?.reduce((sum, c) => sum + parseInt(c.total_recipients), 0);
}
 





 async createAndSend() {
    const recipients = this.userText()
    const message = this.messageText()
    const name = this.createForm.value.name
    const template_name = this.selectedTemplate.name



    console.log("recipients----->",recipients,"message--->",message,"selected templates",this.selectedTemplate.name)

    var CampaignsData = {recipients,message,name,template_name}

    const resp = await this.Apicontroller.addCampaigns(CampaignsData)
    
    console.log("resp--->",resp)

    if (resp.status === 0) {
       this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
    }

   this.createForm.reset()
  this.dialog.closeAll();
    this.fetchOwnCampaigns()
    
  }


// Open Template Picker dialog


selectedTemplate: any = null;
placeholders: string[] = [];
placeholderValues: { [key: string]: string } = {};
previewBody: string = '';

selectTemplate(template: any) {
  this.selectedTemplate = template;

  const body: string = String(template.body || '');

  // Match placeholders like {{1}}, {{2}}, etc.
  const matches = body.match(/\{\{\d+\}\}/g) as string[] || [];

  // Remove duplicates and sort numerically
  this.placeholders = [...new Set(matches)].sort((a: string, b: string) => {
    const numA = parseInt(a.replace(/\D/g, ''), 10);
    const numB = parseInt(b.replace(/\D/g, ''), 10);
    return numA - numB;
  });

  
  // Initialize placeholderValues object
  this.placeholderValues = {};
  this.placeholders.forEach(ph => (this.placeholderValues[ph] = ''));
}


updatePreviewBody() {
  if (!this.selectedTemplate) return;

  let body = String(this.selectedTemplate.body || '');

  // Replace placeholders with current input values
  for (const [ph, val] of Object.entries(this.placeholderValues)) {
    const regex = new RegExp(ph.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'); // escape regex
    body = body.replace(regex, val || ph);
  }

  this.previewBody = body;
}


useTemplate() {
  if (!this.selectedTemplate) return;

  const header = this.selectedTemplate.header || '';
  const footer = this.selectedTemplate.footer || '';

  const formattedMessage = `
${header ? header + '\n' : ''}
${this.previewBody || this.selectedTemplate.body || ''}
${footer ? '\n' + footer : ''}
  `.trim();

  this.messageText.set(formattedMessage);
  this.closeTemplateDialog()}

  async fetchapprovedTemplates(){
          const resp = await this.Apicontroller.fetchapprovedTemplates();
          // console.log("resp---->",resp)
           if (resp && resp.data) {
    this.approvedTemplates = resp.data;

    // console.log("approvedTemplates--------------",this.approvedTemplates)
  }

  

  }

  // Open User Picker dialog



  async fetchownuser(){
 const resp = await this.Apicontroller.fetchUsersContacts(this.organization_id);          // console.log("resp---->",resp)
           if (resp && resp.data) {
    this.ownUser = resp.data;

  }
  console.log("resp--->",resp)
  }

  selectedUsers:any = []
  toggleUserSelection(user: any) {
  const index = this.selectedUsers.indexOf(user);
  if (index === -1) {
    this.selectedUsers.push(user);
  } else {
    this.selectedUsers.splice(index, 1);
  }
}

userSummit(){
  console.log("selectedUsers--->",this.selectedUsers)
  this.userText.set(this.selectedUsers);
  this.closeUserDialog()

}


Campaigns:CapaignsData[]

async fetchOwnCampaigns(){
  
  const resp = await this.Apicontroller.fetchOwnCampaigns()
  // console.log("resp fetch owm campings---",resp)
  this.Campaigns = resp.data
  console.log("resp fetch owm campings---",this.Campaigns)


}


// Close only Create Campaign dialog
closeCreateDialog() {
  if (this.createDialogRef) {
    this.createDialogRef.close();
  }
}

// Close only Template Picker dialog
closeTemplateDialog() {
  if (this.templateDialogRef) {
    this.templateDialogRef.close();
  }
}

// Close only User Picker dialog
closeUserDialog() {
  if (this.userDialogRef) {
    this.userDialogRef.close();
  }
}


// Create Campaign Dialog
openCreateDialog(template: TemplateRef<unknown>) {
  this.createDialogRef = this.dialog.open(template, {
    width: '600px',           // Width
    maxWidth: '90vw',         // Responsive max width
    height: 'auto',           // Height auto
    maxHeight: '80vh',        // Max height for scroll
    autoFocus: false,
    panelClass: 'custom-dialog-container'  // Custom CSS class
  });
}

// Template Picker Dialog
templatePicker(template: TemplateRef<unknown>) {
  this.templateDialogRef = this.dialog.open(template, {
    width: '1000px',
    maxWidth: '95vw',
    height: '700px',
    maxHeight: '90vh',
    autoFocus: false,
    panelClass: 'custom-dialog-container'
  });
}

// User Picker Dialog
userPicker(template: TemplateRef<unknown>) {
  this.userDialogRef = this.dialog.open(template, {
    width: '800px',
    maxWidth: '90vw',
    height: '500px',
    maxHeight: '85vh',
    autoFocus: false,
    panelClass: 'custom-dialog-container'
  });
}



}
