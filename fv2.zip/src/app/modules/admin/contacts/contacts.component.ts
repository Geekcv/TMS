import {
    ChangeDetectionStrategy,
    Component,
    ViewEncapsulation,
} from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
    selector: 'contacts',
    templateUrl: './contacts.component.html',
    styleUrl:'./contacts.component.scss',
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    // imports: [RouterOutlet],
})
export class ContactsComponent {
    /**
     * Constructor
     */
    constructor() {}
}
