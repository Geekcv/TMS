import { Component, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatRippleModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoModule } from '@jsverse/transloco';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { WhatsappStatusCheckService } from 'app/Services/whatsapp-status-check.service';
import { NgApexchartsModule } from 'ng-apexcharts';
import { config } from '../../../../../config';

@Component({
    selector: 'app-dashboard',
    standalone: true,
    templateUrl: './dashboard.component.html',
    styleUrl: './dashboard.component.scss',
    encapsulation: ViewEncapsulation.None,
    imports: [
        //   TranslocoModule,
        //   MatIconModule,
        //   MatButtonModule,
        //   MatRippleModule,
        //   MatMenuModule,
        //   MatTabsModule,
        //   MatButtonToggleModule,
        //   NgApexchartsModule,
        //   MatTableModule,
        // NgClass,
        //CurrencyPipe,
        TranslocoModule,
        MatIconModule,
        MatButtonModule,
        MatRippleModule,
        MatMenuModule,
        MatTabsModule,
        MatButtonToggleModule,
        NgApexchartsModule,
        MatTableModule,
        // NgClass,
        //CurrencyPipe,
    ],
})
export class DashboardComponent {
    role: any;
    organization_id: any;
    userdata: any;
    whatsapp_status: any;

    configdata: any;
    orgname: any;
    email: any;

    /**
     * Constructor
     */
    constructor(
        private api: ApicontrollerService,
        private route: ActivatedRoute,
        private _router: Router,
        private _whatsappStatus: WhatsappStatusCheckService
    ) {
        this.configdata = config.apiBaseURL;

        this.userdata = JSON.parse(localStorage.getItem('userDeatials'));
        this.orgname = this.userdata.name;
        this.email = this.userdata.email;

        // this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
        this.userdata = JSON.parse(localStorage.getItem('userDeatials'));
        this.organization_id = this.userdata.organization_id;
        this.role = _whatsappStatus.getRole();

        // console.log("user data",this.userdata.organization_id)

        // console.log("this.route.snapshot.queryParams.status ---",this.route.snapshot.queryParams.status,this.route.snapshot.queryParams.status == 0)

        this.whatsapp_status = _whatsappStatus.getwhatsappStatus();
        console.log('inside constructor part', this.whatsapp_status);

        if (this.route.snapshot.queryParams.status == 0) {
            _whatsappStatus.setwhatsappStatus(
                this.route.snapshot.queryParams.status
            );
            this.whatsapp_status = this.route.snapshot.queryParams.status;
            //  console.log("inside first time fetch status from query params",this.whatsapp_status)
            //    console.log("get current store whatsapp data ",_whatsappStatus.getwhatsappStatus());
            this.whatsapp_status = _whatsappStatus.getwhatsappStatus();
        }

        // console.log("My role ---->",_whatsappStatus.getRole())
    }

    // environment.ts (Angular)
   // your-component.ts
environment = {
  production: false,
  metaAppId: '1525081288672361',
  metaRedirectUri: `${config.apiBaseURL}/auth/facebook/callback`,
};

connectWhatsapp() {
  console.log('inside whatsapp button ', this.organization_id);

  const extras = encodeURIComponent(JSON.stringify({
    setup: { type: 'whatsapp_onboarding' } // 👈 this triggers embedded signup if no business
  }));

  const fbOAuthUrl =
    `https://www.facebook.com/v18.0/dialog/oauth` +
    `?client_id=${this.environment.metaAppId}` +
    `&redirect_uri=${encodeURIComponent(this.environment.metaRedirectUri)}` +
    `&scope=whatsapp_business_management,whatsapp_business_messaging,business_management` +
    `&state=${this.organization_id}` +
    `&extras=${extras}`;

  window.location.href = fbOAuthUrl;
}

    
}
