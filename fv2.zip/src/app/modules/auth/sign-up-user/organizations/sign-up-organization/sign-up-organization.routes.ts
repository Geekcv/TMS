import { Routes } from '@angular/router';
import { SignUpOrganizationComponent } from './sign-up-organization.component';

export default [
    {
        path: '',
        component: SignUpOrganizationComponent,
    },
] as Routes;
