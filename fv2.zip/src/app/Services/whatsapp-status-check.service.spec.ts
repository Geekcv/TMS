import { TestBed } from '@angular/core/testing';

import { WhatsappStatusCheckService } from './whatsapp-status-check.service';

describe('WhatsappStatusCheckService', () => {
  let service: WhatsappStatusCheckService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WhatsappStatusCheckService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
