
import { Injectable } from '@angular/core';
import { FuseNavigationItem } from '@fuse/components/navigation';
import { FuseMockApiService } from '@fuse/lib/mock-api';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { defaultNavigation } from 'app/mock-api/common/navigation/data'; // Correct import
import { WhatsappStatusCheckService } from 'app/Services/whatsapp-status-check.service';
import { cloneDeep } from 'lodash-es';

@Injectable({ providedIn: 'root' })
export class NavigationMockApi {

    
    // role: void;

      
    /**
     * Constructor
     */
    constructor(private _fuseMockApiService: FuseMockApiService,
        private _whatsappStatus:WhatsappStatusCheckService,
         private Apicontroller: ApicontrollerService
    ) {
        
        // this.loadUserPermissions()
           this.registerHandlers();
    }

    
    /**
     * Register Mock API handlers
     */
    registerHandlers(): void {
        this._fuseMockApiService.onGet('api/common/navigation').reply(({ request }) => {
            // Get role from request headers (mock example, modify as needed)
            // const role = Number(localStorage.getItem('role')); // Convert to number
            // console.log("role",role)

        //    this.loadUserPermissions()

            // const role = this._whatsappStatus.getRole()

            // console.log("insie registerhandler",this._whatsappStatus.getRole())
             const role = this._whatsappStatus.getRole();
            // console.log("role==========>",role)


            // const role = this._whatsappStatus.getRole()
            // console.log("role of side bar --->",role)
            //  Use getNavigation instead of defaultNavigation
            const navigation = cloneDeep(defaultNavigation(role));
            

            return [
                200,
                {
                    default: navigation,
                },
            ];
        });
    }
}
