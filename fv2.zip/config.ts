export const config = {
    
    apiBaseURL : 'http://localhost:3000', 
    // apiBaseURL:'https://724c27bb6f3c.ngrok-free.app',


    // apiBaseURL:'https://aiclassroom.ftisindia.com',

    appVersion: '1.0.0'
}

