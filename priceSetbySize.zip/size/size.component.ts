import { Component } from '@angular/core';

@Component({
  selector: 'app-size',
  templateUrl: './size.component.html',
  styleUrls: ['./size.component.css']
})
export class SizeComponent {

  // constructor() {}

  // formname = {
  //   label: 'Size Table',
  //   css: 'mx-auto mb-5 text-4xl font-semibold'
  // };

  // classes = {
  //   elements: [
  //     {
  //       type: 'table',
  //       headers: ['Category', 'Class 1', 'Class 2'],
  //       rows: [] as { category: string; class1: string; class2: string }[] // Initialize rows as an array of objects with defined structure
  //     },
  //     {
  //       type: 'button',
  //       buttonType: 'button',
  //       label: 'Create New Table Row',
  //       css: 'w-20rem px-3 py-2 mt-5 btnBG1 text-50 text-2xl',
  //       action: 'addRow'
  //     }
  //   ],
  //   css: 'flex gap-6 w-full justify-content-evenly align-items-center flex-column py-2 px-0'
  // };

  // addNewRow() {
  //   const table = this.classes.elements[0];
  //   if (table && table.rows) {
  //     table.rows.push({ category: 'New Category', class1: 'New Class 1', class2: 'New Class 2' });
  //   }
  // }


  formname = {
    label: 'Size Table',
    css: 'mx-auto mb-5 text-4xl font-semibold'
  };


  // Define options for dropdowns
  categoryOptions = [
    { name: 'Category 1',},
    { name: 'Category 2',},
    { name: 'Category 3',},
    { name: 'Category 4',},
    { name: 'Category 5',},
    { name: 'Category 6',},
    { name: 'Category 7',},
    { name: 'Category 8',},
    { name: 'Category 9',},
    { name: 'Category 10',},
    { name: 'Category 11',},
    { name: 'Category 12',}
  ];
  
  class1Options = [
    { name: 'Size 1A', },
    { name: 'Size 1B', },
    { name: 'Size 1C', },
    { name: 'Size 1A', },
    { name: 'Size 1B', },
    { name: 'Size 1C', },
    { name: 'Size 1A', },
    { name: 'Size 1B', },
    { name: 'Size 1C', }
  ];
  
  class2Options = [
    { name: 'Size 2A', },
    { name: 'Size 2B', },
    { name: 'Size 2C', },
    { name: 'Size 1A', },
    { name: 'Size 1B', },
    { name: 'Size 1C', },
    { name: 'Size 1A', },
    { name: 'Size 1B', },
    { name: 'Size 1C', }
  ];

  // Define types for table rows
  classes = {
    elements: [
      {
        type: 'table',
        headers: ['Category', 'Class 1', 'Class 2'],
        rows: [] as { 
          category: string; 
          class1: string; 
          class2: string; 
        }[] // Initialize rows as an array of objects with defined structure
      },
      {
        type: 'button',
        buttonType: 'button',
        label: 'Create New Table Row',
        css: 'w-20rem px-3 py-2 mt-5 btnBG1 text-50 text-2xl',
        action: 'addRow'
      }
    ],
    css: 'flex gap-6 w-full justify-content-evenly align-items-center flex-column py-2 px-0'
  };

  // Method to add a new row
  addNewRow() {
    const table = this.classes.elements[0];
    if (table && Array.isArray(table.rows)) {
      table.rows.push({
        category: 'select category', // Default value for the dropdown
        class1: 'select class',     // Default value for the dropdown
        class2: 'select class'      // Default value for the dropdown
      });
    } else {
      console.error('Table or rows are not properly initialized');
    }
  }

  // Method to handle dropdown change
  handleDropdownChange(row: any, column: string, event: any) {
    row[column] = event.target.value;
    this.logSelectedData();
  }

  // Method to log all selected data
  logSelectedData() {
    const table = this.classes.elements[0];
    if (table && Array.isArray(table.rows)) {
      const selectedData = table.rows.map(row => ({
        category: row.category,
        class1: row.class1,
        class2: row.class2
      }));
      console.log('Selected Data:', selectedData);
    }
  }

  Submit(){
    this.logSelectedData();
    
  }


}
