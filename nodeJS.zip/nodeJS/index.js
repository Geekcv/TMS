const express = require("express");
const app = express();

// Middleware to parse JSON
app.use(express.json());

// Home route
app.get("/", (req, res) => {
  res.send("Welcome to the Simple Express App!");
});

// Example API route
app.get("/api", (req, res) => {
  res.json({ message: "Hello from Express API!" });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
