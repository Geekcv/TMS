import { Viewproviders } from './viewproviders';

describe('Viewproviders', () => {
  it('should create an instance', () => {
    expect(new Viewproviders()).toBeTruthy();
  });
});
