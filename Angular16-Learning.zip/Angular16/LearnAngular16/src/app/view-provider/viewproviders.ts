console.log("view provider")
export class Viewproviders {

    constructor(){
        console.log("constructor Viewproviders")
    }

    showP(){
        console.log("Show-p Viewproviders")

    }
}
