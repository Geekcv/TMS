import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PTableComponent } from './Table/ptable/ptable.component';

import { TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';  // Import ButtonModule
import { TagModule } from 'primeng/tag';  // Import TagModule
import { RatingModule } from 'primeng/rating';
import { PDropdownComponent } from './Dropdown/pdropdown/pdropdown.component';
import { PDropdownsComponent } from './Dropdown/pdropdowns/pdropdowns.component';  // Import RatingModule


@NgModule({
  declarations: [
    AppComponent,
    PTableComponent,
    PDropdownComponent,
    PDropdownsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    TableModule,
    CommonModule,
    FormsModule,
    ButtonModule,
    TagModule,
    RatingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
