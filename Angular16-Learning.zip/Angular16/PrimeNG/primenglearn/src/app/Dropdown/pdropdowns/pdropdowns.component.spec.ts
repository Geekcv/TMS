import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PDropdownsComponent } from './pdropdowns.component';

describe('PDropdownsComponent', () => {
  let component: PDropdownsComponent;
  let fixture: ComponentFixture<PDropdownsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PDropdownsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PDropdownsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
