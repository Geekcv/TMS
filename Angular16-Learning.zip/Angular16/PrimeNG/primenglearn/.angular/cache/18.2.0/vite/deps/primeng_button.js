import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-EN34U5T5.js";
import "./chunk-FFZZ2XJN.js";
import "./chunk-O7DFUHAK.js";
import "./chunk-SXM6IB3K.js";
import "./chunk-PBKKMZF6.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
