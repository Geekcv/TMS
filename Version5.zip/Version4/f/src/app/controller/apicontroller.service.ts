import { Injectable } from '@angular/core';
import { ApiService } from '../servies/api.service';

@Injectable({
  providedIn: 'root'
})
export class ApicontrollerService {

  constructor(private apiService: ApiService) { }

  async loginuser(logindata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "lo_us",
      "data": logindata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  async createClient(clientdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_cl",
      "data": clientdata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  async fetchClient(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_cl",
      "data": ""
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }

  

  async createlinks(linksdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_lik",
      "data": linksdata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  

  async fetchlinks(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_lin",
      "data": ""
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  

  async fetchlinksclient(client_id: any ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_clId",
      "data": {
        client_id
      }
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  async createProject(projectdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "add_pro",
      "data": projectdata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }
  


  async fetchProject(client_id:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_proj",
      "data": {client_id}
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  async createProlinks(linksdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "add_links",
      "data": linksdata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }



  async createCredentials(Credentialsdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_crdent",
      "data": Credentialsdata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  

  async fetchCredentialsclient(client_id: any ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_crdentId",
      "data": {
        client_id
      }
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }



  async fetchcredential(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_crdent",
      "data": ""
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  

  async fetchcredentialclient(client_id: any ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_clId",
      "data": {
        client_id
      }
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


}
