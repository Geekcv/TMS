import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-file-own',
  templateUrl: './file-own.component.html',
  styleUrls: ['./file-own.component.css'],
})
export class FileOwnComponent {
  uploadedFiles1: { name: string; size: number; content?: string | ArrayBuffer | null }[] = [];
  private uploadUrl = 'http://localhost:3000/common/uploads';
  uploadSuccessMessage: string = ''; // For success message
  uploadErrorMessage: string = ''; // For error message

  constructor(private http: HttpClient) {}

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const files = Array.from(input.files);

      files.forEach((file) => {
        const formData = new FormData();
        formData.append('file', file);

        this.http.post(this.uploadUrl, formData).subscribe({
          next: (response: any) => {
            console.log('Upload successful:', response);
            this.uploadedFiles1.push({ name: file.name, size: file.size });
            this.uploadSuccessMessage = `File "${file.name}" uploaded successfully!`;
            setTimeout(() => (this.uploadSuccessMessage = ''), 5000); // Clear after 5 seconds
          },
          error: (error) => {
            console.error('Upload failed:', error);
            this.uploadErrorMessage = `Failed to upload "${file.name}". Please try again.`;
            setTimeout(() => (this.uploadErrorMessage = ''), 5000); // Clear after 5 seconds
          },
        });
      });
    }
  }

  deleteFile(index: number): void {
    this.uploadedFiles1.splice(index, 1);
  }

  downloadFile(file: { name: string }): void {
    window.open(`${this.uploadUrl}/${file.name}`, '_blank');
  }

  getFileLogo(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return 'assets/icons/p1.png';
      case 'doc':
      case 'docx':
        return 'assets/icons/doc-icon.png';
      case 'txt':
        return 'assets/icons/txt-icon.png';
      case 'png':
      case 'jpg':
      case 'jpeg':
        return 'assets/icons/i1.jpg';
      default:
        return 'assets/icons/default-icon.png';
    }
  }
}
