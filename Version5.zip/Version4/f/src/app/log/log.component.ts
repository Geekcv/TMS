import { Component } from '@angular/core';

@Component({
  selector: 'app-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.css']
})
export class LogComponent {

  workLogs = [{ description: 'Work log 1', date: '2025-01-12', updatedBy: 'Ramesh', tags: 'Pending' }];


  isWorkLogDialogVisible = false;


  currentWorkLog: any = {};
  editIndex = -1;

  openWorkLogDialog() {
    this.currentWorkLog = {};
    this.editIndex = -1;
    this.isWorkLogDialogVisible = true;
  }


  editWorkLog(workLog: any, index: number) {
    this.currentWorkLog = { ...workLog };
    this.editIndex = index;
    this.isWorkLogDialogVisible = true;
  }

  saveWorkLog() {
    if (this.editIndex >= 0) {
      this.workLogs[this.editIndex] = this.currentWorkLog;
    } else {
      this.workLogs.push(this.currentWorkLog);
    }
    this.closeWorkLogDialog();
  }


  closeWorkLogDialog() {
    this.isWorkLogDialogVisible = false;
  }
}
