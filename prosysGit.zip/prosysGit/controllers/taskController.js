const pool = require("../db");

// Create a new task
exports.createTask = async (req, res) => {
  const created_by = req.user.userId;

  const {
    // created_by,
    assigned_to,
    title,
    description,
    status,
    is_recurring,
    due_date,
  } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO tasks (created_by, assigned_to, title, description, status, is_recurring, due_date) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [
        created_by,
        assigned_to,
        title,
        description,
        status,
        is_recurring,
        due_date,
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all tasks
exports.getTasks = async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM tasks`);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a single task by ID
exports.getTaskById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(`SELECT * FROM tasks WHERE row_id = $1`, [
      id,
    ]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Task not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a task by ID
exports.updateTask = async (req, res) => {
  const { id } = req.params;
  const { assigned_to, title, description, status, is_recurring, due_date } =
    req.body;

  try {
    const result = await pool.query(
      `UPDATE tasks 
       SET assigned_to = $1, title = $2, description = $3, status = $4, is_recurring = $5, due_date = $6, updated_at = CURRENT_TIMESTAMP 
       WHERE row_id = $7 RETURNING *`,
      [assigned_to, title, description, status, is_recurring, due_date, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Task not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a task by ID
exports.deleteTask = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `DELETE FROM tasks WHERE row_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Task not found" });
    }
    res.json({ message: "Task deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get tasks grouped by status (stages)
// exports.getTasksByStage = async (req, res) => {
//   try {
//     // Fetch all tasks grouped by status
//     const ongoingTasks = await pool.query(
//       `SELECT * FROM tasks WHERE status = 'ongoing' ORDER BY due_date ASC`
//     );

//     const overdueTasks = await pool.query(
//       `SELECT * FROM tasks WHERE status = 'overdue' ORDER BY due_date ASC`
//     );

//     const completedTasks = await pool.query(
//       `SELECT * FROM tasks WHERE status = 'complete' ORDER BY due_date ASC`
//     );

//     res.status(200).json({
//       ongoing: ongoingTasks.rows,
//       overdue: overdueTasks.rows,
//       complete: completedTasks.rows,
//     });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// add filter and paginatores

exports.getTasksByStage = async (req, res) => {
  const { page = 1, limit = 10, status, due_date, created_by } = req.query;

  // Calculate offset for pagination
  const offset = (page - 1) * limit;

  try {
    // Base SQL query
    let baseQuery = "SELECT * FROM tasks WHERE 1=1"; // Using 1=1 to simplify conditional appending

    // Add filters based on query parameters
    const values = [];
    if (status) {
      baseQuery += " AND status = $1";
      values.push(status);
    }
    if (due_date) {
      baseQuery += values.length
        ? " AND due_date <= $" + (values.length + 1)
        : " AND due_date <= $1";
      values.push(due_date);
    }
    if (created_by) {
      baseQuery += values.length
        ? " AND created_by = $" + (values.length + 1)
        : " AND created_by = $1";
      values.push(created_by);
    }

    // Add pagination (LIMIT and OFFSET)
    baseQuery += ` ORDER BY due_date ASC LIMIT $${values.length + 1} OFFSET $${
      values.length + 2
    }`;
    values.push(limit, offset);

    // Execute query
    const result = await pool.query(baseQuery, values);

    // Get total count for pagination info
    const countResult = await pool.query(
      `SELECT COUNT(*) FROM tasks WHERE 1=1`
    );
    const totalTasks = parseInt(countResult.rows[0].count);

    res.status(200).json({
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(totalTasks / limit),
      totalTasks,
      tasks: result.rows,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// GET /tasks/stages?page=1&limit=5&status=ongoing
// GET /tasks/stages?page=2&limit=10&due_date=2024-09-30
// GET /tasks/stages?created_by=8
// page=1: First page of results.
// limit=5: Five tasks per page.
// status=ongoing: Filter to only show ongoing tasks
