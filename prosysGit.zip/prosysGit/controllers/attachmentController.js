const pool = require("../db");

// Create a new attachment
exports.createAttachment = async (req, res) => {
  const { task_id, file_path } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO attachments (task_id, file_path) 
       VALUES ($1, $2) RETURNING *`,
      [task_id, file_path]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all attachments for a task
exports.getAttachmentsByTask = async (req, res) => {
  const { task_id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM attachments WHERE task_id = $1`,
      [task_id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a single attachment by ID
exports.getAttachmentById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM attachments WHERE row_id = $1`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Attachment not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete an attachment by ID
exports.deleteAttachment = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `DELETE FROM attachments WHERE row_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Attachment not found" });
    }
    res.json({ message: "Attachment deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
