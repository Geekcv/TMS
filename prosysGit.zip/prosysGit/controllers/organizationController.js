const bcrypt = require("bcryptjs");
const pool = require("../db");
const jwt = require("jsonwebtoken");

// Create a new organization
// exports.createOrganization = async (req, res) => {
//   const { Owns_name, mobile_no, email, password, GTS_NO } = req.body;

//   try {
//     // Insert new organization into the database
//     const result = await pool.query(
//       `INSERT INTO organizations (Owns_name, mobile_no, email, password, GTS_NO)
//        VALUES ($1, $2, $3, $4, $5) RETURNING *`,
//       [Owns_name, mobile_no, email, password, GTS_NO]
//     );
//     res.status(201).json(result.rows[0]);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// Create new organization with hashed password
exports.createOrganization = async (req, res) => {
  const { Owns_name, mobile_no, email, password, GTS_NO } = req.body;

  try {
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Insert new organization into the database
    const result = await pool.query(
      `INSERT INTO organizations (Owns_name, mobile_no, email, password, GTS_NO) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [Owns_name, mobile_no, email, hashedPassword, GTS_NO]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const JWT_SECRET = process.env.JWT_SECRET || "your_jwt_secret";

exports.loginOrganization = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if the organization exists
    const org = await pool.query(
      `SELECT * FROM organizations WHERE email = $1`,
      [email]
    );

    if (org.rows.length === 0) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Compare the password
    const isMatch = await bcrypt.compare(password, org.rows[0].password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Generate JWT token
    const token = jwt.sign(
      { orgId: org.rows[0].row_id, role: "super admin" }, // Add a role field to identify as organization
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.json({ token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all organizations
exports.getOrganizations = async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM organizations`);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a single organization by ID
exports.getOrganizationById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM organizations WHERE row_id = $1`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Organization not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update an organization by ID
exports.updateOrganization = async (req, res) => {
  const { id } = req.params;
  const { Owns_name, mobile_no, email, password, GTS_NO } = req.body;

  try {
    const result = await pool.query(
      `UPDATE organizations 
       SET Owns_name = $1, mobile_no = $2, email = $3, password = $4, GTS_NO = $5, updated_at = CURRENT_TIMESTAMP 
       WHERE row_id = $6 RETURNING *`,
      [Owns_name, mobile_no, email, password, GTS_NO, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Organization not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete an organization by ID
exports.deleteOrganization = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `DELETE FROM organizations WHERE row_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Organization not found" });
    }
    res.json({ message: "Organization deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
