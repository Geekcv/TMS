const bcrypt = require("bcryptjs");
const pool = require("../db");
const jwt = require("jsonwebtoken");
const { use } = require("bcrypt/promises");

// Create a new user
// exports.createUser = async (req, res) => {
//   const { team_id, email, password, role } = req.body;

//   try {
//     // Insert new user into the database
//     const result = await pool.query(
//       `INSERT INTO users (team_id, email, password, role)
//        VALUES ($1, $2, $3, $4) RETURNING *`,
//       [team_id, email, password, role]
//     );
//     res.status(201).json(result.rows[0]);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

exports.createUser = async (req, res) => {
  const { team_id, email, password, role } = req.body;

  try {
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Insert new user into the database
    const result = await pool.query(
      `INSERT INTO users (team_id, email, password, role)
         VALUES ($1, $2, $3, $4) RETURNING *`,
      [team_id, email, hashedPassword, role]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const JWT_SECRET = process.env.JWT_SECRET || "your_jwt_secret";

exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if the user exists
    const user = await pool.query(`SELECT * FROM users WHERE email = $1`, [
      email,
    ]);

    console.log(user);

    if (user.rows.length === 0) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Compare the password
    const isMatch = await bcrypt.compare(password, user.rows[0].password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // console.log(user.row[0]);

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.rows[0].row_id,
        role: user.rows[0].role,
        teamId: user.rows[0].team_id,
      },
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.json({ token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all users
exports.getUsers = async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM users`);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a single user by ID
exports.getUserById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(`SELECT * FROM users WHERE row_id = $1`, [
      id,
    ]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a user by ID
exports.updateUser = async (req, res) => {
  const { id } = req.params;
  const { team_id, email, password, role } = req.body;

  try {
    const result = await pool.query(
      `UPDATE users 
       SET team_id = $1, email = $2, password = $3, role = $4, updated_at = CURRENT_TIMESTAMP 
       WHERE row_id = $5 RETURNING *`,
      [team_id, email, password, role, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a user by ID
exports.deleteUser = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `DELETE FROM users WHERE row_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json({ message: "User deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
