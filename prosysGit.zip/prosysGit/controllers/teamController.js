const pool = require("../db");

// Create a new team
exports.createTeam = async (req, res) => {
  const { department_id, teams_name } = req.body;

  try {
    // Insert new team into the database
    const result = await pool.query(
      `INSERT INTO teams (department_id, teams_name) 
       VALUES ($1, $2) RETURNING *`,
      [department_id, teams_name]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all teams
exports.getTeams = async (req, res) => {
  try {
    const result = await pool.query(`SELECT * FROM teams`);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a single team by ID
exports.getTeamById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(`SELECT * FROM teams WHERE row_id = $1`, [
      id,
    ]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Team not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a team by ID
exports.updateTeam = async (req, res) => {
  const { id } = req.params;
  const { teams_name } = req.body;

  try {
    const result = await pool.query(
      `UPDATE teams 
       SET teams_name = $1, updated_at = CURRENT_TIMESTAMP 
       WHERE row_id = $2 RETURNING *`,
      [teams_name, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Team not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a team by ID
exports.deleteTeam = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `DELETE FROM teams WHERE row_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Team not found" });
    }
    res.json({ message: "Team deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
