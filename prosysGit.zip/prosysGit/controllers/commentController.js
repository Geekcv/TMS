const pool = require("../db");

// Create a new comment
exports.createComment = async (req, res) => {
  const { task_id, user_id, comment } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO comments (task_id, user_id, comment) 
       VALUES ($1, $2, $3) RETURNING *`,
      [task_id, user_id, comment]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all comments for a task
exports.getCommentsByTask = async (req, res) => {
  const { task_id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM comments WHERE task_id = $1`,
      [task_id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a single comment by ID
exports.getCommentById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM comments WHERE row_id = $1`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Comment not found" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a comment by ID
exports.deleteComment = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `DELETE FROM comments WHERE row_id = $1 RETURNING *`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Comment not found" });
    }
    res.json({ message: "Comment deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
