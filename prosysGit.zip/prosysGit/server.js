const express = require("express");
const organizationRoutes = require("./routes/organizationRoutes"); // Import organization routes
const departmentRoutes = require("./routes/departmentRoutes"); // Import department routes
const teamRoutes = require("./routes/teamRoutes"); // Import team routes
const userRoutes = require("./routes/userRoutes"); // Import user routes
const commentRoutes = require("./routes/commentRoutes"); // Import user routes
const taskRoutes = require("./routes/taskRoutes"); // Import user routes

const app = express();

app.use(express.json()); // To parse JSON requests

// Organization API Routes
app.use("/api", organizationRoutes);
app.use("/api", departmentRoutes);
app.use("/api", teamRoutes);
app.use("/api", userRoutes);
app.use("/api", taskRoutes);
app.use("/api", commentRoutes);
// app.use("/api", userRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  res.status(500).json({ error: err.message });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
