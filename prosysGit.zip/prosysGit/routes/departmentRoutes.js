const express = require("express");
const {
  createDepartment,
  getDepartments,
  getDepartmentById,
  updateDepartment,
  deleteDepartment,
} = require("../controllers/departmentController");
const { protect, authorize } = require("../Middleware/aurh");

const router = express.Router();

// Define routes for departments
router.post(
  "/departments",
  protect,
  authorize("super admin"),
  createDepartment
); // Create new department
router.get("/departments", getDepartments); // Get all departments
router.get("/departments/:id", getDepartmentById); // Get department by ID
router.put("/departments/:id", updateDepartment); // Update department by ID
router.delete("/departments/:id", deleteDepartment); // Delete department by ID

module.exports = router;
