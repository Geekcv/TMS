const express = require("express");
const {
  createUser,
  getUsers,
  getUserById,
  updateUser,
  deleteUser,
  loginUser,
} = require("../controllers/userController.js");
const { protect, authorize } = require("../Middleware/aurh.js");

const router = express.Router();

// Define routes for users
router.post("/users", protect, authorize("super admin"), createUser); // Create new user
router.get("/users", getUsers); // Get all users
router.get("/users/:id", getUserById); // Get a single user by ID
router.put("/users/:id", updateUser); // Update a user by ID
router.delete("/users/:id", deleteUser); // Delete a user by ID

router.post("/userslogin", loginUser); // Create new user

module.exports = router;
