const express = require("express");
const {
  createComment,
  getCommentsByTask,
  getCommentById,
  deleteComment,
} = require("../controllers/commentController");

const router = express.Router();

router.post("/comments", createComment); // Create a new comment
router.get("/comments/task/:task_id", getCommentsByTask); // Get comments by task ID
router.get("/comments/:id", getCommentById); // Get a single comment by ID
router.delete("/comments/:id", deleteComment); // Delete a comment by ID

module.exports = router;
