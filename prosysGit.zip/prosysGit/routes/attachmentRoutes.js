const express = require("express");
const {
  createAttachment,
  getAttachmentsByTask,
  getAttachmentById,
  deleteAttachment,
} = require("../controllers/attachmentController.js");
