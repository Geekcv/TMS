const express = require("express");
const {
  createTeam,
  getTeams,
  getTeamById,
  updateTeam,
  deleteTeam,
} = require("../controllers/teamController");
const { protect } = require("../Middleware/aurh");

const router = express.Router();

// Define routes for teams
router.post("/teams", protect, createTeam); // Create new team
router.get("/teams", getTeams); // Get all teams
router.get("/teams/:id", getTeamById); // Get a single team by ID
router.put("/teams/:id", updateTeam); // Update a team by ID
router.delete("/teams/:id", deleteTeam); // Delete a team by ID

module.exports = router;
