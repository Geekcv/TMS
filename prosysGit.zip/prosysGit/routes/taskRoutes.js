const express = require("express");
const {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
  getTasksByStage,
} = require("../controllers/taskController");
const { protect, authorize } = require("../Middleware/aurh");

const router = express.Router();

router.post("/tasks", protect, createTask); // Create a new task
router.get("/tasks", getTasks); // Get all tasks
router.get("/tasks/:id", getTaskById); // Get a single task by ID
router.put("/tasks/:id", updateTask); // Update a task by ID
router.delete(
  "/tasks/:id",
  protect,
  authorize("admin", "super admin"),
  deleteTask
); // Delete a task by ID

router.get("/tasksStage", protect, getTasksByStage);

module.exports = router;
