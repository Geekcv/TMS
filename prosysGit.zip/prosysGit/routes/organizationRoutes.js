const express = require("express");
const {
  createOrganization,
  getOrganizations,
  getOrganizationById,
  updateOrganization,
  deleteOrganization,
  loginOrganization,
} = require("../controllers/organizationController");

const router = express.Router();

// Define routes for organizations
router.post("/organizations", createOrganization); // Create new organization
router.get("/organizations", getOrganizations); // Get all organizations
router.get("/organizations/:id", getOrganizationById); // Get organization by ID
router.put("/organizations/:id", updateOrganization); // Update organization by ID
router.delete("/organizations/:id", deleteOrganization); // Delete organization by ID

router.post("/organizationslogin", loginOrganization); // Create new organization

module.exports = router;
