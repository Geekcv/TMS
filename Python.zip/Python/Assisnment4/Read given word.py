def find_word_in_file(file_path, word):
    with open(file_path, 'r') as file:
        text = file.read()
        occurrences = text.count(word)
    
    return occurrences

# Example usage:
file_path = 'E:\\newpass.txt'
word = "BY"
occurrences = find_word_in_file(file_path, word)
print(f"Occurrences of '{word}': {occurrences}")
