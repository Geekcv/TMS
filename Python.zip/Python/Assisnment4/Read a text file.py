def count_file_elements(file_path):
    with open(file_path, 'r') as file:
        text = file.read()
        num_characters = len(text)
        num_lines = text.count('\n') + 1
        num_spaces = text.count(' ')
    
    return num_characters, num_lines, num_spaces

# Example usage:
file_path = 'E:\\newpass.txt'
characters, lines, spaces = count_file_elements(file_path)
print(f"Characters: {characters}, Lines: {lines}, Spaces: {spaces}")
