def write_employee_records(file_path):
    employees = [
        "John Doe, Manager, 50000\n",
        "Jane Smith, Developer, 60000\n",
        "Emily Davis, Designer, 55000\n",
        "Michael Brown, Tester, 45000\n",
        "Jessica Taylor, Analyst, 52000\n"
    ]
    
    with open(file_path, 'w') as file:
        file.writelines(employees)

# Example usage:
file_path = 'E:\\newpass.txt'
write_employee_records(file_path)
