# Using readline()
with open('E:\\newpass.txt', 'r') as file:
    first_line = file.readline()
    print("First line using readline():", first_line.strip())

# Using readlines()
with open('E:\\newpass.txt', 'r') as file:
    all_lines = file.readlines()
    print("All lines using readlines():")
    for line in all_lines:
        print(line.strip())
