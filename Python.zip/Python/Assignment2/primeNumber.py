def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def display_non_primes(start, end):
    non_primes = []
    for num in range(start, end + 1):
        if not is_prime(num):
            non_primes.append(num)
    return non_primes

# Example usage:
start_range = int(input("Enter the start of the range: "))
end_range = int(input("Enter the end of the range: "))

non_prime_numbers = display_non_primes(start_range, end_range)
print("Non-prime numbers in the range:", non_prime_numbers)
