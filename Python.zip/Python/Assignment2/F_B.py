def access_characters(string):
    # Forward direction
    print("Characters in forward direction:")
    index = 0
    while index < len(string):
        print(string[index], end=" ")
        index += 1
    print()  # For a newline

    # Backward direction
    print("Characters in backward direction:")
    index = len(string) - 1
    while index >= 0:
        print(string[index], end=" ")
        index -= 1
    print()  # For a newline

# Example usage:
user_string = input("Enter a string: ")
access_characters(user_string)
