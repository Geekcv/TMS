def demonstrate_list_functions():
    sample_list = [1, 2, 3, 4, 5]

    print("Original list:", sample_list)

    # 1. append() - Add an element to the end of the list
    sample_list.append(6)
    print("After append(6):", sample_list)

    # 2. insert() - Insert an element at a specified position
    sample_list.insert(2, 'a')
    print("After insert(2, 'a'):", sample_list)

    # 3. remove() - Remove the first occurrence of an element
    sample_list.remove('a')
    print("After remove('a'):", sample_list)

    # 4. pop() - Remove and return an element at a specified position
    popped_element = sample_list.pop(3)
    print("After pop(3):", sample_list)
    print("Popped element:", popped_element)

    # Re-insert the popped element to avoid ValueError in subsequent operations
    sample_list.insert(3, popped_element)

    # 5. index() - Get the index of the first occurrence of an element
    index_of_4 = sample_list.index(4)
    print("Index of 4:", index_of_4)

    # 6. count() - Count the occurrences of an element in the list
    count_of_2 = sample_list.count(2)
    print("Count of 2:", count_of_2)

    # 7. sort() - Sort the list in ascending order
    sample_list.sort()
    print("After sort():", sample_list)

    # 8. reverse() - Reverse the order of elements in the list
    sample_list.reverse()
    print("After reverse():", sample_list)

    # 9. extend() - Extend the list by appending elements from another list
    sample_list.extend([7, 8, 9])
    print("After extend([7, 8, 9]):", sample_list)

    # 10. clear() - Remove all elements from the list
    sample_list.clear()
    print("After clear():", sample_list)

# Example usage:
demonstrate_list_functions()
