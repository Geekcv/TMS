def fibonacci_series(n):
    fib_sequence = []
    a, b = 0, 1
    for _ in range(n):
        fib_sequence.append(a)
        a, b = b, a + b
    return fib_sequence

# Example usage:
n = int(input("Enter the number of terms: "))
fib_sequence = fibonacci_series(n)
print("Fibonacci series:", fib_sequence)
