def demonstrate_string_functions():
    sample_string = "Hello, World!"

    print("Original string:", sample_string)

    # 1. len() - Get the length of the string
    print("Length of the string:", len(sample_string))

    # 2. lower() - Convert string to lowercase
    print("Lowercase:", sample_string.lower())

    # 3. upper() - Convert string to uppercase
    print("Uppercase:", sample_string.upper())

    # 4. title() - Convert string to title case
    print("Title case:", sample_string.title())

    # 5. capitalize() - Capitalize the first letter of the string
    print("Capitalized:", sample_string.capitalize())

    # 6. strip() - Remove leading and trailing whitespaces
    string_with_spaces = "   Hello, World!   "
    print("Stripped string:", string_with_spaces.strip())

    # 7. replace() - Replace a substring with another substring
    print("Replace 'World' with 'Python':", sample_string.replace("World", "Python"))

    # 8. find() - Find the first occurrence of a substring
    print("Find 'World':", sample_string.find("World"))

    # 9. count() - Count the occurrences of a substring
    print("Count of 'l':", sample_string.count("l"))

    # 10. split() - Split the string into a list
    print("Split string by ', ':", sample_string.split(", "))

    # 11. join() - Join a list of strings into a single string
    words = ["Hello", "World"]
    print("Join list into a string:", " ".join(words))

    # 12. isalpha() - Check if all characters in the string are alphabetic
    alphabet_string = "HelloWorld"
    print("Is alphabetic:", alphabet_string.isalpha())

    # 13. isdigit() - Check if all characters in the string are digits
    digit_string = "12345"
    print("Is digit:", digit_string.isdigit())

    # 14. isalnum() - Check if all characters in the string are alphanumeric
    alnum_string = "Hello123"
    print("Is alphanumeric:", alnum_string.isalnum())

    # 15. startswith() - Check if the string starts with a specified substring
    print("Starts with 'Hello':", sample_string.startswith("Hello"))

    # 16. endswith() - Check if the string ends with a specified substring
    print("Ends with 'World!':", sample_string.endswith("World!"))

# Example usage:
demonstrate_string_functions()
