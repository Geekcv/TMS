# # Integer
# int_var = 10
# print(f"Integer: {int_var}")
# print(f"Addition: {int_var + 5}")
# print(f"Multiplication: {int_var * 2}")
# print(f"Power: {int_var ** 2}")
# print()

# # Float
# float_var = 10.5
# print(f"Float: {float_var}")
# print(f"Addition: {float_var + 5.5}")
# print(f"Multiplication: {float_var * 2}")
# print(f"Power: {float_var ** 2}")
# print()

# # String
# str_var = "Hello"
# print(f"String: {str_var}")
# print(f"Uppercase: {str_var.upper()}")
# print(f"Lowercase: {str_var.lower()}")
# print(f"Concatenation: {str_var + ' World'}")
# print()

# # List
# list_var = [1, 2, 3, 4, 5]
# print(f"List: {list_var}")
# print(f"Append: {list_var.append(6)} and list is now {list_var}")
# print(f"Pop: {list_var.pop()} and list is now {list_var}")
# print(f"Length: {len(list_var)}")
# print()

# # Dictionary

# dict_var = {"name": "Alice", "age": 25, "city": "New York"}
# print(f"Dictionary: {dict_var}")
# print(f"Get 'name': {dict_var.get('name')}")
# print(f"Keys: {dict_var.keys()}")
# print(f"Values: {dict_var.values()}")
# print()





# int number
# num = 16
# print(f"this number is {num}")
# print(f"afeter add is {num + 5}")
# print(f"multiplay add is {num * 5}")
# print(f"afetr add is {num ** 5}")

# float
# num =16.3
# print("float number",num)

# string
# name ="abhishek"
# name ="""abhishek 12"""
# print("name is ",name)


# list
# mylist =[1,2,3,4,5]
# print("list is ",mylist)
# print("add elements in list ",mylist.append(6))
# print("after add list is ",mylist)
# print("remove elements in list ",mylist.remove(3))
# print("after remove list is ",mylist)
# mylist[2]=56
# print("list is ",mylist)

# for i in mylist:
#     print("list is ",i)


# tuple
mytuple =("abhi",12,"cv",78,9)
# print(mytuple)
# for i in mytuple:
#     print("in loop",i)
# mytuple=("abhishek","sudhakar")
print(mytuple.append("abc"))
print(mytuple)
