# Function to add two numbers
def add_two_numbers(num1, num2):
    return num1 + num2

# Ask the user for the first number
number1 = int(input("Enter the first number: "))

# Ask the user for the second number
number2 = int(input("Enter the second number: "))

# Calculate the sum
result = add_two_numbers(number1, number2)

# Print the result
print(f"The sum of {number1} and {number2} is {result}.")
