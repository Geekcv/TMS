# Ask the user for their name
user_name = input("Please enter your name: ")

# Print the greeting
print(f"Hello, {user_name}!")

