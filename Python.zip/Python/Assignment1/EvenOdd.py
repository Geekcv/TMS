# # Function to check if a number is even or odd
# def check_even_odd(number):
#     if number % 2 == 0:
#         return "even"
#     else:
#         return "odd"

# # Ask the user for a number
# number = int(input("Enter a number: "))

# # Determine if the number is even or odd
# result = check_even_odd(number)

# # Print the result
# print(f"The number {number} is {result}.")




def check_even_odd(number):
    if number %2==0:
        print(f"{number} is even")
    else:
        print(f"{number} is odd")

number = int(input("enter number"))
check_even_odd(number)

