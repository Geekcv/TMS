x = [4, 6, 8, 24, 12, 2]
largest_item = max(x)
print("Largest item in the list:", largest_item)
