def reverse_string(s):
    return s[::-1]

# Example usage:
sample_string = "your name"
reversed_string = reverse_string(sample_string)
print("Reversed string:", reversed_string)
