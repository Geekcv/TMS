def unique_elements(input_list):
    unique_list = list(set(input_list))
    return unique_list

# Example usage:
input_list = [2, 5, 8, 2, 2, 3, 2, 5, 6]
unique_list = unique_elements(input_list)
print("Unique elements in the list:", unique_list)
