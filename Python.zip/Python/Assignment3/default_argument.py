def function_with_default_argument(name="User"):
    print(f"Hello, {name}!")

# Example usage:
function_with_default_argument()
function_with_default_argument("Alice")
