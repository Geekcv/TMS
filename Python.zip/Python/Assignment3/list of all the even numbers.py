even_numbers = [num for num in range(4, 31) if num % 2 == 0]
print("Even numbers between 4 and 30:", even_numbers)
