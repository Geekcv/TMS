def variable_length_function(*args):
    for arg in args:
        print(arg)

# Example usage:
variable_length_function(1, 2, 3)
variable_length_function('a', 'b', 'c')
