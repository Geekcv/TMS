def divide_lists(list1, list2):
    results = []
    for i in range(len(list1)):
        try:
            result = list1[i] / list2[i]
            results.append(result)
        except ZeroDivisionError:
            print(f"Error: Division by zero at index {i}")
            results.append(None)
        except IndexError:
            print(f"Error: Index out of bound at index {i}")
            results.append(None)
    return results

# Example usage:
list1 = [10, 20, 30, 40]
list2 = [2, 0, 5]

results = divide_lists(list1, list2)
print("Division results:", results)
