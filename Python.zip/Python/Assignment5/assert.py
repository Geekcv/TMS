def factorial(n):
    assert n >= 0, "Factorial is not defined for negative numbers."
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

# Example usage:
try:
    num = int(input("Enter a number to find its factorial: "))
    print(f"Factorial of {num} is {factorial(num)}")
except AssertionError as e:
    print(e)
