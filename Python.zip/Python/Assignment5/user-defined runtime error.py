def generate_runtime_error():
    user_input = int(input("Enter a number: "))
    if user_input < 0:
        raise ValueError("This is a user-defined runtime error: Negative numbers are not allowed.")
    print("You entered a valid number.")

# Example usage:
try:
    generate_runtime_error()
except ValueError as e:
    print(e)
