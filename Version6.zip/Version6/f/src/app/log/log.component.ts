import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { AuthService } from '../servies/auth.service';



interface Client {
  row_id: string; // Client ID as a string
  name: string;
  description: string;
}

interface worklogs {
  description: string;
  date: any;
  updatedBy:any;
  tags:any;
  client_id: string;
  row_id: string;
  user_id: string;
}

@Component({
  selector: 'app-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.css']
})
export class LogComponent {

  clientId!: string | null; // Holds the client ID from the route
  projectId!: string | null; // Holds the project  ID from the route

  client!: Client; // Holds the client details

  // Simulated data source (replace with actual service)
  clients: Client[] = [];
  worklogs: worklogs[] = []; // Array of password


  workLogs = [{ description: 'Work log 1', date: '2025-01-12', updatedBy: 'Ramesh', tags: 'Pending',showFullDescription: false }];


  isWorkLogDialogVisible = false;


  currentWorkLog: any = {};
  editIndex = -1;


  tags: any[] = [
    { label: 'Urgent', value: 'urgent' },
    { label: 'Normal', value: 'normal' },
    { label: 'Low Priority', value: 'low' },
    // Add more tag options as needed...
  ];



  toggleDescription(log: any) {
    log.showFullDescription = !log.showFullDescription;
  }


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService
  ) {}
    




  async ngOnInit(): Promise<void> {
    this.clientId = this.route.snapshot.paramMap.get('clientId');
    console.log("clientid",this.clientId)
    this.projectId = this.route.snapshot.paramMap.get('projectId');
    console.log("projectId",this.projectId)

    if (!this.clientId) {
      console.error('Client ID not provided');
      this.router.navigate(['/']); // Redirect if ID is missing
      return;
    }

    console.log('Client ID:', this.clientId);

    await this.fetchClients(); // Fetch client data
    await this.fetchworklogs(); // Fetch links for the client

    this.loadClientData(this.clientId); // Load client data
  }


  async fetchClients(): Promise<void> {
    try {
      const response = await this.apiController.fetchClient();
      this.clients = response.data || []; // Ensure `data` exists in the API response
    } catch (error) {
      console.error('Error fetching clients:', error);
    }
  }


  loadClientData(id: string): void {
    const client = this.clients.find((client) => client.row_id === id);
    if (client) {
      this.client = client;
      console.log('Found client:', this.client);
    } else {
      console.error(`Client with ID "${id}" not found`);
      // this.router.navigate(['/show-client']); // Redirect if client not found
    }
  }


  async fetchworklogs(): Promise<void> {
    try {
      const response = await this.apiController.fetchlogs(this.projectId);
      console.log('Response from fetchc logs:----------', response);

      // Process the response to extract links
      this.workLogs = response?.data?.map((item: any) => ({
        ...item.logs, // Extract the `links` object properties
        client_id: item.client_id, // Add the client_id
        row_id: item.row_id, // Add the row_id
        user_id: item.user_id, // Add the user_id
      })) || []; // Default to an empty array if `data` or `links` is undefined

      console.log('Processed logs for client:======', this.workLogs);
    } catch (error) {
      console.error('Error fetching logs:', error);
      this.workLogs = []; // Default to an empty array in case of an error
    }
  }
  

  openWorkLogDialog() {
    this.currentWorkLog = {};
    this.editIndex = -1;
    this.isWorkLogDialogVisible = true;
  }


  editWorkLog(workLog: any, index: number) {
    this.currentWorkLog = { ...workLog };
    this.editIndex = index;
    this.isWorkLogDialogVisible = true;
  }

  async saveWorkLog() {
    
  
    try {
      const userId = this.authService.getUserId();
    var project_id = this.projectId

      const logsData = {
        logs: this.currentWorkLog,
        userId,
        client_id: this.clientId,
        project_id:project_id,
        row_id: this.currentWorkLog.row_id, // Ensure the row_id is included
      };
  
      // Log the data to make sure it's correct
      console.log('logs data being sent:', logsData);
  
      if (this.editIndex >= 0) {
        // Edit existing link
        this.workLogs[this.editIndex] = this.currentWorkLog;
      } else {
        // Add new link
        this.workLogs.push(this.currentWorkLog);
      }
  
      // Save links to the backend
      const response = await this.apiController.createlogs(logsData);
      console.log('logsData saved successfully:', response);
    } catch (error) {
      console.error('logsData to save credential:', error);
    } finally {
      this.closeWorkLogDialog();
    }
  }


  closeWorkLogDialog() {
    this.isWorkLogDialogVisible = false;
  }
}
