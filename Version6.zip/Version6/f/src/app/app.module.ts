import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';


import { InputTextModule } from 'primeng/inputtext'; // Import InputTextModule
import { PasswordModule } from 'primeng/password';   // Import PasswordModule
import { ButtonModule } from 'primeng/button';
import { ClientAddComponent } from './client-add/client-add.component';       // Import ButtonModule

import { CardModule } from 'primeng/card';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FileUploadModule } from 'primeng/fileupload';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';


import { ClientShowComponent } from './client-show/client-show.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { ClientDetailsComponent } from './client-details/client-details.component';
import { NavbarComponent } from './navbar/navbar.component';
import { MenubarModule } from 'primeng/menubar';
import { ProjectdetailsComponent } from './projectdetails/projectdetails.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { ShowProjectComponent } from './show-project/show-project.component';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { ProjectDetailsComponent } from './project-details/project-details.component';
import { CredentialsComponent } from './credentials/credentials.component';
import { LogComponent } from './log/log.component';
import { FileOwnComponent } from './file-own/file-own.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ClientAddComponent,
    ClientShowComponent,
    EditClientComponent,
    ClientDetailsComponent,
    NavbarComponent,
    ProjectdetailsComponent,
    AddProjectComponent,
    ShowProjectComponent,
    ProjectDetailsComponent,
    CredentialsComponent,
    LogComponent,
    FileOwnComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
    FormsModule,
    ReactiveFormsModule,


    InputTextModule,
    PasswordModule,
    ButtonModule,
    CardModule,
    TableModule,
    DialogModule,
    BrowserAnimationsModule,
    FileUploadModule,
    MenubarModule,
    CalendarModule,
    DropdownModule,
    ToastModule

  ],
  providers: [MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
