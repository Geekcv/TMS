import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';

@Component({
  selector: 'app-managers',
  templateUrl: './managers.component.html',
  styleUrls: ['./managers.component.css']
})

export class ManagersComponent {
  customers = [
    { name: 'Customer 1', products: ['Product A', 'Product B'], sizes: ['Small', 'Medium'] },
    { name: 'Customer 2', products: ['Product C', 'Product D'], sizes: ['Medium', 'Large'] },
    { name: 'Customer 3', products: ['Product E', 'Product F'], sizes: ['Small', 'Large'] }
  ];
  
  selectedCustomer: { name: string, products: string[], sizes: string[] } | null = null;
  tableData: { product: string, size: string }[] = [];

  fetchTableData() {
    if (this.selectedCustomer) {
      this.tableData = [
        { product: '', size: '' },
        { product: '', size: '' },
        { product: '', size: '' }
      ];
    }
  }

  onProductChange(rowIndex: number, event: Event) {
    const target = event.target as HTMLSelectElement;
    if (target) {
      const newProduct = target.value;
      this.tableData[rowIndex].product = newProduct;
    }
  }

  onSizeChange(rowIndex: number, event: Event) {
    const target = event.target as HTMLSelectElement;
    if (target) {
      const newSize = target.value;
      this.tableData[rowIndex].size = newSize;
    }
  }

  onCustomerChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    const customerName = target.value;

    this.selectedCustomer = this.customers.find(c => c.name === customerName) || null;
  }

  addRow() {
    if (this.selectedCustomer) {
      this.tableData.push({ product: '', size: '' });
    }
  }


}