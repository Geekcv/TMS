import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { Router } from '@angular/router';
import { AuthService } from '../servies/auth.service';  // Import AuthService

@Component({
  selector: 'app-client-add',
  templateUrl: './client-add.component.html',
  styleUrls: ['./client-add.component.css']
})
export class ClientAddComponent {
  clientForm: FormGroup;
  loading: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private authService: AuthService  // Inject AuthService
  ) {
    this.clientForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onEdit(){

  }

  async onSubmit() {
    if (this.clientForm.valid) {
      this.loading = true; // Show loading spinner
      this.errorMessage = ''; // Reset error message
      this.successMessage = ''; // Reset success message

      try {
        const userId = this.authService.getUserId(); // Get userId from AuthService
        if (!userId) {
          this.errorMessage = 'User not authenticated!';
          return;
        }

        const clientData = { 
          ...this.clientForm.value,
          userId: userId // Include userId in the client data
        };

        const resp = await this.Apicontroller.createClient(clientData);

        if (resp.status == 0) {
          this.successMessage = 'Client added successfully!';
          setTimeout(() => {
            this.router.navigate(['/show-client']);
          }, 1000);
        } else {
          this.errorMessage = 'Failed to add client. Please try again.';
        }
      } catch (error) {
        console.error('Error:', error);
        this.errorMessage = 'An error occurred. Please try again later.';
      } finally {
        this.loading = false; // Hide loading spinner
      }
    } else {
      this.errorMessage = 'Please fill in all required fields.';
    }
  }
}
