import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApicontrollerService } from '../controller/apicontroller.service';

interface Client {
  row_id: string; // Client ID as a string
  name: string;
  description: string;
}

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.css']
})
export class EditClientComponent implements OnInit {
  clientForm!: FormGroup;
  clientId!: string | null; // Holds the client ID from the route
  clients: Client[] = []; // Clients fetched from the API

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router,
    private apiController: ApicontrollerService // Corrected service casing
  ) {
    // Initialize the form with validation rules
    this.clientForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  async ngOnInit(): Promise<void> {
    // Get the client ID from the route
    this.clientId = this.route.snapshot.paramMap.get('id');
  
    if (!this.clientId) {
      console.error('Client ID not provided');
      this.router.navigate(['/']); // Redirect if ID is missing
      return;
    }
  
    console.log('Client ID:', this.clientId);
  
    // Fetch clients and load the form data
    await this.fetchClients();
    this.loadClientData(this.clientId);
  }
  

  async fetchClients(): Promise<void> {
    try {
      const response = await this.apiController.fetchClient();
      this.clients = response.data; // Assuming the API response includes a `data` property
    } catch (error) {
      console.error('Error fetching clients:', error);
      // Handle error, e.g., show an error message or redirect
    }
  }

  loadClientData(id: string): void {
    // Find the client by row_id
    const client = this.clients.find(client => client.row_id === id);

    if (client) {
      console.log('Found client:', client);
      // Populate the form with existing client data
      this.clientForm.patchValue(client);
    } else {
      console.error(`Client with ID "${id}" not found`);
      // Redirect if the client is not found
      this.router.navigate(['/show-client']);
    }
  }

  async onSubmit(): Promise<void> {
    if (this.clientForm.valid) {
      try {
        const updatedClientData = { row_id: this.clientId, ...this.clientForm.value };
        console.log('Updated Client Data:', updatedClientData);

        // Call the API to update the client data
        const response = await this.apiController.createClient(updatedClientData);

        if (response.status == 0) {
          console.log('Client updated successfully');
          // Navigate to the client list after a successful update
          this.router.navigate(['/show-client']);
        } else {
          console.error('Failed to update client:', response.message);
        }
      } catch (error) {
        console.error('Error updating client:', error);
      }
    } else {
      console.error('Form is invalid');
    }
  }
}
