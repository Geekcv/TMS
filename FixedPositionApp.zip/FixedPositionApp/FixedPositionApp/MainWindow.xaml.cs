﻿using System;
using System.Windows;

namespace FixedPositionApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Set the window position dynamically to the bottom-right corner
            SetBottomRightPosition();
        }

        private void SetBottomRightPosition()
        {
            // Get screen dimensions (primary monitor)
            double screenWidth = SystemParameters.WorkArea.Width;  // Usable screen width
            double screenHeight = SystemParameters.WorkArea.Height; // Usable screen height

            // Calculate bottom-right position
            this.Left = screenWidth - this.Width; // Align window's right edge with screen's right edge
            this.Top = screenHeight - this.Height; // Align window's bottom edge with screen's bottom edge
        }

        private void CurrentScreenButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is the current screen button!", "Info");
        }
    }
}
