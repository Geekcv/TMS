import ActivatedUsers from "../models/ActivatedUsers.js";

// Create a new activated user record
export const createActivatedUser = async (req, res) => {
  try {
    const { activation_plan_id, user_id, organisation_id } = req.body;
    const activatedUser = await ActivatedUsers.create({
      activation_plan_id,
      user_id,
      organisation_id,
    });
    res.status(201).json(activatedUser);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all activated users
export const getActivatedUsers = async (req, res) => {
  try {
    const activatedUsers = await ActivatedUsers.findAll();
    res.status(200).json(activatedUsers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get an activated user by ID
export const getActivatedUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const activatedUser = await ActivatedUsers.findByPk(id);
    if (activatedUser) {
      res.status(200).json(activatedUser);
    } else {
      res.status(404).json({ error: "Activated User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update an activated user record
export const updateActivatedUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { activation_plan_id, user_id, organisation_id } = req.body;
    const activatedUser = await ActivatedUsers.findByPk(id);
    if (activatedUser) {
      activatedUser.activation_plan_id = activation_plan_id;
      activatedUser.user_id = user_id;
      activatedUser.organisation_id = organisation_id;
      await activatedUser.save();
      res.status(200).json(activatedUser);
    } else {
      res.status(404).json({ error: "Activated User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete an activated user record
export const deleteActivatedUser = async (req, res) => {
  try {
    const { id } = req.params;
    const activatedUser = await ActivatedUsers.findByPk(id);
    if (activatedUser) {
      await activatedUser.destroy();
      res.status(200).json({ message: "Activated User deleted successfully" });
    } else {
      res.status(404).json({ error: "Activated User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
