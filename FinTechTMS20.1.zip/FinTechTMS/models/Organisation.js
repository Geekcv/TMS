import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";

const Organisation = sequelize.define("Organisation", {
  organisation_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  organisation_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  activation_plan_id: {
    type: DataTypes.INTEGER,
    references: {
      model: "Subscription_Plans",
      key: "row_id",
    },
  },
  activation_status: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  expiry_date: {
    type: DataTypes.DATE,
  },
});

export default Organisation;
