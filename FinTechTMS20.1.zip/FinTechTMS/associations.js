// associations.js

import Tasks from "./models/Tasks.js";
import Comments from "./models/Comments.js";
import TaskAttachments from "./models/TaskAttachments.js";
import Users from "./models/Users.js";

// Define associations

// Tasks can have many comments
Tasks.hasMany(Comments, { foreignKey: "task_id", onDelete: "CASCADE" });
Comments.belongsTo(Tasks, { foreignKey: "task_id" });

// Tasks can have many attachments
Tasks.hasMany(TaskAttachments, { foreignKey: "task_id", onDelete: "CASCADE" });
TaskAttachments.belongsTo(Tasks, { foreignKey: "task_id" });

// A user can create many comments
Users.hasMany(Comments, { foreignKey: "user_id", onDelete: "CASCADE" });
Comments.belongsTo(Users, { foreignKey: "user_id" });

// A user can create many tasks
Users.hasMany(Tasks, { foreignKey: "user_id", onDelete: "CASCADE" });
Tasks.belongsTo(Users, { foreignKey: "user_id" });

export default function setAssociations() {
  // You can sync your associations here if needed, or keep them separate.
  console.log("Associations are set.");
}
