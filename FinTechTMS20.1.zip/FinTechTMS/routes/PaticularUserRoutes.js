import express from "express";
import { LoginUser } from "../controllers/LoginUserContoller.js";

const router = express.Router();

router.post("/Login", LoginUser);

export default router;
