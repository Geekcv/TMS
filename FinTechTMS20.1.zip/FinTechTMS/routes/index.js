import express from "express";
const app = express();

import organisationRoutes from "./organisationRoutes.js";
import subscriptionPlansRoutes from "./subscriptionPlansRoutes.js";
import userRoutes from "./userRoutes.js";
import taskRoutes from "./taskRoutes.js";
import activatedUsersRoutes from "./activatedUsersRoutes.js";
import taskAssigneeRoutes from "./taskAssigneeRoutes.js";
import LoginUser from "./PaticularUserRoutes.js";

const router = express.Router();

router.use("/v1", organisationRoutes);
router.use("/v1", subscriptionPlansRoutes);
router.use("/v1", userRoutes);
router.use("/v1", taskRoutes);
router.use("/v1", activatedUsersRoutes);
router.use("/v1", taskAssigneeRoutes);
router.use("/v1", LoginUser);

export default router;
