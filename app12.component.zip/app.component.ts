import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  type: string = 'System Based Software | Cloud';
  links: string[] = ['Invoice Reports'];

  isEditingType: boolean = false;
  isEditingLink: boolean = false;
  isAddingLink: boolean = false;

  currentType: string = '';
  currentLink: string = '';
  editingLinkIndex: number | null = null;

  // Edit Type Popup
  openEditTypePopup() {
    this.currentType = this.type;
    this.isEditingType = true;
  }

  saveType() {
    this.type = this.currentType.trim();
    this.closeTypePopup();
  }

  closeTypePopup() {
    this.isEditingType = false;
    this.currentType = '';
  }

  // Edit/Add Link Popup
  openEditLinkPopup(index: number) {
    this.editingLinkIndex = index;
    this.currentLink = this.links[index];
    this.isEditingLink = true;
  }

  openAddLinkPopup() {
    this.currentLink = '';
    this.isAddingLink = true;
  }

  saveLink() {
    if (this.isAddingLink) {
      if (this.currentLink.trim()) {
        this.links.push(this.currentLink);
      }
    } else if (this.isEditingLink && this.editingLinkIndex !== null) {
      this.links[this.editingLinkIndex] = this.currentLink.trim();
    }
    this.closeLinkPopup();
  }

  closeLinkPopup() {
    this.isAddingLink = false;
    this.isEditingLink = false;
    this.editingLinkIndex = null;
    this.currentLink = '';
  }


}
