import { Component, OnInit } from '@angular/core';

interface   Product {
  id: string;
  name: string;
  size:string;
  category:string;
  price:string;
}


@Component({
  selector: 'app-size',
  templateUrl: './size.component.html',
  styleUrls: ['./size.component.css']
})
export class SizeComponent implements OnInit  {


    Product: Product[] | undefined;
    selectedProduct: Product | undefined;

    
    size:Product[]| undefined    
    selectedsizeclass1:[]| undefined

    selectedsizeclass2:[]|undefined

    selectedsizeclass3:[]|undefined
    selectedsizeclass4:[]|undefined


    products!: Product[];

    ngOnInit() {
        this.Product = [
            { id:'10' , name: 'New York', category: 'shirt',size:'xl' ,price:'1200'},
            { id:'20' , name: 'Rome', category: 't shirt',size:'l' ,price:'2300'},
            { id:'25' , name: 'London', category: 'pants',size:'2xl' ,price:'400'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'100' , name: 'Paris', category: 'accessories' ,size:'S',price:'30000'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},
            { id:'50' , name: 'Istanbul', category: 'cap' ,size:'M',price:'900'},

        ];
        this.products = this.Product;

         

    } 




    
}
