﻿using System;
using System.IO;
using System.Windows;

namespace FileUpdater
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void UpdateFilesButton_Click(object sender, RoutedEventArgs e)
        {
            // Define source and destination directories
            string sourceFolder = @"E:\Fintech_IT\Git_upload\CURD_NO_DB";
            string destinationFolder = @"E:\Fintech_IT\TMS\nodeJS";

            try
            {
                // Call the method to update files
                UpdateFilesAndFolders(sourceFolder, destinationFolder);

                MessageBox.Show("Files and folders updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateFilesAndFolders(string sourceFolder, string destinationFolder)
        {
            // Check if the source folder exists
            if (!Directory.Exists(sourceFolder))
                throw new DirectoryNotFoundException($"Source folder not found: {sourceFolder}");

            // Ensure the destination folder exists
            if (!Directory.Exists(destinationFolder))
                Directory.CreateDirectory(destinationFolder);

            // Get all files in the source folder
            foreach (var filePath in Directory.GetFiles(sourceFolder))
            {
                string fileName = Path.GetFileName(filePath);
                string destFilePath = Path.Combine(destinationFolder, fileName);

                // Copy file (overwrite if exists)
                File.Copy(filePath, destFilePath, true);
            }

            // Recursively handle subdirectories
            foreach (var subFolder in Directory.GetDirectories(sourceFolder))
            {
                string folderName = Path.GetFileName(subFolder);
                string destSubFolder = Path.Combine(destinationFolder, folderName);

                // Recursive call
                UpdateFilesAndFolders(subFolder, destSubFolder);
            }
        }
    }
}
