const express = require("express");
const app = express();
// const fileUpload = require('express-fileupload');
require("dotenv").config();
const path = require("path");
const bodyParser = require("body-parser");
const WhatsAppSDK = require('./public/lib/whatsappCloudApi/whatsappCloudApi.js');
    const axios = require('axios');

const cors = require("cors");
const common = require("./public/lib/common.js");
const useragent = require("express-useragent");
const PORT = process.env.SERVER_PORT || 3000;
const libFunc = require("./public/lib/functions.js");
const queries = require("./public/lib/connect_db/queries.js");
const fs = require("fs")





app.use(bodyParser.json({ verify: (req, _res, buf) => { req.rawBody = buf; } }));

// require("./public/lib/google_auth/passport.js");

app.use(cors());

app.use(useragent.express());
// app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded form data
app.set("trust proxy", true); // IMPORTANT if using behind proxy

const session = require("express-session");
const passport = require("passport");
// const { default: axios } = require("axios");

app.use(
  session({
    secret: "aiims_research_jwt_secret729@",
    resave: false,
    saveUninitialized: true,
  })
);

app.use(passport.initialize());
app.use(passport.session());


// Required session handlers
passport.serializeUser((user, done) => {
  done(null, user); // Store user object (or just user.id if preferred)
});

passport.deserializeUser((user, done) => {
  done(null, user); // Retrieve full user (or lookup by ID)
});

app.use(bodyParser.json({ limit: "100mb", type: "application/json" }));
app.use(
  bodyParser.urlencoded({
    limit: "5000mb",
    extended: true,
    parameterLimit: 50000,
  })
);

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
app.use("/common", common);
app.use("/", express.static("public"));
app.use("/node_modules", express.static(path.join(__dirname, "node_modules")));
app.use(
  "/bower_components",
  express.static(path.join(__dirname, "bower_components"))
);

//app.use(express.static(path.join(__dirname, "public/frontend")));

// app.get('/*', (req,res)=>{
//     res.sendFile(path.join(__dirname, 'public/frontend/index.html'))
// })

app.listen(PORT, function () {
  console.log("app is listening on port " + PORT);
});




const wa = new WhatsAppSDK({
  accessToken: process.env.WHATSAPP_TOKEN, // Long-lived token from Meta
  phoneNumberId: process.env.WHATSAPP_PHONE_ID,
  wabaId: process.env.WABA_ID,
  verifyToken: process.env.WEBHOOK_VERIFY_TOKEN, // used for webhook verification
  appSecret: process.env.APP_SECRET, // used to verify webhook signatures

 
});


// console.log("process.env.WHATSAPP_TOKEN :",process.env.WHATSAPP_TOKEN)
// console.log("process.env.WHATSAPP_PHONE_NUMBER_ID :",process.env.WHATSAPP_PHONE_ID)
// console.log("process.env.WHATSAPP_WABA_ID:",process.env.WABA_ID)
// console.log("process.env.WHATSAPP_VERIFY_TOKEN",process.env.WEBHOOK_VERIFY_TOKEN)
// console.log("process.env.WHATSAPP_APP_SECRET",process.env.APP_SECRET)



// ================== send normal message 
async function sendmessagewa(){
await wa.sendText({
   to: '917297028304',  // receiver phone number in international format
    // to: '919413569917', 
  //   body: 'good afternoon ',
  //   media: {
  //   type: "image",
  //   url: "2393582571037789",
  //   caption: "This is an image"
  // }
    body: 'good afternoon ',
    image: { id: "2074469829753490" }


  });
}

// sendmessagewa()


async function fetchMeduafile() {

// const mediaResp = await wa.uploadMedia(
//   process.env.WHATSAPP_PHONE_ID,
//   'video',
//   fs.readFileSync('D:\\WhatsApp Platform\\acube24-wa\\public\\assets\\uploads\\videos\\1760078294894_20251010-0444-02.5308244.mp4'),
//   'D:\\WhatsApp Platform\\acube24-wa\\public\\assets\\uploads\\videos\\1760078294894_20251010-0444-02.5308244.mp4'
// );

// // console.log("mediaResp",mediaResp);

// await wa.sendMessageRaw(process.env.WHATSAPP_PHONE_ID, {
//   messaging_product: 'whatsapp',
//   to: '917297028304',
//   type: 'video',
//   video: { id: mediaResp.id }  // MUST be from your WABA
// });

// const mediaBuffer = await wa.downloadMedia(1329792775462611);
// fs.writeFileSync('downloaded_cat.jpg', mediaBuffer);

const mediaInfo = await wa.getMediaInfo(1495209658364156);
console.log("mediaInfo",mediaInfo);

}


// fetchMeduafile()


//  =======================  send tempalted message 
async function sendTemplatewa() {
  await wa.sendTemplate({
  to: '917297028304',
  // to:'919413569917',
  template: 'order_update_customer',  // your template name
  language: 'en_US',
  bodyParams: ['abhishek','12345'] // optional, for placeholders
});
}

// sendTemplatewa()








app.get('/', (req, res) => {
  // wa.verifyWebhookChallenge(req.query, res);
  console.log("get api server start ")
});









// ======================= Webhooks (Receiving Messages & Status)


// GET /webhook (verification)
app.get('/webhook', (req, res) => {
  console.log("wee")
  wa.verifyWebhookChallenge(req.query, res);
});

// POST /webhook (events)
// app.post('/webhook', async (req, res) => {
//   console.log("my webhook post")
//   const ok = wa.verifyWebhookSignature({
//     rawBody: req.rawBody,
//     signatureHeader: req.get('X-Hub-Signature-256')
//   });
//   console.log("ok:",ok)
//   if (!ok) return res.sendStatus(403);
//   wa.processWebhook(req.body);
//   res.sendStatus(200);
// });

// Listen to events 
wa.on('message', async (msg, raw) => {
  // simple echo on text
  if (msg.type === 'text' && msg.from) {
    await wa.sendText({ to: msg.from, body: `You said: ${msg.text.body}` });
  }
});

wa.on("status", (status, fullPayload) => {
  console.log("Delivery status:", status.status);
});


 app.post("/webhook", async (req, res) => {
    console.log("req--------------->",req.body)
    res.sendStatus(200);
  try {
    const messages = req.body.entry?.[0]?.changes?.[0]?.value?.messages;
    console.log("data ------>", req.body.entry?.[0]?.changes?.[0])

    const others_data = JSON.stringify(req.body.entry?.[0]?.changes?.[0]);

    
    if (messages) {
      for (const msg of messages) {
        const phone = msg.from;
        const body = msg.text?.body || "";
        console.log(" Incoming:", phone, body);

        let row_id = libFunc.randomid()
       
        const resp =   await queries.customQuery(
        `INSERT INTO wap.messages (row_id,phone, direction, body,others_data) VALUES ('${row_id}','${phone}','in','${body}','${others_data}')`);
       
        console.log("response--->",resp)
      }
    }
  } catch (err) {
    console.error("Webhook error:", err.message);
  }
});






// =================== Business Management APIs
async function businessManagementAPI() {

  // get media 
   const res = await wa._request(`media/2393562431039803`,{ method: 'GET' });
  console.log('Media info:', res);1

// Get Business Info
// const business = await wa.getBusiness(process.env.WABA_ID);
// console.log("Get Business Info--->",business);

// // Get WABA Details
// const waba = await wa.getWABA();
// console.log("Get WABA Details---------->",waba);

// // Get Phone Numbers
// const numbers = await wa.getPhoneNumbers();
// console.log("Get Phone Numbers----------->",numbers);

  
}

// businessManagementAPI()


//===================== Template Management APIs
async function TemplateManagementAPI() {

  // List Templates
const templates = await wa.listTemplates();
console.log("Templates:", templates.data);

// Create Template

// await wa.createTemplate(process.env.WABA_ID, {
//   name: "test2",
//   category: "MARKETING",
//   language: "en_US",
//   components: [
//     {
//       type: "BODY",
//       text: "Hello {{1}}, your order {{2}} is confirmed!"     
//     }
//   ]
// });




// const templateSpec = {
//   name: "order_update_customer1",
//   category: "MARKETING",
//   language: "en_US",
//   components: [
//     {
//       type: "HEADER",
//       format: "TEXT",
//       text: "Order Update"
//     },
//     {
//       type: "BODY",
//        text: "Hi {{1}}, your order {{2}} is confirmed and will be delivered soon."
//     },
//     {
//       type: "FOOTER",
//       text: "Thank you for shopping with us!"
//     }
//   ]
// };

// const result = await wa.createTemplate(process.env.WABA_ID, templateSpec);
// console.log("Template created:", result);



// const marketingTemplate = {
//   name: "diwali_offer_promo",
//   category: "MARKETING",
//   language: "en_US",
//   components: [
//     {
//       type: "HEADER",
//       format: "TEXT",
//       text: " Special Offer!"
//     },
//     {
//       type: "BODY",
//       text: "Hi {{1}}, enjoy {{2}}% off on all products this Diwali! Offer valid till {{3}}.",
//       example: {
//         body_text: [
//           ["Abhishek", "25", "Oct 15, 2025"]
//         ]
//       }
//     },
//     {
//       type: "FOOTER",
//       text: "Tap below to shop now "
//     },
//     {
//       type: "BUTTONS",
//       buttons: [
//         {
//           type: "URL",
//           text: "Shop Now",
//           url: "https://fintechshop.com/offer"
//         }
//       ]
//     }
//   ]
// };

// const result = await wa.createTemplate(process.env.WABA_ID, marketingTemplate);
// console.log(" Template created:", result);





// Delete Template
// await wa.deleteTemplate(process.env.WABA_ID, "order_update");





// const mediaResp = await wa.uploadMedia(
//   process.env.WHATSAPP_PHONE_ID,
//   'image',
//   fs.readFileSync('D:\\WhatsApp Platform\\acube24-wa\\public\\assets\\uploads\\images\\1760154114669_logo-message123.png'),
//   'D:\\WhatsApp Platform\\acube24-wa\\public\\assets\\uploads\\images\\1760154114669_logo-message123.png'
// );

// console.log("Uploaded media ID:", mediaResp.id);

// const templateSpec = {
//   name: "hj",
//   category: "MARKETING",
//   language: "en_US",
//   components: [
//     {
//       type: "HEADER",
//       format: "IMAGE", // Uppercase required!
//       example: {
//         header_handle: [mediaResp.id]
//       }
//     },
//     {
//       type: "BODY",
//       text: "Hi your order is confirmed and will be delivered soon."
//     },
//     {
//       type: "FOOTER",
//       text: "Thank you for shopping with us!"
//     }
//   ]
// };

// const result = await wa.createTemplate(process.env.WABA_ID, templateSpec);
// console.log("Template created:", result);



}


// TemplateManagementAPI()



async function updateTemplate() {
  const newTemplateSpec = {
    name: 'order_update12',       // New template name
    category: 'MARKETING',  // Template category
    language: 'en_US',          // Language code
    components: [
      {
        type: 'header',
        format: 'TEXT',
        text: 'Order Update'
      },
      {
        type: 'body',
        text: 'Hello your order has been shipped!'
      }
    ],
    allow_category_change: false
  };
  
  try {
    const result = await wa.editTemplate(
      process.env.WABA_ID,     // WABA ID
      'no_heder_footer', // Existing template name you want to edit
      newTemplateSpec
    );

    console.log('Template updated successfully:', result);
  } catch (err) {
    console.error('Error updating template:', err.message);
  }
}

// updateTemplate();







async function run() {
  const campaign = await wa.createCampaign(undefined, {
    name: 'Promo October',
    campaign_type: 'TRIGGERED', // ✅ use TRIGGERED for immediate send
    message_template: {
      name: 'simple_700',
      language: { code: 'en_US' },
      components: [{ type: 'body', parameters: [{ type: 'text', text: 'Hello!' }] }]
    },
    recipients: ['917297028304']
  });

  console.log('Campaign created:', campaign);

  // TRIGGERED campaigns are sent immediately, no need to call sendCampaign separately
  console.log('Campaign sent immediately!');
}

// run().catch(console.error);








































app.get('/auth/facebook/url', (req, res) => {
  const orgId = req.query.orgId;
  const client_id = process.env.client_id;
  const redirect_uri = `${process.env.BACKEND_URL}/auth/facebook/callback?orgId=${orgId}`;
  const scope = encodeURIComponent('whatsapp_business_management,business_management');
  const url = `https://www.facebook.com/v20.0/dialog/oauth?client_id=${client_id}&redirect_uri=${encodeURIComponent(redirect_uri)}&scope=${scope}&response_type=code`;
  console.log("orgId: ",orgId, "client_id:", client_id,"redirect_uri:",redirect_uri,"scope:",scope,"url:",url)
  // res.json({ url });
});

// app.get('/auth/facebook/callback', async (req, res) => {
//   const { code } = req.query;
//   if (!code) return res.status(400).json({ error: 'Missing code' });

//   const tokenResponse = await fetch(
//     `https://graph.facebook.com/v18.0/oauth/access_token?client_id=${process.env.META_APP_ID}&client_secret=${process.env.APP_SECRET}&redirect_uri=${process.env.META_REDIRECT_URI}&code=${code}`
//   );

//   const tokenData = await tokenResponse.json();
//   console.log("LOCAL TOKEN RESPONSE:", tokenData);


//   // Use SDK or Graph to fetch business -> WABA -> phone numbers
//   const wa = new WhatsAppSDK({ tokenData });
//   // If you need business id explicitly, call getBusiness on a stored business id.
//   // Often you call "me?fields=businesses" or call Business Manager endpoints
//   // Example: get owned WABAs via Business Manager: replace with appropriate call
//   const owned = await wa.getOwnedWABAs(); // may need businessId param if you have one
//   const wabaId = owned?.data?.[0]?.id;

//   const phones = await wa.getPhoneNumbers(wabaId);
//   const phoneNumberId = phones?.data?.[0]?.id;


//   console.log("wa",wa,"owned",owned,"wabaid",wabaId,"phone",phones,"phoneNumberId",phoneNumberId)

//   // Save to local DB (SQLite or Postgres)
// });

// ---------------------

app.get('/auth/facebook/callback', async (req, res) => {
  const { code, state:orgId} = req.query;
  console.log("code--",code,"orgId", orgId)
  if (!code) return res.status(400).json({ error: 'Missing code' });

  //  Exchange code for short-lived token
  const tokenResponse = await fetch(
    `https://graph.facebook.com/v20.0/oauth/access_token?client_id=${process.env.META_APP_ID}&client_secret=${process.env.APP_SECRET}&redirect_uri=${process.env.META_REDIRECT_URI}&code=${code}`
  );
  const tokenData = await tokenResponse.json();
  const shortToken = tokenData.access_token;

  console.log("shortToken:--",shortToken)

  //  Exchange for long-lived token
  const longTokenRes = await fetch(
    `https://graph.facebook.com/v20.0/oauth/access_token?grant_type=fb_exchange_token&client_id=${process.env.META_APP_ID}&client_secret=${process.env.APP_SECRET}&fb_exchange_token=${shortToken}`
  );
  const longTokenData = await longTokenRes.json();
  const accessToken = longTokenData.access_token;

  console.log("accessToken:--",accessToken)


  // Get user's business ID
  const businessRes = await fetch(
    `https://graph.facebook.com/v20.0/me?fields=businesses&access_token=${accessToken}`
  );
  const businessData = await businessRes.json();
  console.log("businessData",businessData)
  const businessId = businessData?.businesses?.data?.[0]?.id;
  if (!businessId) {
    console.error("No business found for user", businessData);
    return res.status(400).json({ error: "No business account found. Please make sure your FB user has a business." });
  }

  //  Create WhatsAppSDK with token + businessId
  const wa = new WhatsAppSDK({
    accessToken,
    businessId, //  this fixes "businessId required"
    appSecret: process.env.APP_SECRET
  });

  //  Get WABA and Phone Numbers
  const owned = await wa.getOwnedWABAs();
  const wabaId = owned?.data?.[0]?.id;
  const phones = await wa.getPhoneNumbers(wabaId);
  const phoneNumberId = phones?.data?.[0]?.id;

  console.log("Business:", businessId, "WABA:", wabaId, "Phone:", phoneNumberId,"token",accessToken);


  const row_id = libFunc.randomid();
  //  Save to DB
  await queries.customQuery(
    `INSERT INTO wap.api_credentials (row_id, organization_id, access_token, business_id, waba_id, phone_number_id)
     VALUES ('${row_id}','${orgId}','${accessToken}','${businessId}','${wabaId}','${phoneNumberId}')`
  );

  //  Redirect user to frontend with success
  console.log("process.env.FRONTEND_URL",process.env.FRONTEND_URL)
  // res.redirect(`${process.env.FRONTEND_URL}/dashboard/whatsapp?status=connected`);
  res.redirect(`${process.env.FRONTEND_URL}/dashboard?status=0`);

});

//  app.post("/webhook", async (req, res) => {
//     console.log("req--------------->",req)
//     res.sendStatus(200);
//   try {
//     const messages = req.body.entry?.[0]?.changes?.[0]?.value?.messages;
//     console.log("data ------>", req.body.entry?.[0]?.changes?.[0])

//     let others_data = JSON.stringify(req.body)
    
//     if (messages) {
//       for (const msg of messages) {
//         const phone = msg.from;
//         const body = msg.text?.body || "";
//         console.log(" Incoming:", phone, body);

//         let row_id = libFunc.randomid()
       
//         const resp =   await queries.customQuery(
//         `INSERT INTO wap.messages (row_id,phone, direction, body) VALUES ('${row_id}','${phone}','in','${body}')`);
       
//         console.log("response--->",resp)
//       }
//     }
//   } catch (err) {
//     console.error("Webhook error:", err.message);
//   }
// });

