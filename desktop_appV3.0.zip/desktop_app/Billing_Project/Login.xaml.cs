﻿using System.Windows;
using Billing_Project.controller;
using Billing_Project.service;

namespace Billing_Project
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();

            // always check 
            if (ApiService.IsUserLoggedIn())
            {
                RedirectToClientWindow();
            }
        }


        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = txtEmail.Text;
            string password = txtPassword.Password;

           

            //bool isLoggedIn = await Apicontroller.LoginUserAsync(logindata);

            bool isLoggedIn = await Apicontroller.LoginUserpg(username, password);

            if (isLoggedIn)
            {
                RedirectToClientWindow();
            }
            else
            {
                //lblMessage.Text = "Invalid email or password!";
                MessageBox.Show("Invalid email or password!");
                txtEmail.Clear();
                txtPassword.Clear(); 
            }
        }

        private void RedirectToClientWindow()
        {
            Clients clientsWindow = new Clients();
            clientsWindow.Show();
            this.Close();
        }        
    }
}
