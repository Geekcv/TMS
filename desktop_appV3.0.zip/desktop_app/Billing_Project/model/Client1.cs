﻿namespace Billing_Project.model
{
    public class Client1
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
