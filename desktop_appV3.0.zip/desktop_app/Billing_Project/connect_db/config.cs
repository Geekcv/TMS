﻿using System.IO;
using Newtonsoft.Json.Linq;


namespace Billing_Project.connect_db
{
    public class config
    {
        private static string ConnectionString;

        public static string DatabaseConfig()
        {
           
                // Read the JSON configuration file
                string json = File.ReadAllText("appsettings.json");
                JObject config = JObject.Parse(json);
                var dbConfig = config["Database"];

                string host = dbConfig["Host"]?.ToString();
                string port = dbConfig["Port"]?.ToString();
                string user = dbConfig["User"]?.ToString();
                string password = dbConfig["Password"]?.ToString();
                string database = dbConfig["Name"]?.ToString();               

               

                // Create connection string with pooling
                ConnectionString = $"Host={host};Port={port};Username={user};Password={password};Database={database};Pooling=true;MinPoolSize=1;MaxPoolSize=20;";

               

                Console.WriteLine("Database connection pooling initialized!");
                //MessageBox.Show("Database connection pooling initialized!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);

                return ConnectionString;
                        
        }        

    }
}
