﻿using Billing_Project.connect_db;
using Billing_Project.model;
using Billing_Project.service;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Windows;

namespace Billing_Project.controller
{
    public class Apicontroller
    {
        private const string JwtSecretKey = "ThisIsAStrongSecretKeyWithMoreThan32Chars";

        public static async Task<bool> LoginUserAsync(object logindata)
        {
            var loginData = new
            {
                fn = "common_fn",
                se = "lo_us",
                data = logindata
            };

            string response = await ApiService.PostUrlAsync(loginData, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("Login failed: Empty response");
                return false;
            }

            // encode response agian 
            string urlDecoded = Uri.UnescapeDataString(response);

            try
            {
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);

                if (result?.data?.token != null)
                {
                    ApiService.SaveToken(result.data.token.ToString());
                    return true;
                }
                else
                {
                    Console.WriteLine("Login failed: No token received");
                    return false;
                }
            }
            catch (JsonReaderException jex)
            {
                Console.WriteLine("JSON Parsing Error: " + jex.Message);
                Console.WriteLine("API Response: " + response);
                return false;
            }
        }



        public static async Task<bool> LoginUserpg(string username, string password)
        {
            string userTable1 = "public.users"; // Fixed table reference format

            Dictionary<string, object> conditions = new Dictionary<string, object>
    {
        { "AND", new Dictionary<string, object>
            {
                { "username", username },
                { "password", password } // ⚠️ Password should be hashed in a real application
            }
        }
    };

            // Fetch data asynchronously
            List<Dictionary<string, object>> userTable = await queries.FetchData(userTable1, conditions);

            if (userTable.Count > 0) // Corrected the check
            {
                var row = userTable[0]; // Access first item correctly
                int userId = Convert.ToInt32(row["user_id"]);
                string userName = row["username"].ToString();

                string token = GenerateJwtToken(userId, userName); // Ensure this method exists
                if (token!= null)
                {
                    ApiService.SaveToken(token);
                    return true;
                }
                else
                {
                    Console.WriteLine("Login failed: No token received");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false; // Return failure
            }
        }



        private static string GenerateJwtToken(int userId, string username)
        {

            var key = Encoding.UTF8.GetBytes(JwtSecretKey); // Ensure key is at least 32 characters
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
            new Claim("userId", userId.ToString()),
            new Claim("username", username)
        }),
                Expires = DateTime.UtcNow.AddHours(24),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature // Ensure correct algorithm
                )
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }












        public static async Task<bool> AddClientAsync(object clientdata)
        {
            var loginData = new
            {
                fn = "common_fn",
                se = "cr_cl",
                data = clientdata
            };

            string response = await ApiService.PostUrlAsync(loginData, "common");

            if (string.IsNullOrEmpty(response))
            {
                Console.WriteLine("Login failed: Empty response");
                return false;
            }           

            string urlDecoded = Uri.UnescapeDataString(response);

            try
            {
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"Parsed JSON: {result}");

                if (result != null && result.status == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (JsonReaderException jex)
            {
                Console.WriteLine("JSON Parsing Error: " + jex.Message);
                Console.WriteLine(" API Response: " + response);
                return false;
            }
        }




        public static async Task<List<Client1>> GetClientsAsync()
        {
            string response = await ApiService.PostUrlAsync(new { fn = "common_fn", se = "fe_cl" }, "common");

            if (string.IsNullOrEmpty(response))
            {
                //Console.WriteLine("Failed to fetch clients: Empty response");
                return new List<Client1>();
            }

            try
            {
                // Fix potential JSON formatting issues
                string jsonResponse = response.Trim();
                if (jsonResponse.StartsWith("[") && jsonResponse.EndsWith("]"))
                {
                    jsonResponse = jsonResponse.Trim('[', ']'); // Remove outer brackets if it's an array
                }

                string urlDecoded = Uri.UnescapeDataString(jsonResponse);

                // Deserialize JSON
                var result = JsonConvert.DeserializeObject<dynamic>(urlDecoded);
                Console.WriteLine($"Parsed Clients JSON: {result}");

                // Extract client list
                var clientsList = new List<Client1>();
                foreach (var item in result)
                {
                    clientsList.Add(new Client1
                    {
                        //RowId = item.row_id,
                        Name = item.name,
                        Description = item.description
                    });
                }
                return clientsList;
            }
            catch (Exception ex)
            {
                //Console.WriteLine("Error parsing clients: " + ex.Message);
                return new List<Client1>();
            }
        }       



    }
}
