﻿using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Newtonsoft.Json;

namespace Billing_Project.service
{
    public class ApiService
    {
        private static readonly HttpClient client = new HttpClient { BaseAddress = new Uri(ConfigUrl.ConfigSettings.apiBaseURL) };
        private const string TokenFilePath = "auth_token.txt"; // File to store token

        // Load Token from File
        private static string LoadToken()
        {
            return File.Exists(TokenFilePath) ? File.ReadAllText(TokenFilePath) : null;
        }

        // Save Token to File
        public static void SaveToken(string token)
        {
            File.WriteAllText(TokenFilePath, token);
        }

        // Clear Token (Logout)
        public static void Logout()
        {
            // file delete 
            if (File.Exists(TokenFilePath))
                File.Delete(TokenFilePath);
        }

        // Build Headers with Token
        private static void SetHeaders()
        {
            string token = LoadToken();
            client.DefaultRequestHeaders.Clear();
            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            }
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        // Encode Data (Base64)
        private static string EncodeData(object data)
        {
            string json = JsonConvert.SerializeObject(data);
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        }

        // Decode Data (Handles JSON, Base64, and URL-Encoded Base64)
        private static string DecodeData(string response)
        {
            try
            {
                Console.WriteLine($"Raw Response: {response}"); // Log before decoding

                string trimmedResponse = response.Trim();

                // Check if Already JSON
                if (trimmedResponse.StartsWith("{") || trimmedResponse.StartsWith("["))
                {
                    Console.WriteLine("Response is already JSON.");
                    return response;
                }

                // URL Decode First (Handles URL-encoded Base64)
                string urlDecoded = Uri.UnescapeDataString(trimmedResponse);
                Console.WriteLine($"URL Decoded: {urlDecoded}");

                // Validate and Decode Base64
                if (IsValidBase64(urlDecoded))
                {
                    byte[] bytes = Convert.FromBase64String(urlDecoded);
                    string decodedString = Encoding.UTF8.GetString(bytes);
                    Console.WriteLine($"Base64 Decoded: {decodedString}");

                    // Check if Decoded Data is JSON
                    if (decodedString.Trim().StartsWith("{") || decodedString.Trim().StartsWith("["))
                    {
                        Console.WriteLine("Successfully Decoded JSON from Base64.");
                        return decodedString;
                    }

                    Console.WriteLine("Base64 Decoded, but not JSON. Returning decoded text.");
                    return decodedString;
                }

                Console.WriteLine(" Not Base64. Returning raw response.");
                return response;
            }
            catch (FormatException)
            {
                Console.WriteLine(" Invalid Base64 format. Returning raw response.");
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Decoding Error: " + ex.Message);
                return response;
            }
        }

        // Validate if a String is Base64
        private static bool IsValidBase64(string input)
        {
            if (string.IsNullOrEmpty(input) || input.Length % 4 != 0 || input.Contains(" "))
                return false;

            try
            {
                Convert.FromBase64String(input);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        //  POST Request
        public static async Task<string> PostUrlAsync(object data, string url)
        {
            SetHeaders();
            string encodedPayload = EncodeData(data);
            var content = new StringContent(JsonConvert.SerializeObject(new { payload = encodedPayload }), Encoding.UTF8, "application/json");

            try
            {
                HttpResponseMessage response = await client.PostAsync(url, content);
                response.EnsureSuccessStatusCode(); // Throws exception if status is not 2xx

                string responseString = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Raw API Response: {responseString}");

                return DecodeData(responseString); // Decodes API response properly
            }
            catch (HttpRequestException httpEx)
            {
                Console.WriteLine("HTTP Request Error: " + httpEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            return null;
        }


        // Check if User is Logged In
        public static bool IsUserLoggedIn()
        {
            return !string.IsNullOrEmpty(LoadToken());
        }





        // Get User ID from JWT Token
        public static string GetUserId()
        {
            string token = LoadToken();
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                // Split JWT and get the payload (2nd part)
                string[] parts = token.Split('.');
                if (parts.Length < 2)
                    throw new Exception("Invalid JWT format");

                // Convert Base64 URL to standard Base64
                string base64Payload = parts[1].Replace('-', '+').Replace('_', '/');
                while (base64Payload.Length % 4 != 0) // Add padding if needed
                {
                    base64Payload += "=";
                }

                // Decode Base64 payload
                string payloadJson = Encoding.UTF8.GetString(Convert.FromBase64String(base64Payload));

                // Parse JSON and extract userId
                using (JsonDocument doc = JsonDocument.Parse(payloadJson))
                {
                    if (doc.RootElement.TryGetProperty("UserId", out JsonElement userIdElement))
                    {
                        return userIdElement.GetString();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error decoding token: " + ex.Message);
                //services
            }

            return null; // Return null if decoding fails
        }

    }
}
