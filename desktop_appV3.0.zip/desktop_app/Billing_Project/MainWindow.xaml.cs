﻿
using System.Data;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Billing_Project.connect_db;
using Billing_Project.function;
using Newtonsoft.Json;

namespace Billing_Project
{

    public partial class MainWindow : Window
    {
       private string selectedId;
        private string userTable = "public" + ".my_table1";
        public MainWindow()
        {
            InitializeComponent();
            btnfetch_Click(null, null);
        }


        // Insert Data
        private async void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtAge.Text))
                {
                    MessageBox.Show("Please enter both Name and Age.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var row_id = functions.RandomId();
                var name = txtName.Text;
                var age = Int32.Parse(txtAge.Text);

                var columns = new Dictionary<string, object>
                 {
                      { "row_id", row_id },
                      { "name", name },
                      { "age", age },
                 };

                // Create instance of DatabaseHelper
                var result = await queries.InsertData(userTable, columns);

                if (result != null)
                {
                    MessageBox.Show("Data inserted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtName.Clear();
                    txtAge.Clear();
                    btnfetch_Click(null, null);
                }
                else
                {
                    MessageBox.Show("Failed to insert data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error inserting data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        // clean data
        private void btntxtClearData_Click(object sender, RoutedEventArgs e)
        {
            txtName.Text = "";
            txtAge.Text = "";
        }


        // Fetch Data
        private async void btnfetch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Create a dictionary for conditions
                //Dictionary<string, object> conditions = new Dictionary<string, object>
                //{
                //    { "OR", new Dictionary<string, object>
                //        {
                //            { "name", "abhishek" },
                //            { "age", 11 }
                //        }
                //    }
                //};

                Dictionary<string, object> conditions = null;

                //Dictionary<string, object> conditions = new Dictionary<string, object> 
                //{
                //    { "ORDER", new Dictionary<string, string>
                //      {
                //         { "created_at","desc" }, // Specify the column to order by
                //       }
                //     }
                //};

                // Fetch data asynchronously
                List<Dictionary<string, object>> xmlResult = await queries.FetchData(userTable, conditions);

                // define column name which display 
                List<string> specificColumns = new List<string> { "name", "age","row_id" };

                // Bind the result to the DataGrid
                dataGridResult.ItemsSource = ConvertToDataTable(xmlResult,specificColumns).DefaultView;
                    //dataGridResult.ItemsSource = xmlResult;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Convert List<Dictionary<string, object>> to DataTable
        //private DataTable ConvertToDataTable(List<Dictionary<string, object>> data)
        //{
        //    DataTable table = new DataTable();

        //    if (data.Count == 0)
        //        return table;

        //    // Add columns
        //    foreach (var key in data[0].Keys)
        //    {
        //        table.Columns.Add(key, typeof(string));  // Adjust the type as needed
        //    }

        //    // Add rows
        //    foreach (var dict in data)
        //    {
        //        DataRow row = table.NewRow();
        //        foreach (var key in dict.Keys)
        //        {
        //            row[key] = dict[key]?.ToString() ?? DBNull.Value.ToString();
        //        }
        //        table.Rows.Add(row);
        //    }

        //    return table;
        //}


        private DataTable ConvertToDataTable(List<Dictionary<string, object>> data, List<string> specificColumns = null)
        {
            DataTable table = new DataTable();

            // Return an empty table if there is no data
            if (data == null || data.Count == 0)
                return table;

            // Determine which columns to add
            var columnsToAdd = specificColumns ?? data[0].Keys.ToList(); // Use specificColumns if provided, otherwise use all keys

            // Add columns to the DataTable
            foreach (var key in columnsToAdd)
            {
                // Add a column with type inferred from the first row's value if possible
                Type columnType = typeof(string); // Default type

                // Check the first row to determine the correct type
                if (data[0].ContainsKey(key) && data[0][key] != null)
                {
                    columnType = data[0][key].GetType();
                }

                table.Columns.Add(key, columnType);
            }

            // Add rows to the DataTable
            foreach (var dict in data)
            {
                DataRow row = table.NewRow();
                foreach (var key in columnsToAdd)
                {
                    if (dict.ContainsKey(key))
                    {
                        // Assign the value or DBNull if the value is null
                        row[key] = dict[key] ?? DBNull.Value;
                    }
                    else
                    {
                        row[key] = DBNull.Value; // Handle missing keys
                    }
                }
                table.Rows.Add(row);
            }

            return table;
        }


        // data grid 

        private void dataGridResult_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridResult.SelectedItem != null)
            {
                try
                {
                    DataRowView row = (DataRowView)dataGridResult.SelectedItem;

                    txtName.Text = row["Name"].ToString();
                    txtAge.Text = row["Age"].ToString();
                    selectedId = row["row_id"].ToString();
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
        }




        // update data 

        private  async void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtAge.Text))
                {
                    MessageBox.Show("Please enter both Name and Age.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var name = txtName.Text;
                var age = Int32.Parse(txtAge.Text);

                var columns = new Dictionary<string, object>
                 {
                    { "name", name },
                    { "age", age },
                };

                var comm = new Dictionary<string, object>
                 {
                    { "row_id", selectedId },
                };

                // Create instance of DatabaseHelper
                var result = await queries.UpdateData(userTable, columns, comm);

                if (result != null)
                {
                    MessageBox.Show("Data update successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtName.Clear();
                    txtAge.Clear();
                    btnfetch_Click(null, null);
                }
                else
                {
                    MessageBox.Show("Failed to updae data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error update data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        
        
        // delete data

        private async void btndelete_Click(object sender, RoutedEventArgs e)
        {
            var comm = new Dictionary<string, object>
                 {
                    { "row_id", selectedId },
                };

            // Create instance of DatabaseHelper
            var result = await queries.DeleteData(userTable, comm);

            if (result != null)
            {
                MessageBox.Show("Data delete successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                txtName.Clear();
                txtAge.Clear();
                btnfetch_Click(null, null);
            }
            else
            {
                MessageBox.Show("Failed to delete data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }


            // create table 
            // var data = new List<Dictionary<string, object>>()
            //{
            //     new Dictionary<string, object> { { "id", "name" }, { "fdtype", "TEXT" }, { "required", true } },
            //     new Dictionary<string, object> { { "id", "age" }, { "fdtype", "INTEGER" }, { "required", false } },
            //     //new Dictionary<string, object> { { "id", "created_on" }, { "fdtype", "TIMESTAMP" }, { "required", true } }
            // };


            // var res = queries.CreateTable("public", "user", data);

            // if (res != null) {
            //     MessageBox.Show("table created successfully");
            // }

        }

        private void btncount_Click(object sender, RoutedEventArgs e)
        {
            Dictionary<string, object> conditions = null;
            //Dictionary<string, object> conditions = new Dictionary<string, object>
            //{
            //    {"name","yash" }
            //};


            Task<int?> res = queries.CountRecordsAsync(userTable, conditions);

            if (res != null)
            {
                count.Content = res.Result;
                //MessageBox.Show("fetch count  successfully");
            }
        }


        // JOIN data


        private void btnjoin_Click(object sender, RoutedEventArgs e)
        {
            var selectFields = new List<string>
            {
                "Customers.CustomerName",
                "Orders.OrderID",
                "Orders.TotalAmount"
            };

              var conditions = new List<Dictionary<string, object>>
               {
                    new Dictionary<string, object>
                    {
                            { "jointype", "right" },
                            { "tables", new List<Dictionary<string, string>>
                                {
                                     new Dictionary<string, string>
                                      {
                                          { "tb", "Customers" },
                                           { "on", "CustomerID" } // Column from Customers used for joining
                                       },
                                      new Dictionary<string, string>
                                      {
                                        { "tb", "Orders" },
                                         { "on", "CustomerID" } // Column from Orders used for joining
                                       }
                                  }
                            }
                    }
               };

            string orderBy = "Customers.CustomerName";

            // Prepare the complete SQL query
            var joindataQuery = queries.PrepareJoin(conditions, selectFields, orderBy);

            Console.WriteLine(joindataQuery); // Output the constructed SQL query for debugging purposes

            dataGridResult.ItemsSource = ConvertToDataTable(joindataQuery).DefaultView;

        }

        private async void btnselect_Click(object sender, RoutedEventArgs e)
        {
            List<string> data = null;
            Dictionary<string,string> cond = null;
            Dictionary <string ,string> orderBy = null;
            Dictionary<string,int> limit = null;
            Dictionary<string, int> offset = null;
            List<Dictionary<string, object>> joins = null;

            //var parameters = new
            //{
            //    //data = new List<string>
            //    //{
            //    //  "customername",
            //    //},
            //    data,
            //    tablename = "Customers",  // Specify the table name
            //    cond = new Dictionary<string, object>
            //    {
            //       { "customername", "Jane Smith" }  // Example condition
            //    },
            //     orderby = new Dictionary<string, string>
            //     {
            //         { "customername","asc" }
            //     },                 
            //     limit = new Dictionary<string,int>
            //     {
            //         { "LIMIT",10 }
            //     },
            //     offset = new Dictionary<string, int>
            //     {
            //         {"OFFSET",0 }
            //     },
            //     joins = new List<Dictionary<string, object>> 
            //     {
            //        new Dictionary<string, object>
            //        {
            //                { "jointype", "right" },
            //                { "tables", new List<Dictionary<string, string>>
            //                    {
            //                         new Dictionary<string, string>
            //                          {
            //                              { "tb", "Customers" },
            //                               { "on", "CustomerID" } // Column from Customers used for joining
            //                           },
            //                          new Dictionary<string, string>
            //                          {
            //                            { "tb", "Orders" },
            //                             { "on", "CustomerID" } // Column from Orders used for joining
            //                           }
            //                      }
            //                }
            //        }

            //     }  
            //};

            var parameters = new
            {
                data ,
                tablename = "Customers",  // Specify the table name
                cond = new Dictionary<string, object>
                {
                   { "OR", new Dictionary<string, object>
                        {
                            { "customername", "Charlie Black" },
                            { "city", "Phoenix" }
                        }
                    }
                } ,
                orderby = new Dictionary<string, string>
                 {
                     { "customername","asc" }
                 },
                limit = new Dictionary<string, int>
                 {
                     { "LIMIT",10 }
                 },
                offset = new Dictionary<string, int>
                 {
                     {"OFFSET",0 }
                 },
                joins
            };


            var selectQueryres = await queries.SelectQuery(parameters);

            dataGridResult.ItemsSource = ConvertToDataTable(selectQueryres).DefaultView;

            //foreach (var row in res)
            //{
            //    Console.WriteLine(string.Join(", ", ((IDictionary<string, object>)row).Select(kvp => $"{kvp.Key}: {kvp.Value}")));
            //}
        }

        private async void btncustome_Click(object sender, RoutedEventArgs e)
        {
            string query = "SELECT * FROM public.my_table1 where name='ankit';"; // Or get your query from a textbox, etc.
            string query1 = "INSERT INTO public.my_table1 (row_id,name, age) VALUES ('21250205161418_K8R9','Cheese','11');";
            string query2 = "UPDATE public.my_table1 SET name ='hhh' WHERE  row_id='21250205161418_K8R9'";
            string query3 = "DELETE FROM public.my_table1 WHERE row_id='21250205161418_K8R9'";

            string query4 = "CREATE TABLE public.mytable (id int primary key, data text); INSERT INTO mytable VALUES (1,'one'), (2,'two'); ";

            string query5 = "SELECT * FROM public.my_table1 WHERE name ILIKE 'A%';";

            string query6 = "CREATE VIEW abhiTable AS SELECT name, age  FROM public.my_table1;";

            string query7 = "select * from public.abhiTable";

            try
            {
                List<Dictionary<string, object>> results = await queries.CustomQuery(query7);

                // Now you can do something with the results
                if (results != null)
                {
                    foreach (var row in results)
                    {
                        Console.WriteLine(string.Join(", ", row.Select(kvp => $"{kvp.Key}: {kvp.Value}")));
                    }

                    // Or, bind the results to a DataGrid
                     dataGridResult.ItemsSource = ConvertToDataTable(results).DefaultView; ; // If your DataGrid is setup to handle List<Dictionary<string,object>>
                }
                else
                {
                    Console.WriteLine("No results found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                // Optionally show an error message to the user
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        //private async void btnhttp_Click(object sender, RoutedEventArgs e)
        //{
        //    using (var client = new HttpClient())
        //    {
        //        try
        //        {
        //            Task<string> jsonTask = HttpClientExample2.GetRequestExample();
        //            string json = await jsonTask; // Await the Task to get the result

        //            List<Dictionary<string, object>>? json1 = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(json);

        //            if (json1 != null)
        //            {
        //                dataGridResult.ItemsSource = ConvertToDataTable(json1).DefaultView;
        //            }
        //            else
        //            {
        //                MessageBox.Show("Failed to deserialize JSON to List<Dictionary<string, object>>");
        //            }
        //        }
        //        catch (JsonSerializationException ex)
        //        {
        //            MessageBox.Show($"Error deserializing JSON: {ex.Message}");
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show($"An unexpected error occurred: {ex.Message}");
        //        }
        //    }
        //}

        //private void btnPost_Click(object sender, RoutedEventArgs e)
        //{
        //    var userId = Int32.Parse(txtuserId.Text);
        //    var title = txttitle.Text;
        //    var body = txtBody.Text;

        //    // Create the POST data as a JSON string using the arguments.
        //    var postData = new StringContent(JsonConvert.SerializeObject(new
        //    {
        //        userId = userId,
        //        title = title,
        //        body = body,
        //    }),
        //    Encoding.UTF8, "application/json");

        //    //var postData = new StringContent(JsonConvert.SerializeObject(new
        //    //{
        //    //    email = "abhi@gmail.com",
        //    //    password = "123",

        //    //}));


        //    HttpClientExample2.PostRequestExample(postData);

        //}

    }
}