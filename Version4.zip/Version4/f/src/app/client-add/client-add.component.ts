import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { Router } from '@angular/router';
import { AuthService } from '../servies/auth.service';  // Import AuthService
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-client-add',
  templateUrl: './client-add.component.html',
  styleUrls: ['./client-add.component.css']
})
export class ClientAddComponent {
  clientForm: FormGroup;
  loading: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private authService: AuthService  // Inject AuthService
  ) {
    this.clientForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  uploadedFilePath: string = ''; // To store the uploaded file's path

onFileSelected(event: Event): void {
  const input = event.target as HTMLInputElement;
  if (input.files && input.files.length > 0) {
    const file = input.files[0];
    const formData = new FormData();
    formData.append('file', file);

    this.http.post('http://localhost:3000/common/uploads', formData).subscribe({
      next: (response: any) => {
        console.log('Upload successful:', response);
        // Extract the file path from the response
        if (response?.rsp?.data?.filesInfo?.[0]?.foPa) {
          this.uploadedFilePath = response.rsp.data.filesInfo[0].foPa;
          console.log('Uploaded File Path:', this.uploadedFilePath);
        } else {
          console.error('Unexpected response format:', response);
          this.errorMessage = 'File upload failed. Invalid server response.';
        }
      },
      error: (error) => {
        console.error('Upload failed:', error);
        this.errorMessage = 'File upload failed. Please try again.';
      },
    });
  }
}



async onSubmit() {
  if (this.clientForm.valid) {
    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    try {
      const userId = this.authService.getUserId();
      if (!userId) {
        this.errorMessage = 'User not authenticated!';
        return;
      }

      // Include uploaded file path in the form data
      const clientData = { 
        ...this.clientForm.value,
        userId: userId,
        photourl: this.uploadedFilePath // Include file path from the upload response
      };

      const resp = await this.Apicontroller.createClient(clientData);

      if (resp.status === 0) {
        this.successMessage = 'Client added successfully!';
        setTimeout(() => {
          this.router.navigate(['/show-client']);
        }, 1000);
      } else {
        this.errorMessage = 'Failed to add client. Please try again.';
      }
    } catch (error) {
      console.error('Error:', error);
      this.errorMessage = 'An error occurred. Please try again later.';
    } finally {
      this.loading = false;
    }
  } else {
    this.errorMessage = 'Please fill in all required fields.';
  }
}

  
}
