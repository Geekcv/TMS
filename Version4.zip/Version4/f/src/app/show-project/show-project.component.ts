import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from '../controller/apicontroller.service';

interface Project {
  id: number;
  project_name: string;
}
@Component({
  selector: 'app-show-project',
  templateUrl: './show-project.component.html',
  styleUrls: ['./show-project.component.css']
})
export class ShowProjectComponent {
  projects: Project[] = [];
  clientId!: string | null; // Holds the client ID from the route

    constructor(private router: Router,private Apicontroller: ApicontrollerService,

      private route: ActivatedRoute,

    ) {
   
    this.fetch()

    
  }
  
  async fetch(){
    this.clientId = this.route.snapshot.paramMap.get('id');

    const resp = await this.Apicontroller.fetchProject(this.clientId);
    this.projects = resp.data
  }

  editClient(clientId: number) {
    this.router.navigate(['edit-project', clientId]);
  }

  viewClientDetails(clientId: any,project:any) {
    this.router.navigate(['/projectdetails', clientId,project]);
  }


}
