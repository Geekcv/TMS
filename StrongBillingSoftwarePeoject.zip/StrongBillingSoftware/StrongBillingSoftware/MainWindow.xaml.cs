﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace StrongBillingSoftware
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Navigate to the Login Page
        private void OnLoginClick(object sender, RoutedEventArgs e)
        {
            // Show the login window
            LoginPage loginPage = new LoginPage();
            loginPage.ShowDialog();

            // After login success, hide the login panel and show the main application content
            ShowMainAppPanel();
        }

        // Navigate to the Register Page
        private void OnRegisterClick(object sender, RoutedEventArgs e)
        {
            // Show the register window
            RegisterPage registerPage = new RegisterPage();
            registerPage.ShowDialog();
        }

        // Show Main Application Panel after login
        private void ShowMainAppPanel()
        {
            // Hide the login panel
            LoginPanel.Visibility = Visibility.Collapsed;
            
            // Show the main app panel
            MainAppPanel.Visibility = Visibility.Visible;
        }

        // Navigate to Dashboard Page
        private void OnDashboardClick(object sender, RoutedEventArgs e)
        {
            MainContentFrame.Navigate(new DashboardPage());
        }

        // Navigate to Products Page
        private void OnProductsClick(object sender, RoutedEventArgs e)
        {
            MainContentFrame.Navigate(new ProductsPage());
        }

        // Navigate to Customers Page
        private void OnCustomersClick(object sender, RoutedEventArgs e)
        {
            MainContentFrame.Navigate(new CustomersPage());
        }

        // Navigate to Invoices Page
        private void OnInvoicesClick(object sender, RoutedEventArgs e)
        {
            MainContentFrame.Navigate(new InvoicesPage());
        }

        // Logout the user and show the login panel again
        private void OnLogoutClick(object sender, RoutedEventArgs e)
        {
            // Hide the main app panel and show the login panel
            MainAppPanel.Visibility = Visibility.Collapsed;
            LoginPanel.Visibility = Visibility.Visible;
        }

    }
}
