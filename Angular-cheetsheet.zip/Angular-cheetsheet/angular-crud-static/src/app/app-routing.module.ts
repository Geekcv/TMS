import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CrudJsonServerComponent } from './crud-json-server/crud-json-server.component';

const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' }, // Default route
  { path: 'crud', component: CrudJsonServerComponent }, // CRUD route
  { path: '**', redirectTo: '/crud' } // Fallback route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
