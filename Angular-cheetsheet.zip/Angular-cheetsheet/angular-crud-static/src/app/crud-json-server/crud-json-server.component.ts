import { Component } from '@angular/core';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-crud-json-server',
  templateUrl: './crud-json-server.component.html',
  styleUrls: ['./crud-json-server.component.css']
})
export class CrudJsonServerComponent {
  items: any[] = [];
  newItem = { name: '', description: '' }; // Removed `id` from the new item

  constructor(private crudService: CrudService) {}

  ngOnInit(): void {
    this.getItems();
  }

  // Get items from JSON Server
  getItems(): void {
    this.crudService.getItems().subscribe((data) => {
      // Add an `isEditing` flag to each item
      this.items = data.map(item => ({ ...item, isEditing: false }));
    });
  }

  // Add item
  addItem(): void {
    if (this.newItem.name && this.newItem.description) {
      const itemToAdd = { ...this.newItem }; // Do not include `id`

      this.crudService.addItem(itemToAdd).subscribe(() => {
        this.getItems(); // Refresh the list
        this.newItem = { name: '', description: '' }; // Reset form
      });
    }
  }

  // Enable edit mode for an item
  editItem(item: any): void {
    item.isEditing = true;
  }

  // Save changes to an item
  saveItem(item: any): void {
    this.crudService.updateItem(item).subscribe(() => {
      item.isEditing = false; // Exit edit mode
      this.getItems(); // Refresh the list
    });
  }

  // Delete item
  deleteItem(id: number): void {
    this.crudService.deleteItem(id).subscribe(() => {
      this.getItems(); // Refresh the list
    });
  }




  
}
