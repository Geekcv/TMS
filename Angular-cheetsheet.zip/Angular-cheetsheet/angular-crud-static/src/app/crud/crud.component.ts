import { Component } from '@angular/core';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css'],
})
export class CrudComponent {
  // Static data
  items = [
    { id: 1, name: 'Item 1', description: 'Description of Item 1' },
    { id: 2, name: 'Item 2', description: 'Description of Item 2' },
    { id: 3, name: 'Item 3', description: 'Description of Item 3' },
  ];

  // New item object for Create operation
  newItem = { id: 0, name: '', description: '' };

  // Create
  addItem() {
    if (this.newItem.name && this.newItem.description) {
      const newId = this.items.length
        ? this.items[this.items.length - 1].id + 1
        : 1;
      this.items.push({ ...this.newItem, id: newId });
      this.newItem = { id: 0, name: '', description: '' }; // Reset form
    }
  }

  // Update
  updateItem(item: any) {
    const index = this.items.findIndex((i) => i.id === item.id);
    if (index > -1) {
      this.items[index] = { ...item };
    }
  }

  // Delete
  deleteItem(id: number) {
    this.items = this.items.filter((item) => item.id !== id);
  }
}
