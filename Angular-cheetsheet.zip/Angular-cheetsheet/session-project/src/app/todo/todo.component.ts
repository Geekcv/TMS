import { Component, OnInit } from '@angular/core';
import { Todo } from '../models/todo';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  todos: Todo[] = [];
  newTodo: string = '';
  editMode: boolean = false;
  editTodo: Todo | null = null;

  constructor(private todoService: TodoService) {}

  ngOnInit(): void {
    this.loadTodos();
  }

  // Load Todos
  loadTodos(): void {
    this.todos = this.todoService.getTodos();
  }

  // Add Todo
  addTodo(): void {
    if (this.newTodo.trim()) {
      const newId = this.todos.length ? Math.max(...this.todos.map(t => t.id)) + 1 : 1;
      this.todoService.addTodo({ id: newId, title: this.newTodo, completed: false });
      this.newTodo = '';
      this.loadTodos();
    }
  }

  // Edit Todo
  startEdit(todo: Todo): void {
    this.editMode = true; // Enable edit mode
    this.editTodo = { ...todo }; // Create a copy of the selected todo
  }

  updateTodo(): void {
    if (this.editTodo) {
      this.todoService.updateTodo(this.editTodo); // Update the todo in the session storage
      this.editMode = false; // Exit edit mode
      this.editTodo = null; // Clear the temporary editTodo object
      this.loadTodos(); // Reload the updated todos
    }
  }

  // Delete Todo
  deleteTodo(id: number): void {
    this.todoService.deleteTodo(id);
    this.loadTodos();
  }
}
