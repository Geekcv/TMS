import { Injectable } from '@angular/core';
import { Todo } from './models/todo';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private sessionKey = 'todos';

  constructor() {}

  // Get Todos
  getTodos(): Todo[] {
    const todos = sessionStorage.getItem(this.sessionKey);
    return todos ? JSON.parse(todos) : [];
  }

  // Save Todos
  saveTodos(todos: Todo[]): void {
    sessionStorage.setItem(this.sessionKey, JSON.stringify(todos));
  }

  // Add Todo
  addTodo(todo: Todo): void {
    const todos = this.getTodos();
    todos.push(todo);
    this.saveTodos(todos);
  }

  // Update Todo
  updateTodo(updatedTodo: Todo): void {
    const todos = this.getTodos().map(todo =>
      todo.id === updatedTodo.id ? updatedTodo : todo
    );
    this.saveTodos(todos);
  }

  // Delete Todo
  deleteTodo(id: number): void {
    const todos = this.getTodos().filter(todo => todo.id !== id);
    this.saveTodos(todos);
  }
}
