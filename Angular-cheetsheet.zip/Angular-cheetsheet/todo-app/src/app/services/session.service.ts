import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SessionService {
  private readonly TASKS_KEY = 'tasks';

  constructor() {}

  getTasks(): { title: string; completed: boolean }[] {
    const tasks = sessionStorage.getItem(this.TASKS_KEY);
    return tasks ? JSON.parse(tasks) : [];
  }

  addTask(task: string): void {
    const tasks = this.getTasks();
    tasks.push({ title: task, completed: false });
    sessionStorage.setItem(this.TASKS_KEY, JSON.stringify(tasks));
  }

  updateTask(index: number, updatedTask: string): void {
    const tasks = this.getTasks();
    tasks[index].title = updatedTask;
    sessionStorage.setItem(this.TASKS_KEY, JSON.stringify(tasks));
  }

  toggleTaskCompletion(index: number): void {
    const tasks = this.getTasks();
    tasks[index].completed = !tasks[index].completed;
    sessionStorage.setItem(this.TASKS_KEY, JSON.stringify(tasks));
  }

  deleteTask(index: number): void {
    const tasks = this.getTasks();
    tasks.splice(index, 1);
    sessionStorage.setItem(this.TASKS_KEY, JSON.stringify(tasks));
  }
}
