import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly baseUrl = 'http://localhost:3000/users';

  constructor(private http: HttpClient, private router: Router) {}

  register(user: { username: string; password: string }): Observable<any> {
    return this.http.post(this.baseUrl, user).pipe(
      catchError((error) => throwError(() => error))
    );
  }

  login(username: string, password: string): Observable<any> {
    return this.http.get<any[]>(`${this.baseUrl}?username=${username}`).pipe(
      map((users) => {
        const user = users.find((u) => u.password === password);
        if (user) {
          sessionStorage.setItem('user', JSON.stringify(user));
          return user;
        } else {
          throw new Error('Invalid credentials');
        }
      }),
      catchError((error) => throwError(() => error))
    );
  }

  logout(): void {
    sessionStorage.removeItem('user');
    this.router.navigate(['/login']);
  }

  isAuthenticated(): boolean {
    return !!sessionStorage.getItem('user');
  }

    // Retrieve user data from session storage
    getUserData(): any {
      return JSON.parse(sessionStorage.getItem('user') || '{}');
    }
  
}
