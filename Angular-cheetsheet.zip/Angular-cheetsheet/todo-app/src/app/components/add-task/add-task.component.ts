import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from '../../services/session.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
})
export class AddTaskComponent {
  task = '';

  constructor(private sessionService: SessionService, private router: Router) {}

  addTask(): void {
    if (this.task.trim()) {
      this.sessionService.addTask(this.task);
      this.task = '';
      this.router.navigate(['/view-tasks']);
    }
  }
}
