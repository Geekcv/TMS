import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SessionService } from '../../services/session.service';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
})
export class EditTaskComponent implements OnInit {
  task = '';
  index!: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private sessionService: SessionService
  ) {}

  ngOnInit(): void {
    this.index = +this.route.snapshot.paramMap.get('index')!;
    const tasks = this.sessionService.getTasks();
    this.task = tasks[this.index].title;
  }

  saveTask(): void {
    if (this.task.trim()) {
      this.sessionService.updateTask(this.index, this.task);
      this.router.navigate(['/view-tasks']);
    }
  }
}
