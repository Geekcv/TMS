import { Component, OnInit } from '@angular/core';
import { SessionService } from '../../services/session.service';

@Component({
  selector: 'app-view-tasks',
  templateUrl: './view-tasks.component.html',
})
export class ViewTasksComponent implements OnInit {
  tasks: { title: string; completed: boolean }[] = [];

  constructor(private sessionService: SessionService) {}

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks(): void {
    this.tasks = this.sessionService.getTasks();
  }

  toggleCompletion(index: number): void {
    this.sessionService.toggleTaskCompletion(index);
    this.loadTasks();
  }

  deleteTask(index: number): void {
    this.sessionService.deleteTask(index);
    this.loadTasks();
  }
}
