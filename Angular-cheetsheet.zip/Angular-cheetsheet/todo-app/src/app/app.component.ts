import { Component } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  constructor(public authService: AuthService, private router: Router) {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/profile']);  // Redirect authenticated users to profile page
    }
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);  // Redirect to login page after logout
  }
}
