import Notice from "../models/notification.js";
import Task from "../models/task.js";
import User from "../models/user.js";

export const createTask = async (req, res) => {
  try {
    const { userId } = req.user;
    const { title, team, stage, date, priority, assets } = req.body;

    // Ensure `team` is an array
    const teamArray = Array.isArray(team) ? team : [team];
    // Ensure `assets` is an array
    const assetsArray = Array.isArray(assets) ? assets : assets ? [assets] : [];

    let text = "New task has been assigned to you";
    if (teamArray.length > 1) {
      text += ` and ${teamArray.length - 1} others.`;
    }

    text += ` The task priority is set as ${priority} priority, so check and act accordingly. The task date is ${new Date(
      date
    ).toDateString()}. Thank you!!!`;

    const activity = {
      type: "assigned",
      activity: text,
      by: userId,
    };

    // Create the task
    const task = await Task.create({
      title,
      team: teamArray,
      stage: stage.toLowerCase(),
      date,
      priority: priority.toLowerCase(),
      assets: assetsArray,
      activities: [activity], // Ensure this is an array
    });

    // Create the notification
    await Notice.create({
      team: teamArray,
      text,
      taskId: task.id, // Adjust to match your model's field name
    });

    res.status(200).json({
      status: true,
      task,
      message: "Task created successfully.",
    });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const duplicateTask = async (req, res) => {
  try {
    const { id } = req.params;

    // Fetch the original task
    const task = await Task.findByPk(id);

    if (!task) {
      return res.status(404).json({ status: false, message: "Task not found" });
    }

    // Create the new duplicated task
    const newTask = await Task.create({
      title: task.title + " - Duplicate",
      team: task.team,
      subTasks: task.subTasks,
      assets: task.assets,
      priority: task.priority,
      stage: task.stage,
      date: task.date,
    });

    // Create notification for the new task
    let text = "New task has been assigned to you";
    if (task.team.length > 1) {
      text += ` and ${task.team.length - 1} others.`;
    }

    text += ` The task priority is set as ${
      task.priority
    } priority, so check and act accordingly. The task date is ${new Date(
      task.date
    ).toDateString()}. Thank you!!!`;

    await Notice.create({
      team: task.team,
      text,
      taskId: newTask.id, // Adjust to match your model's field name
    });

    res
      .status(200)
      .json({ status: true, message: "Task duplicated successfully." });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const postTaskActivity = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.user;
    const { type, activity } = req.body;

    // Fetch the task
    const task = await Task.findByPk(id);

    if (!task) {
      return res.status(404).json({ status: false, message: "Task not found" });
    }

    // Add activity to task's activities
    const newActivity = {
      type,
      activity,
      by: userId,
    };

    // Assuming activities is a JSON column or similar
    const updatedActivities = task.activities
      ? [...task.activities, newActivity]
      : [newActivity];

    // Update task with new activities
    await task.update({ activities: updatedActivities });

    res
      .status(200)
      .json({ status: true, message: "Activity posted successfully." });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const dashboardStatistics = async (req, res) => {
  try {
    const { userId, isAdmin } = req.user;

    // Fetch tasks
    const allTasks = isAdmin
      ? await Task.findAll({
          where: { isTrashed: false },
          include: {
            model: User,
            as: "team",
            attributes: ["name", "role", "title", "email"],
          },
          order: [["createdAt", "DESC"]],
        })
      : await Task.findAll({
          where: {
            isTrashed: false,
            team: {
              [Sequelize.Op.contains]: [userId],
            },
          },
          include: {
            model: User,
            as: "team",
            attributes: ["name", "role", "title", "email"],
          },
          order: [["createdAt", "DESC"]],
        });

    // Fetch active users
    const users = await User.findAll({
      where: { isActive: true },
      attributes: ["name", "title", "role", "isAdmin", "createdAt"],
      limit: 10,
      order: [["createdAt", "DESC"]],
    });

    // Group tasks by stage
    const groupTasksByStage = allTasks.reduce((result, task) => {
      const stage = task.stage;
      result[stage] = (result[stage] || 0) + 1;
      return result;
    }, {});

    // Group tasks by priority
    const groupData = Object.entries(
      allTasks.reduce((result, task) => {
        const priority = task.priority;
        result[priority] = (result[priority] || 0) + 1;
        return result;
      }, {})
    ).map(([name, total]) => ({ name, total }));

    // Calculate total tasks and last 10 tasks
    const totalTasks = allTasks.length;
    const last10Task = allTasks.slice(0, 10);

    const summary = {
      totalTasks,
      last10Task,
      users: isAdmin ? users : [],
      tasks: groupTasksByStage,
      graphData: groupData,
    };

    res.status(200).json({
      status: true,
      message: "Successfully",
      ...summary,
    });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const getTasks = async (req, res) => {
  try {
    const { stage, isTrashed } = req.query;

    // Define the query conditions
    const queryConditions = {
      where: { isTrashed: isTrashed ? true : false },
      include: {
        model: User,
        as: "team",
        attributes: ["name", "title", "email"],
      },
      order: [["createdAt", "DESC"]],
    };

    if (stage) {
      queryConditions.where.stage = stage;
    }

    // Fetch tasks from the database
    const tasks = await Task.findAll(queryConditions);

    res.status(200).json({
      status: true,
      tasks,
    });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const createSubTask = async (req, res) => {
  try {
    const { title, tag, date } = req.body;
    const { id } = req.params;

    // Validate that the task exists
    const task = await Task.findByPk(id);
    if (!task) {
      return res.status(404).json({ status: false, message: "Task not found" });
    }

    // Create a new subtask
    const newSubTask = await SubTask.create({
      title,
      tag,
      date,
      taskId: id, // Associate the subtask with the parent task
    });

    // Optionally, update the parent task if needed (not necessary for Sequelize)
    // For example, you might want to update some attributes in the parent task

    res.status(200).json({
      status: true,
      message: "SubTask added successfully.",
      subTask: newSubTask,
    });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, date, team, stage, priority, assets } = req.body;

    // Find the task by primary key
    const task = await Task.findByPk(id);

    if (!task) {
      return res.status(404).json({ status: false, message: "Task not found" });
    }

    // Update task attributes
    task.title = title;
    task.date = date;
    task.priority = priority.toLowerCase();
    task.assets = assets;
    task.stage = stage.toLowerCase();
    task.team = team;

    // Save the updated task
    await task.save();

    res
      .status(200)
      .json({ status: true, message: "Task updated successfully." });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const trashTask = async (req, res) => {
  try {
    const { id } = req.params;

    // Find the task by primary key
    const task = await Task.findByPk(id);

    if (!task) {
      return res.status(404).json({ status: false, message: "Task not found" });
    }

    // Mark the task as trashed
    task.isTrashed = true;

    // Save the updated task
    await task.save();

    res.status(200).json({
      status: true,
      message: "Task trashed successfully.",
    });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const deleteRestoreTask = async (req, res) => {
  try {
    const { id } = req.params;
    const { actionType } = req.query;

    switch (actionType) {
      case "delete":
        await Task.destroy({ where: { id } });
        break;

      case "deleteAll":
        await Task.destroy({ where: { isTrashed: true } });
        break;

      case "restore":
        const taskToRestore = await Task.findByPk(id);

        if (!taskToRestore) {
          return res
            .status(404)
            .json({ status: false, message: "Task not found" });
        }

        taskToRestore.isTrashed = false;
        await taskToRestore.save();
        break;

      case "restoreAll":
        await Task.update({ isTrashed: false }, { where: { isTrashed: true } });
        break;

      default:
        return res
          .status(400)
          .json({ status: false, message: "Invalid action type" });
    }

    res.status(200).json({
      status: true,
      message: "Operation performed successfully.",
    });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};
