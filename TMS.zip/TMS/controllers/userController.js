import { response } from "express";
import User from "../models/user.js";
import { createJWT } from "../utils/index.js";
import Notice from "../models/notification.js";
import { token } from "morgan";

export const registerUser = async (req, res) => {
  try {
    const { name, email, password, isAdmin, role, title } = req.body;

    const userExist = await User.findOne({ where: { email } });

    if (userExist) {
      return res.status(400).json({
        status: false,
        message: "User already exists",
      });
    }

    const user = await User.create({
      name,
      email,
      password,
      isAdmin,
      role,
      title,
    });

    if (user) {
      isAdmin ? createJWT(res, user._id) : null;

      user.password = undefined;

      res.status(201).json(user);
    } else {
      return res
        .status(400)
        .json({ status: false, message: "Invalid user data" });
    }
  } catch (error) {
    console.log(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res
        .status(401)
        .json({ status: false, message: "Invalid email or password." });
    }

    if (!user?.isActive) {
      return res.status(401).json({
        status: false,
        message: "User account has been deactivated, contact the administrator",
      });
    }

    const isMatch = await user.matchPassword(password);

    if (user && isMatch) {
      createJWT(res, user.id);

      user.password = undefined;
      console.log(res.token);
      res.status(200).json(user);
    } else {
      return res
        .status(401)
        .json({ status: false, message: "Invalid email or password" });
    }
  } catch (error) {
    console.log(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const logoutUser = async (req, res) => {
  try {
    res.cookie("token", "", {
      htttpOnly: true,
      expires: new Date(0),
    });

    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    console.log(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const getTeamList = async (req, res) => {
  try {
    // const users = await User.find().select("name title role email isActive");

    const users = await User.findAll({
      attributes: ["name", "title", "role", "email", "isActive"],
    });

    res.status(200).json(users);
  } catch (error) {
    console.log(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const getNotificationsList = async (req, res) => {
  try {
    const { userId } = req.user;

    // Fetch notifications where the user is in the team and has not read the notification
    const notice = await Notice.findAll({
      where: {
        team: {
          [Op.contains]: [userId],
        },
        isRead: {
          [Op.notIn]: [userId],
        },
      },
      include: [
        {
          model: Task,
          attributes: ["title"],
        },
      ],
    });

    res.status(201).json(notice);
  } catch (error) {
    console.log(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const updateUserProfile = async (req, res) => {
  try {
    const { userId, isAdmin } = req.user;
    const { _id, name, title, role } = req.body;

    // Determine the correct user ID to update based on admin status
    const id =
      isAdmin && userId === _id
        ? userId
        : isAdmin && userId !== _id
        ? _id
        : userId;

    // Find the user by ID using Sequelize
    const user = await User.findByPk(id);

    if (user) {
      // Update user fields if provided in the request body
      user.name = name || user.name;
      user.title = title || user.title;
      user.role = role || user.role;

      // Save the updated user profile
      const updatedUser = await user.save();

      // Remove the password from the response
      updatedUser.password = undefined;

      res.status(201).json({
        status: true,
        message: "Profile Updated Successfully.",
        user: updatedUser,
      });
    } else {
      res.status(404).json({ status: false, message: "User not found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const markNotificationRead = async (req, res) => {
  try {
    const { userId } = req.user;
    const { isReadType, id } = req.query;

    if (isReadType === "all") {
      // Mark all unread notifications as read
      await Notice.update(
        {
          isRead: sequelize.fn("array_append", sequelize.col("isRead"), userId),
        },
        {
          where: {
            team: { [Op.contains]: [userId] },
            isRead: { [Op.not]: { [Op.contains]: [userId] } },
          },
        }
      );
    } else {
      // Mark a specific notification as read
      await Notice.update(
        {
          isRead: sequelize.fn("array_append", sequelize.col("isRead"), userId),
        },
        {
          where: {
            id,
            isRead: { [Op.not]: { [Op.contains]: [userId] } },
          },
        }
      );
    }

    res.status(201).json({ status: true, message: "Done" });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const changeUserPassword = async (req, res) => {
  try {
    const { userId } = req.user;
    const { password } = req.body;

    const user = await User.findByPk(userId); // findById is replaced by findByPk in Sequelize

    if (user) {
      // Hash the new password before saving
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);

      await user.save();

      // Exclude the password from the response
      user.password = undefined;

      res.status(200).json({
        status: true,
        message: "Password changed successfully.",
      });
    } else {
      res.status(404).json({ status: false, message: "User not found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const activateUserProfile = async (req, res) => {
  try {
    const { id } = req.params;
    const { isActive } = req.body;

    // Find user by primary key (assuming `id` is the primary key)
    const user = await User.findByPk(id);

    if (user) {
      // Update the user's isActive status
      user.isActive = isActive;

      await user.save();

      res.status(200).json({
        status: true,
        message: `User account has been ${isActive ? "activated" : "disabled"}`,
      });
    } else {
      res.status(404).json({ status: false, message: "User not found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};

export const deleteUserProfile = async (req, res) => {
  try {
    const { id } = req.params;

    // Delete the user by primary key
    const deletedUser = await User.destroy({
      where: { id },
    });

    if (deletedUser) {
      res
        .status(200)
        .json({ status: true, message: "User deleted successfully" });
    } else {
      res.status(404).json({ status: false, message: "User not found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(400).json({ status: false, message: error.message });
  }
};
