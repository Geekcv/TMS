import { Sequelize } from "sequelize";
import dotenv from "dotenv";

dotenv.config();

// Print the URI to verify it's being loaded
console.log("Postgres URI:", process.env.POSTGRES_URI);

const sequelize = new Sequelize(process.env.POSTGRES_URI || "", {
  dialect: "postgres",
  logging: false,
});

export const dbConnection = async () => {
  try {
    if (!process.env.POSTGRES_URI) {
      throw new Error("POSTGRES_URI is not defined");
    }
    await sequelize.authenticate();
    console.log(
      "Connection to the database has been established successfully."
    );

    await sequelize.sync({ force: false }); // force: true will drop tables if they already exist and recreate them

    // Start your server or application here
    console.log("Database & tables created!");
  } catch (error) {
    console.log("DB Error:", error.message);
  }
};

export default sequelize;
