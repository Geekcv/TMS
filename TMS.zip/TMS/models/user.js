// import bcrypt from "bcryptjs";
// import mongoose, { Schema } from "mongoose";

// const userSchema = new Schema(
//   {
//     name: { type: String, required: true },
//     title: { type: String, required: true },
//     role: { type: String, required: true },
//     email: { type: String, required: true, unique: true },
//     password: { type: String, required: true },
//     isAdmin: { type: Boolean, required: true, default: false },
//     tasks: [{ type: Schema.Types.ObjectId, ref: "Task" }],
//     isActive: { type: Boolean, required: true, default: true },
//   },
//   { timestamps: true }
// );

// userSchema.pre("save", async function (next) {
//   if (!this.isModified("password")) {
//     next();
//   }

//   const salt = await bcrypt.genSalt(10);
//   this.password = await bcrypt.hash(this.password, salt);
// });

// userSchema.methods.matchPassword = async function (enteredPassword) {
//   return await bcrypt.compare(enteredPassword, this.password);
// };

// const User = mongoose.model("User", userSchema);

// export default User;

import { DataTypes, Model } from "sequelize";
import bcrypt from "bcryptjs";
// import sequelize from "../utils/index.js"; // Assuming you have a Sequelize instance exported from this file
import sequelize from "../config/database.js"; // Assuming you have a Sequelize instance exported from this file

class User extends Model {
  async matchPassword(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
  }
}

User.init(
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    role: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    isAdmin: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    sequelize, // Pass the Sequelize instance
    modelName: "User",
    timestamps: true, // Adds createdAt and updatedAt fields
    hooks: {
      beforeSave: async (user) => {
        if (user.changed("password")) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
    },
  }
);

// Define association with Task model if needed
// Assuming you have a Task model defined
// User.hasMany(Task, { foreignKey: "userId" });

export default User;
