// import mongoose, { Schema } from "mongoose";

// const taskSchema = new Schema(
//   {
//     title: { type: String, required: true },
//     date: { type: Date, default: new Date() },
//     priority: {
//       type: String,
//       default: "normal",
//       enum: ["high", "medium", "normal", "low"],
//     },
//     stage: {
//       type: String,
//       default: "todo",
//       enum: ["todo", "in progress", "completed"],
//     },
//     activities: [
//       {
//         type: {
//           type: String,
//           default: "assigned",
//           enum: [
//             "assigned",
//             "started",
//             "in progress",
//             "bug",
//             "completed",
//             "commented",
//           ],
//         },
//         activity: String,
//         date: { type: Date, default: new Date() },
//         by: { type: Schema.Types.ObjectId, ref: "User" },
//       },
//     ],

//     subTasks: [
//       {
//         title: String,
//         date: Date,
//         tag: String,
//       },
//     ],
//     assets: [String],
//     team: [{ type: Schema.Types.ObjectId, ref: "User" }],
//     isTrashed: { type: Boolean, default: false },
//   },
//   { timestamps: true }
// );

// const Task = mongoose.model("Task", taskSchema);

// export default Task;

import { DataTypes, Model } from "sequelize";
import sequelize from "../config/database.js"; // Ensure Sequelize instance is imported correctly
import User from "./user.js"; // Ensure User model is imported correctly

class Task extends Model {}

Task.init(
  {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    date: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    priority: {
      type: DataTypes.STRING,
      defaultValue: "normal",
      validate: {
        isIn: [["high", "medium", "normal", "low"]],
      },
    },
    stage: {
      type: DataTypes.STRING,
      defaultValue: "todo",
      validate: {
        isIn: [["todo", "in progress", "completed"]],
      },
    },
    activities: {
      type: DataTypes.ARRAY(DataTypes.JSONB), // JSONB for structured data in PostgreSQL
      defaultValue: [],
      validate: {
        isArrayOfValidActivities(value) {
          if (!Array.isArray(value)) {
            throw new Error("Activities must be an array");
          }
          value.forEach((activity) => {
            if (
              ![
                "assigned",
                "started",
                "in progress",
                "bug",
                "completed",
                "commented",
              ].includes(activity.type)
            ) {
              throw new Error("Invalid activity type: " + activity.type);
            }
          });
        },
      },
    },
    subTasks: {
      type: DataTypes.ARRAY(DataTypes.JSONB),
      defaultValue: [],
    },
    assets: {
      type: DataTypes.ARRAY(DataTypes.STRING),
      defaultValue: [],
    },
    isTrashed: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  },
  {
    sequelize, // Pass the Sequelize instance
    modelName: "Task",
    timestamps: true, // Adds createdAt and updatedAt fields
  }
);

// Associations
Task.belongsToMany(User, { through: "TaskTeam", as: "team" }); // Many-to-many relationship with User model

export default Task;
