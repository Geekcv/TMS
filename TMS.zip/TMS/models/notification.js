import { DataTypes, Model } from "sequelize";
import sequelize from "../config/database.js"; // Adjust the import based on your configuration

class Notice extends Model {}

Notice.init(
  {
    team: {
      type: DataTypes.ARRAY(DataTypes.INTEGER), // Assuming team is an array of user IDs
      allowNull: true,
    },
    text: {
      type: DataTypes.STRING,
      allowNull: false, // Assuming text is required
    },
    task: {
      type: DataTypes.INTEGER, // Assuming task is an ID
      allowNull: true,
    },
    notiType: {
      type: DataTypes.ENUM("alert", "message"),
      defaultValue: "alert",
    },
    isRead: {
      type: DataTypes.ARRAY(DataTypes.INTEGER), // Assuming isRead is an array of user IDs
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: "Notice",
    timestamps: true, // Automatically adds createdAt and updatedAt
  }
);

export default Notice;
