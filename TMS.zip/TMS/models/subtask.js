// models/subTask.js
import { DataTypes, Model } from "sequelize";
import sequelize from "../config/database.js"; // Ensure Sequelize instance is imported correctly
import Task from "./task.js"; // Ensure Task model is imported correctly

class SubTask extends Model {}

SubTask.init(
  {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    tag: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    date: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    taskId: {
      type: DataTypes.INTEGER,
      references: {
        model: Task,
        key: "id",
      },
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: "SubTask",
    timestamps: true,
  }
);

// Association
SubTask.belongsTo(Task, { foreignKey: "taskId" });

export default SubTask;
