import { Component } from '@angular/core';
import { ApicontrollerService } from './controller/apicontroller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Frontend';
  posts: any[] = []; // Stores fetched posts
  filteredPosts: any[] = []; // Stores filtered posts for search functionality
  isLoading = false; // To manage the loading state
  searchQuery: string = ''; // Store the search query
  myposts:any[]=[]
  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router
  ) {
    this.fetchPosts(); // Fetch posts on initialization
    this.fetchmyPosts()
  }


  // async fetchmyPosts() {
  //   try {
  //     const resp: any = await this.Apicontroller.fetchPost();
  //     console.log('Fetched Posts:', resp);

  //     // Ensure we have an array of posts
  //     this.myposts = Array.isArray(resp.data) ? resp.data : resp;
  //   } catch (error) {
  //     console.error('Error fetching posts:', error);
  //     this.posts = [];
  //   }
  // }


// my clone table data with original
  async fetchmyPosts() {
    try {
      const resp: any = await this.Apicontroller.fetchPost();
      console.log('Fetched Posts:', resp);
  
      // Ensure we have an array of posts and map status to isChecked
      this.myposts = Array.isArray(resp.data) ? resp.data.map((post: { status: string; }) => ({
        ...post,
        isChecked: post.status === 'payment done'
      })) : [];
    } catch (error) {
      console.error('Error fetching posts:', error);
      this.myposts = [];
    }
  }
  
  // Fetch posts from the backend external api
  async fetchPosts() {
    try {
      const resp: any = await this.Apicontroller.fetchEXPost();
      console.log('Fetched Posts:', resp);

      // Ensure we have an array of posts
      this.posts = Array.isArray(resp.data) ? resp.data : resp;
      this.filteredPosts = this.posts; // Initialize filteredPosts with all posts initially
    } catch (error) {
      console.error('Error fetching posts:', error);
      this.posts = [];
      this.filteredPosts = [];
    }
  }

  // Handle checkbox change and save the post with isChecked value
  async onCheckboxChange(post: any) {
    console.log('Checkbox State Changed:', post.isChecked); // Log the checkbox state
    await this.savePost(post); // Save the updated post
  }

  // Save the post to the database
  async savePost(post: any) {
    try {
      this.isLoading = true;
      console.log('Saving Post:', post);

      // Send the post with updated isChecked value
      const response = await this.Apicontroller.createPost(post);
      console.log('Save Response:', response);

      if (response.status === 0) {
        // alert('Post saved successfully!');
      } else {
        // alert('Failed to save post.');
      }
    } catch (error) {
      console.error('Error saving post:', error);
      // alert('An error occurred while saving the post.');
    } finally {
      this.isLoading = false;
    }
  }

  // Save all posts with current checkbox state
  async saveAlldata() {
    try {
      this.isLoading = true;
      console.log('Saving All Posts...');

      // Iterate through all posts and save them
      for (const post of this.filteredPosts) {
        await this.savePost(post); // Save each post with its current isChecked value
      }

      // alert('All posts saved successfully!');
    } catch (error) {
      console.error('Error saving all posts:', error);
      // alert('An error occurred while saving all posts.');
    } finally {
      this.isLoading = false;
    }
  }

  // Handle search input and filter posts
  // // Handle search input and filter posts
onSearch() {
  if (this.searchQuery.trim()) {
    // Filter posts based on the title or body
    this.filteredPosts = this.posts.filter(post => 
      (post.title && post.title.toLowerCase().includes(this.searchQuery.toLowerCase())) || 
      (post.body && post.body.toLowerCase().includes(this.searchQuery.toLowerCase()))||
      (post.id && post.id.toString().includes(this.searchQuery))

    );
  } else {
    // If search query is empty, show all posts
    this.filteredPosts = this.posts;
  }
}


  

}
