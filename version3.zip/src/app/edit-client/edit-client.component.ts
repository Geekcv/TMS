import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
}

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
})
export class EditClientComponent implements OnInit {
  clientForm!: FormGroup;
  clientId!: number;

  // Simulated data source (replace with actual service)
  clients: Client[] = [
    { id: 1, name: 'John Doe', email: 'john@example.com', phone: '123-456-7890' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '098-765-4321' },
    // Add more clients as needed
  ];

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.clientForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.clientId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadClientData(this.clientId);
  }

  loadClientData(id: number) {
    const client = this.clients.find(client => client.id === id);
    if (client) {
      this.clientForm.patchValue(client); // Populate form with existing data
    }
  }

  onSubmit() {
    if (this.clientForm.valid) {
      console.log(this.clientForm.value);
      // Logic to update the client data goes here (e.g., call a service)
      
      // After saving, navigate back to the main page or show success message
      this.router.navigate(['/']);
    }
  }
}
