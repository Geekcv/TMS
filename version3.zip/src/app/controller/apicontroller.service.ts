import { Injectable } from '@angular/core';
import { ApiService } from '../servies/api.service';

@Injectable({
  providedIn: 'root'
})
export class ApicontrollerService {

  constructor(private apiService: ApiService) { }

  async createPost(Postdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_post",
      "data": Postdata
    };

    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }


  async fetchPost(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_post",
      "data": " "
      }
    
    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }

  async fetchEXPost(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_Expost",
      "data": " "
      }
    
    console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    console.log(resp);
    return resp;
  }

}
