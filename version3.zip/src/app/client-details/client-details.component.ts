import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
}

@Component({
  selector: 'app-client-details',
  templateUrl: './client-details.component.html',
})
export class ClientDetailsComponent {


  clientId!: number;
  client!: Client | undefined;

  // Simulated data source (replace with actual service)
  clients: Client[] = [
    { id: 1, name: 'John Doe', email: 'john@example.com', phone: '123-456-7890' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '098-765-4321' },
    // Add more clients as needed
  ];

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.clientId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadClientData(this.clientId);
  }

  loadClientData(id: number) {
    this.client = this.clients.find(client => client.id === id); // Find the client by ID
  }









  // Data
  links = [{ title: 'Instagram', link: 'www.instagram.com' }];
  credentials = [{ username: 'ABCD', password: '****' }];
  workLogs = [{ description: 'Work log 1', date: '2025-01-12', updatedBy: 'Ramesh', tags: 'Pending' }];

  // Dialog Flags
  isLinkDialogVisible = false;
  isCredentialDialogVisible = false;
  isWorkLogDialogVisible = false;

  // Temporary Objects for Dialogs
  currentLink: any = {};
  currentCredential: any = {};
  currentWorkLog: any = {};
  editIndex = -1;

  // Open Dialogs
  openLinkDialog() {
    this.currentLink = {};
    this.editIndex = -1;
    this.isLinkDialogVisible = true;
  }

  openCredentialDialog() {
    this.currentCredential = {};
    this.editIndex = -1;
    this.isCredentialDialogVisible = true;
  }

  openWorkLogDialog() {
    this.currentWorkLog = {};
    this.editIndex = -1;
    this.isWorkLogDialogVisible = true;
  }

  // Edit Operations
  editLink(link: any, index: number) {
    this.currentLink = { ...link };
    this.editIndex = index;
    this.isLinkDialogVisible = true;
  }

  editCredential(credential: any, index: number) {
    this.currentCredential = { ...credential };
    this.editIndex = index;
    this.isCredentialDialogVisible = true;
  }

  editWorkLog(workLog: any, index: number) {
    this.currentWorkLog = { ...workLog };
    this.editIndex = index;
    this.isWorkLogDialogVisible = true;
  }

  // Save Operations
  saveLink() {
    if (this.editIndex >= 0) {
      this.links[this.editIndex] = this.currentLink;
    } else {
      this.links.push(this.currentLink);
    }
    this.closeLinkDialog();
  }

  saveCredential() {
    if (this.editIndex >= 0) {
      this.credentials[this.editIndex] = this.currentCredential;
    } else {
      this.credentials.push(this.currentCredential);
    }
    this.closeCredentialDialog();
  }

  saveWorkLog() {
    if (this.editIndex >= 0) {
      this.workLogs[this.editIndex] = this.currentWorkLog;
    } else {
      this.workLogs.push(this.currentWorkLog);
    }
    this.closeWorkLogDialog();
  }

  // Close Dialogs
  closeLinkDialog() {
    this.isLinkDialogVisible = false;
  }

  closeCredentialDialog() {
    this.isCredentialDialogVisible = false;
  }

  closeWorkLogDialog() {
    this.isWorkLogDialogVisible = false;
  }


  // Store selected files
  uploadedFiles1: { name: string; size: number; content: string | ArrayBuffer | null }[] = [];
  uploadedFiles2: { name: string; size: number; content: string | ArrayBuffer | null }[] = [];


  // File selection handler
  onFileSelected1(event: Event): void {
    const input = event.target as HTMLInputElement;
  
    if (input?.files) {
      Array.from(input.files).forEach((file) => {
        // Read file content if needed
        const reader = new FileReader();
        reader.onload = (e: ProgressEvent<FileReader>) => {
          this.uploadedFiles1.push({
            name: file.name,
            size: file.size,
            content: e.target?.result ?? null, // Fallback to null if undefined
          });
        };
        reader.readAsDataURL(file); // Or readAsText / readAsArrayBuffer
      });
    }
  }
  
  // Delete a file from the memory
  deleteFile(index: number): void {
    this.uploadedFiles1.splice(index, 1);
  }
  saveToLocalStorage(): void {
    localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles1));
  }
  
  loadFromLocalStorage(): void {
    const data = localStorage.getItem('uploadedFiles');
    if (data) {
      this.uploadedFiles1 = JSON.parse(data);
    }
  }
  downloadFile(file: { name: string; content: string | ArrayBuffer | null }): void {
    const link = document.createElement('a');
    link.href = file.content as string; // Must be a Base64 data URL
    link.download = file.name;
    link.click();
  }


  getFileLogo(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return 'assets/icons/p1.png'; // Path to your PDF logo
      case 'doc':
      case 'docx':
        return 'assets/icons/doc-icon.png'; // Path to your Word logo
      case 'txt':
        return 'assets/icons/txt-icon.png'; // Path to your Text logo
      case 'png':
      case 'jpg':
      case 'jpeg':
        return 'assets/icons/i1.jpg'; // Path to your Image logo
      default:
        return 'assets/icons/default-icon.png'; // Path to a default logo
    }
  }



  onFileSelected2(event: Event): void {
    const input = event.target as HTMLInputElement;
  
    if (input?.files) {
      Array.from(input.files).forEach((file) => {
        // Read file content if needed
        const reader = new FileReader();
        reader.onload = (e: ProgressEvent<FileReader>) => {
          this.uploadedFiles2.push({
            name: file.name,
            size: file.size,
            content: e.target?.result ?? null, // Fallback to null if undefined
          });
        };
        reader.readAsDataURL(file); // Or readAsText / readAsArrayBuffer
      });
    }
  }
  
  // Delete a file from the memory
  deleteFile2(index: number): void {
    this.uploadedFiles2.splice(index, 1);
  }
  saveToLocalStorage2(): void {
    localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles2));
  }
  
  loadFromLocalStorage2(): void {
    const data = localStorage.getItem('uploadedFiles');
    if (data) {
      this.uploadedFiles2 = JSON.parse(data);
    }
  }
  
    
}
