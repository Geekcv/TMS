﻿using System;
using System.Windows;
using Npgsql;

namespace StrongBillingSoftware
{
    public partial class AddProductPage : Window
    {
        private DatabaseHelper db;

        public AddProductPage()
        {
            InitializeComponent();
            db = new DatabaseHelper();
            LoadCategories();
        }

        // Load categories from database
        private void LoadCategories()
        {
            string query = "SELECT * FROM categories";
            var categories = db.ExecuteQuery(query);

            CategoryComboBox.ItemsSource = categories.DefaultView;
            CategoryComboBox.DisplayMemberPath = "name"; // Assuming "name" column exists
            CategoryComboBox.SelectedValuePath = "category_id"; // Assuming "category_id" column exists
        }

        // Save Product button click event
        private void OnSaveClick(object sender, RoutedEventArgs e)
        {
            string productName = ProductNameTextBox.Text;
            decimal price = Convert.ToDecimal(PriceTextBox.Text);
            int stock = Convert.ToInt32(StockTextBox.Text);
            int categoryId = Convert.ToInt32(CategoryComboBox.SelectedValue);

            string query = "INSERT INTO products (name, price, stock, category_id) VALUES (@name, @price, @stock, @category_id)";
            var parameters = new NpgsqlParameter[]
            {
                new NpgsqlParameter("@name", productName),
                new NpgsqlParameter("@price", price),
                new NpgsqlParameter("@stock", stock),
                new NpgsqlParameter("@category_id", categoryId)
            };

            db.ExecuteNonQuery(query, parameters);
            MessageBox.Show("Product added successfully.");
            this.Close();
        }

        // Cancel button click event
        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
