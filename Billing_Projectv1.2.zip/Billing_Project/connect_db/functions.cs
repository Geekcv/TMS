﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billing_Project.connect_db
{
    public class functions
    {

        private static readonly Random _random = new Random();
        private static readonly string _possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        public static string RandomId()
        {
            string randomTxt = "";

            for (int i = 0; i < 4; i++)
            {
                randomTxt += _possible[_random.Next(_possible.Length)];
            }

            return GetTimeStamp() + "_" + randomTxt;
        }

        private static string GetTimeStamp()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmss");
        }
    }
}

