﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml;

namespace Billing_Project.connect_db
{
    public class DatabaseHelper
    {
        private static readonly string ConnectionString =
            "Host=localhost;Port=5432;Username=postgres;Password=Admin;Database=TestDB;Pooling=true;MinPoolSize=1;MaxPoolSize=20;";



        // insert data       


        public static async Task<object> InsertData(string tablename, Dictionary<string, object> columns)
        {
            using (var connectDb = new NpgsqlConnection(ConnectionString))
            {
                await connectDb.OpenAsync();

                var colString = "(";
                var lastKey = GetLastKey(columns);
                foreach (var k in columns.Keys)
                {
                    if (columns[k] != null)
                    {
                        if (k != lastKey)
                        {
                            colString += k + ",";
                        }
                        else
                        {
                            colString += k + ")";
                        }
                    }
                }

                var valString = "('";
                foreach (var k in columns.Keys)
                {
                    if (columns[k] != null)
                    {
                        if (k != lastKey)
                        {
                            if (columns[k] is Array)
                            {
                                valString += JsonSerializer.Serialize(columns[k]).Replace("'", "`") + "' ,'";
                            }
                            else
                            {
                                valString += columns[k].ToString().Replace("'", "`") + "' ,'";
                            }
                        }
                        else
                        {
                            if (columns[k] is Array)
                            {
                                valString += JsonSerializer.Serialize(columns[k]).Replace("'", "`") + "')";
                            }
                            else
                            {
                                valString += columns[k].ToString().Replace("'", "`") + "')";
                            }
                        }
                    }

                }

                var sqlString = "INSERT INTO " + tablename + colString + " VALUES" + valString + " ON CONFLICT(row_id) DO NOTHING RETURNING row_id;";
                Console.WriteLine(sqlString);

                try
                {
                    using (var cmd = new NpgsqlCommand(sqlString, connectDb))
                    {
                        var response = await cmd.ExecuteScalarAsync();

                        return response; // Return the row_id or null if insert failed

                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine($"Error running query: {ex.Message}");
                    throw;
                }
            }

        }
        private static string GetLastKey(Dictionary<string, object> columns)
        {
            var lastKey = string.Empty;
            foreach (var key in columns.Keys)
            {
                lastKey = key;
            }
            return lastKey;
        }


        // fetch data

        public static async Task<List<Dictionary<string, object>>> FetchDataAsync(string tableName, Dictionary<string, object> cond)
        {
            return await Task.Run(() =>
            {
                try
                {
                    var colString = " WHERE ";
                    Console.WriteLine("cond");
                    Console.WriteLine(cond);

                    var sqlString = "SELECT * FROM " + tableName;

                    if (cond == null)
                    {
                        sqlString += " ;";
                        Console.WriteLine(sqlString);
                    }
                    else
                    {
                        if (cond.Count > 1)
                        {
                            foreach (var k in cond.Keys)
                            {
                                if (k == "OR")
                                {
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' OR ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                        }
                                    }
                                }
                                if (k == "AND")
                                {
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' AND ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            foreach (var k in cond.Keys)
                            {
                                if (k == "OR")
                                {
                                    Console.WriteLine("k");
                                    Console.WriteLine(k);
                                    Console.WriteLine(cond[k]);
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' OR ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                            sqlString += colString + " ;";
                                        }
                                    }
                                }
                                else if (k == "AND")
                                {
                                    foreach (var key in (Dictionary<string, object>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, object>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            colString += key.Key + " = '" + key.Value + "' AND ";
                                        }
                                        else
                                        {
                                            colString += key.Key + " = '" + key.Value + "'";
                                            sqlString += colString + " ;";
                                        }
                                    }
                                }
                                else if (k == "LIMIT")
                                {
                                    sqlString += " LIMIT " + cond[k] + " ;";
                                }
                                else if (k == "ORDER")
                                {
                                    var orderString = " ORDER BY ";
                                    foreach (var key in (Dictionary<string, string>)cond[k])
                                    {
                                        var lastk = GetLastKey((Dictionary<string, string>)cond[k]);
                                        if (key.Key != lastk)
                                        {
                                            orderString += key.Key + " " + key.Value.ToUpper() + " , ";
                                        }
                                        else
                                        {
                                            orderString += key.Key + " " + key.Value.ToUpper();
                                            sqlString += orderString + " ;";
                                        }
                                    }
                                }
                                else
                                {
                                    colString += " " + k + " = '" + cond[k] + "'";
                                    sqlString += colString + " ;";
                                }
                            }
                        }
                    }

                    using (var connection = new NpgsqlConnection(ConnectionString))
                    {
                        connection.Open();
                        using (var command = new NpgsqlCommand(sqlString, connection))
                        {
                            using (var reader = command.ExecuteReader())
                            {
                                var rows = new List<Dictionary<string, object>>();
                                while (reader.Read())
                                {
                                    var row = new Dictionary<string, object>();
                                    for (int i = 0; i < reader.FieldCount; i++)
                                    {
                                        row.Add(reader.GetName(i), reader.GetValue(i));
                                    }
                                    rows.Add(row);
                                }
                                return rows;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine("Error running query: " + ex.Message);
                    return new List<Dictionary<string, object>>();
                }
            });
        }

        private static string GetLastKey<T>(Dictionary<string, T> dict)
        {
            string lastKey = null;
            foreach (var key in dict.Keys)
            {
                lastKey = key;
            }
            return lastKey;
        }


        // update data

        public static async Task<int> UpdateData(string tablename, Dictionary<string, object> columns, Dictionary<string, object> cond)
        {
            using (var connectDb = new NpgsqlConnection(ConnectionString))
            {
                await connectDb.OpenAsync();

                Console.WriteLine("columns");
                Console.WriteLine(JsonSerializer.Serialize(columns));
                Console.WriteLine("cond");
                Console.WriteLine(JsonSerializer.Serialize(cond));
                Console.WriteLine("tablename");
                Console.WriteLine(tablename);

                string colString = "";
                var lastKey = GetLastKey(columns);
                foreach (var k in columns.Keys)
                {
                    if (columns[k] != null)
                    {
                        if (k != lastKey)
                        {
                            Console.WriteLine("kast jet===");

                            if (columns[k] is Array)
                            {
                                colString += $"{k} = '{JsonSerializer.Serialize(columns[k]).Replace("'", "`")}',";
                            }
                            else
                            {
                                colString += $"{k} = '{columns[k].ToString().Replace("'", "`")}',";
                            }
                        }
                        else
                        {
                            Console.WriteLine("lst key");
                            if (columns[k] is Array)
                            {
                                colString += $"{k} = '{JsonSerializer.Serialize(columns[k]).Replace("'", "`")}',";
                            }
                            else
                            {
                                colString += $"{k} = '{columns[k].ToString().Replace("'", "`")}',";
                            }
                        }
                    }
                }

                if (colString.EndsWith(","))
                {
                    colString = colString.Substring(0, colString.Length - 1);
                }

                var sqlString = $"UPDATE {tablename} SET {colString} WHERE {GetFirstKey(cond)} = '{GetFirstValue(cond)}';";
                Console.WriteLine(sqlString);

                try
                {
                    using (var cmd = new NpgsqlCommand(sqlString, connectDb))
                    {
                        var response = await cmd.ExecuteNonQueryAsync();

                        return response; // Return the row_id or null if insert failed

                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine($"Error running query: {ex.Message}");
                    throw;
                }
            }

        }

        private static string GetFirstKey(Dictionary<string, object> dict)
        {
            foreach (var key in dict.Keys)
            {
                return key;
            }
            return null;
        }

        private static object GetFirstValue(Dictionary<string, object> dict)
        {
            foreach (var value in dict.Values)
            {
                return value;
            }
            return null;
        }
    

    

    // Delete data 

        public static async Task<int> DeleteData(string tableName, Dictionary<string, object> cond)
        {
            /**
             * DELETE FROM table_name WHERE condition;
             */
            using (var connection = new NpgsqlConnection(ConnectionString))
            {
                await connection.OpenAsync();
                string op = "";
                string condValue;
                if (cond.Values.First() is Array)
                {
                    op = " IN  ";
                    List<string> tcondValue = new List<string>();
                    foreach (var item in (Array)cond.Values.First())
                    {
                        tcondValue.Add($"'{item}'");
                    }
                    condValue = "(" + string.Join(",", tcondValue) + ")";
                }
                else
                {
                    op = " = '";
                    condValue = $"{cond.Values.First()}'";
                }
                string sqlString = $"DELETE FROM {tableName} WHERE {cond.Keys.First()}{op}{condValue};";
                Console.WriteLine(sqlString);


                using (var command = new NpgsqlCommand(sqlString, connection))
                {
                    var response = await command.ExecuteNonQueryAsync();
                    return response;
                }
            }
        }



    // create table 





    } 
}






