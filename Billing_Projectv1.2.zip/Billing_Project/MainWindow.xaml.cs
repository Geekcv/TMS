﻿using Billing_Project.connect_db;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using static Npgsql.Replication.PgOutput.Messages.RelationMessage;

namespace Billing_Project
{
    public partial class MainWindow : Window
    {
        private string selectedId;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Insert Data
        private async void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtAge.Text))
                {
                    MessageBox.Show("Please enter both Name and Age.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var row_id = functions.RandomId();
                var name = txtName.Text;
                var age =Int32.Parse( txtAge.Text);

                var columns = new Dictionary<string, object>
        {
            { "row_id", row_id },
            { "name", name },
            { "age", age },
        };

                // Create instance of DatabaseHelper
                var result = await DatabaseHelper.InsertData("public.my_table1", columns);

                if (result != null)
                {
                    MessageBox.Show("Data inserted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtName.Clear();
                    txtAge.Clear();
                }
                else
                {
                    MessageBox.Show("Failed to insert data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error inserting data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }




        // Fetch Data
        private async void btnfetch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Dictionary<string, object> conditions = null;

                // Fetch data asynchronously
                List<Dictionary<string, object>> xmlResult = await DatabaseHelper.FetchDataAsync("public.my_table1", conditions);

                // Bind the result to the DataGrid
                dataGridResult.ItemsSource = ConvertToDataTable(xmlResult).DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Convert List<Dictionary<string, object>> to DataTable
        private DataTable ConvertToDataTable(List<Dictionary<string, object>> data)
        {
            DataTable table = new DataTable();

            if (data.Count == 0)
                return table;

            // Add columns
            foreach (var key in data[0].Keys)
            {
                table.Columns.Add(key, typeof(string));  // Adjust the type as needed
            }

            // Add rows
            foreach (var dict in data)
            {
                DataRow row = table.NewRow();
                foreach (var key in dict.Keys)
                {
                    row[key] = dict[key]?.ToString() ?? DBNull.Value.ToString();
                }
                table.Rows.Add(row);
            }

            return table;
        }



        // update  dadta 
        private  async void btnupdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtAge.Text))
                {
                    MessageBox.Show("Please enter both Name and Age.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var row_id = functions.RandomId();
                var name = txtName.Text;
                var age = Int32.Parse(txtAge.Text);

                var columns = new Dictionary<string, object>
                 {
                    { "name", name },
                    { "age", age },
                };

                var comm = new Dictionary<string, object>
                 {
                    { "row_id", selectedId },
                };

                // Create instance of DatabaseHelper
                var result = await DatabaseHelper.UpdateData("public.my_table1", columns,comm);

                if (result != null)
                {
                    MessageBox.Show("Data update successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtName.Clear();
                    txtAge.Clear();
                }
                else
                {
                    MessageBox.Show("Failed to updae data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error update data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void dataGridResult_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridResult.SelectedItem != null)
            {
                DataRowView row = (DataRowView)dataGridResult.SelectedItem;
                txtName.Text = row["Name"].ToString();
                txtAge.Text = row["Age"].ToString();
                selectedId = row["row_id"].ToString(); // Assuming you have an ID column
            }
        }



        // delete data
        private async void btndelete_Click(object sender, RoutedEventArgs e)
        {
            var comm = new Dictionary<string, object>
                 {
                    { "row_id", selectedId },
                };

            // Create instance of DatabaseHelper
            var result = await DatabaseHelper.DeleteData("public.my_table1",comm);

            if (result != null)
            {
                MessageBox.Show("Data delete successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                txtName.Clear();
                txtAge.Clear();
            }
            else
            {
                MessageBox.Show("Failed to delete data.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }




    }
}
