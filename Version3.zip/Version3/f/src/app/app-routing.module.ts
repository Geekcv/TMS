import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ClientAddComponent } from './client-add/client-add.component';
import { ClientShowComponent } from './client-show/client-show.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { ClientDetailsComponent } from './client-details/client-details.component';


import { authGuard } from './servies/auth.guard';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'add-client',canActivate: [authGuard], component: ClientAddComponent },
  { path: 'show-client',canActivate: [authGuard], component: ClientShowComponent },
  { path: 'edit-client/:id',canActivate: [authGuard], component: EditClientComponent } ,// Route for editing a client
  { path: 'client-details/:id',canActivate: [authGuard], component: ClientDetailsComponent } // Route for viewing client details



  // { path: '**', redirectTo: 'login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
