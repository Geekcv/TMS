import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() {}

  token: string | null = '';

  // Method to get userId from the JWT token
  getUserId(): string | null {
    this.token = localStorage.getItem('token');
    if (this.token) {
      try {
        const payload = JSON.parse(atob(this.token.split('.')[1]));
        return payload.userId || null; // Return the userId if available
      } catch (error) {
        console.error('Error decoding token:', error);
        return null;
      }
    }
    return null;
  }

  isValidToken(): boolean {
    this.token = localStorage.getItem('token');
    if (this.token) {
      try {
        const payload = JSON.parse(atob(this.token.split('.')[1]));
        const expiration = payload.exp;
        const currentTime = Math.floor(Date.now() / 1000);
        return payload.userId && currentTime < expiration;
      } catch (error) {
        console.error('Error decoding token:', error);
        return false;
      }
    }
    return false;
  }
}
