export const config = {
    // apiBaseURL : 'http://192.168.1.5:3000',
    apiBaseURL : 'http://localhost:3000',
    // cryptoSecret: "AmnVRMN38h",
}