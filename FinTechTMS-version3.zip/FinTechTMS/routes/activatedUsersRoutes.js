import express from "express";
import {
  createActivatedUser,
  getActivatedUsers,
  getActivatedUserById,
  updateActivatedUser,
  deleteActivatedUser,
} from "../controllers/activatedUsersController.js";

const router = express.Router();

router.post("/activated-users", createActivatedUser);
router.get("/activated-users", getActivatedUsers);
router.get("/activated-users/:id", getActivatedUserById);
router.put("/activated-users/:id", updateActivatedUser);
router.delete("/activated-users/:id", deleteActivatedUser);

export default router;
