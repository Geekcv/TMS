import express from "express";
import {
  assignTask,
  getTaskAssignees,
  getTaskAssigneeById,
  updateTaskAssignee,
  deleteTaskAssignee,
} from "../controllers/taskAssigneeController.js";

const router = express.Router();

router.post("/task-assignee", assignTask);
router.get("/task-assignee", getTaskAssignees);
router.get("/task-assignee/:id", getTaskAssigneeById);
router.put("/task-assignee/:id", updateTaskAssignee);
router.delete("/task-assignee/:id", deleteTaskAssignee);

export default router;
