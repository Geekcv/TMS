import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";

const SubscriptionPlans = sequelize.define("Subscription_Plans", {
  row_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  activation_plan_id: {
    type: DataTypes.INTEGER,
    unique: true,
  },
  activation_plan_name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  user_count_allowed: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
});

export default SubscriptionPlans;
