import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";
import Users from "./Users.js";
import Organisation from "./Organisation.js";
import SubscriptionPlans from "./SubscriptionPlans.js";

const ActivatedUsers = sequelize.define("Activated_Users", {
  row_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  activation_plan_id: {
    type: DataTypes.INTEGER,
    references: {
      model: SubscriptionPlans,
      key: "row_id",
    },
  },
  user_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Users,
      key: "user_id",
    },
  },
  organisation_id: {
    type: DataTypes.INTEGER,
    references: {
      model: Organisation,
      key: "organisation_id",
    },
  },
});

export default ActivatedUsers;
