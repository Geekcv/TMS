import Users from "../models/Users.js";

// Create a new user
export const createUser = async (req, res) => {
  try {
    const {
      organisation_id,
      username,
      password,
      full_name,
      email,
      activated,
      role,
    } = req.body;
    const user = await Users.create({
      organisation_id,
      username,
      password,
      full_name,
      email,
      activated,
      role,
    });
    res.status(201).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all users
export const getUsers = async (req, res) => {
  try {
    const users = await Users.findAll();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a user by ID
export const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await Users.findByPk(id);
    if (user) {
      res.status(200).json(user);
    } else {
      res.status(404).json({ error: "User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a user
export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { organisation_id, username, password, full_name, email, activated } =
      req.body;
    const user = await Users.findByPk(id);
    if (user) {
      user.organisation_id = organisation_id;
      user.username = username;
      user.password = password;
      user.full_name = full_name;
      user.email = email;
      user.activated = activated;
      await user.save();
      res.status(200).json(user);
    } else {
      res.status(404).json({ error: "User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a user
export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await Users.findByPk(id);
    if (user) {
      await user.destroy();
      res.status(200).json({ message: "User deleted successfully" });
    } else {
      res.status(404).json({ error: "User not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
