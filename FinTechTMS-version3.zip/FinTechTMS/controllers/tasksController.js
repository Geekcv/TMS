import Tasks from "../models/Tasks.js";

// Create a new task
export const createTask = async (req, res) => {
  try {
    const {
      user_id,
      task_title,
      task_description,
      completion_status,
      status_updated_by,
      priority,
    } = req.body;
    const task = await Tasks.create({
      user_id,
      task_title,
      task_description,
      completion_status,
      status_updated_by,
      priority,
    });
    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all tasks
export const getTasks = async (req, res) => {
  try {
    const tasks = await Tasks.findAll();
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get a task by ID
export const getTaskById = async (req, res) => {
  try {
    const { id } = req.params;
    const task = await Tasks.findByPk(id);
    if (task) {
      res.status(200).json(task);
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update a task
export const updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      task_title,
      task_description,
      completion_status,
      status_updated_by,
      priority,
    } = req.body;
    const task = await Tasks.findByPk(id);
    if (task) {
      task.task_title = task_title;
      task.task_description = task_description;
      task.completion_status = completion_status;
      task.status_updated_by = status_updated_by;
      task.priority = priority;
      await task.save();
      res.status(200).json(task);
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a task
export const deleteTask = async (req, res) => {
  try {
    const { id } = req.params;
    const task = await Tasks.findByPk(id);
    if (task) {
      await task.destroy();
      res.status(200).json({ message: "Task deleted successfully" });
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
