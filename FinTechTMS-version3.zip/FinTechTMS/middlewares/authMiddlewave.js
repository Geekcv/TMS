// import jwt from "jsonwebtoken";
// import User from "../models/user.js"; // Adjust the path to your Sequelize User model

import passport from "./passport.js";

// const protectRoute = async (req, res, next) => {
//   try {
//     // Retrieve the token from cookies (or headers, if that's how you store it)
//     const token =
//       req.cookies?.token || req.headers.authorization?.split(" ")[1];

//     if (token) {
//       // Verify the token
//       const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

//       // Fetch the user from the PostgreSQL database using Sequelize
//       const user = await User.findOne({
//         where: { id: decodedToken.userId },
//         attributes: ["email", "isAdmin"], // Select specific columns
//       });

//       if (!user) {
//         return res
//           .status(401)
//           .json({
//             status: false,
//             message: "Not authorized. Try logging in again.",
//           });
//       }

//       // Attach user data to the request object
//       req.user = {
//         email: user.email,
//         isAdmin: user.isAdmin,
//         userId: decodedToken.userId,
//       };

//       // Proceed to the next middleware
//       next();
//     } else {
//       return res
//         .status(401)
//         .json({
//           status: false,
//           message: "Not authorized. Try logging in again.",
//         });
//     }
//   } catch (error) {
//     console.error(error);
//     return res
//       .status(401)
//       .json({
//         status: false,
//         message: "Not authorized. Try logging in again.",
//       });
//   }
// };

// const isAdminRoute = (req, res, next) => {
//   if (req.user && req.user.isAdmin) {
//     next();
//   } else {
//     return res.status(401).json({
//       status: false,
//       message: "Not authorized as admin. Try login as admin.",
//     });
//   }
// };

// export { isAdminRoute, protectRoute };

export const ensureAuthenticated = (req, res, next) => {
  passport.authenticate("jwt", { session: false }, (err, user) => {
    if (err || !user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    req.user = user;
    next();
  })(req, res, next);
};

export const authorizeRoles =
  (...roles) =>
  (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Forbidden: Access is denied" });
    }
    next();
  };
