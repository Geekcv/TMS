// simple array
arr = [1, 2, 3, 4, 5];
console.log(arr);

// add
// console.log(arr.push(6));
// console.log(arr);

// remove
// console.log(arr.pop());
// console.log(arr);

// shift
// console.log(arr.shift());
// console.log(arr);

// unshift
// console.log(arr.unshift(45));
// console.log(arr);

// filter
// console.log(arr.filter((item) => item < 3));

// map
console.log(arr.map((item) => item * 2));
console.log(arr);
