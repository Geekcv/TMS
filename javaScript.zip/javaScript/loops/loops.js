// for

// for (let i = 0; i < 10; i++) {
//   console.log("hello abhi");
// }

// while

// let i = 0;

// while (i < 10) {
//   console.log("abhishek");
//   i++;
// }

// for-of
// arr = [1, 2, 3, 4, 5];
// for (const iterator of arr) {
//   console.log(iterator);
// }

// for - in
obj1 = {
  name: "abhishek",
  age: 22,
  address: "mandore",
};

for (const key in obj1) {
  console.log(obj1[key]);
}

// for (const key in obj1) {
//   if (Object.hasOwnProperty.call(obj1, key)) {
//     const element = obj1[key];
//     console.log(element);
//   }
// }
