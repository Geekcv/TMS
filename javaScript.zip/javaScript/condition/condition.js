// if

// x = 10;
// let x;
// if (x) {
//   console.log("X is true:", x);
// }

// if - else

// let x = 2;
// if (x) {
//   console.log("x is true");
// } else {
//   console.log("x is false");
// }

// esle if

// let x = 30;
// let y = 30;

// if (x == 2) {
//   console.log("x is :", x);
// } else if (x > y) {
//   console.log("x is greater than y");
// } else if (x < y) {
//   console.log("x is less than y");
// } else {
//   console.log("x is equal to y");
// }

// ternary
// let x = 100;
// let y = 20;

// console.log(x > y ? "X is greater than Y" : "Y is greater than X");

// switch case

let x = 1;

switch (x) {
  case 1:
    console.log("X is  1");
    break;
  case 2:
    console.log("x is 2");
    break;

  case 5:
    console.log("x is 5");
    break;

  default:
    console.log("no match foud");
}
