// // old function
// function sum(a, b) {
//   return a + b;
// }

// console.log(sum(3, 4));

// // arrow function

// const result = (x, y) => {
//   return x * y;
// };

// console.log(result(4, 5));
