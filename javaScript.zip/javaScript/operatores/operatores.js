//arithmetic
// x = 5;
// y = 6;

// console.log("x+y:", x + y);
// console.log("x-y:", x - y);
// console.log("x*y:", x * y);
// console.log("x/y:", x / y);
// console.log("x%y:", x % y);
// console.log("x**y:", x ** y);

// assignments
// x = 4;
// x += 2; // x=x+2
// x -= 2;
// x *= 2;
// x /= 2;
// x %= 2;
// console.log(x);

// compare  result always boolean
// x = 5;
// y = 3;

// console.log(x > y);
// console.log(x < y);
// console.log(x <= y);
// console.log(x >= y);
// console.log(x == y);
// console.log(x === y);
// console.log(x != y);

// logical

// x = true;
// y = false;

// console.log(x && y);
// console.log(x || y);
// console.log(!x);

// spread and rest operatores

// copy array
// arr = [1, 2, 3, 4, 5];
// arr2 = [...arr];
// console.log(arr, arr2);

// merage array
arr1 = [1, 2, 3, 4, 5];
arr2 = [9, 10, 11, 12];

arr3 = [...arr1, ...arr2];
console.log(arr3);
