// add multiple string
// name = "abhishek";
// last_name = "cv";
// address = "mondore";
// console.log(name + " " + last_name + " " + address);

// using concat method
// name = "abhishek";
// last_name = "cv";
// address = "mondore 123 ";
// console.log(name.concat(" ", last_name, " ", address));

// substring
// name = "abhishek";
// console.log(name.substring(0, 2));

// length of string
// name = "abhishek";
// console.log(name.length);

// uppercase and lowercase string
// name = "abhishek";
// console.log(name.toUpperCase());
// console.log(name.toLowerCase());

// split
// name = "abhishek/cv/kirti";
// console.log(name.split("/"));

// replace method
// name = "abhishek cv";
// console.log(name.replace("cv", "kirti"));

// trim , do right and left space remove
// name = "                             abhisek                         ";
// console.log(name);
// console.log(name.trim());
