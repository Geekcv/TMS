// variables

// // var
// var name = "abhishek";
// console.log("name-", name);

// // let
// let father_name = "nagina ram";
// console.log("father_name-", father_name);

// // cosnt
// const bro = "kirti raj";
// console.log("bro-", bro);

// var can be re decalr and update value
// var a = 10;
// a = 40;
// var a = 50;
// console.log(a);

// let can be update value but no re decalr value
// let a = 100;
// a = 300;
// let a= 400;
// console.log(a);

// const can not be update and re decalr value
// const a = 700;
// // a = 600;
// const  a =899;
// console.log(a);

// var with function
// function print() {
//   var a = 10;
//   // a = 40;
//   console.log(a);
// }

// print();

// console.log(a);

// let is block level scope

// function print() {
//   let a = 10;
//   //   a = 40;
//   console.log(a);
// }

// print();

// console.log(a);
