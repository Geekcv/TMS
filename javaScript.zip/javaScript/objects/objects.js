// abhishek

let employee = {
  name: "abhishek",
  others_details: { age: 22, gender: "male" },
  hobbies: ["play games", "watch movies"],
  greet: function () {
    console.log("hello", this.name);
  },
};

console.log(employee.name);
console.log(employee.others_details);
console.log(employee.hobbies);
// console.log(employee.greet());
employee.greet();
