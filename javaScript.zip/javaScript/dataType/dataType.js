// //number
// a = 10;
// console.log(a);

// // string
// // name = "abhishek";
// // name = "abhishek";
// name = `abhishek`;
// console.log(name);

// //boolean
// yes = true;
// no = false;
// console.log(yes, no);

// //undefined
// let value;
// console.log(value);

// //null
// let address = null;
// console.log(address);

// object
// ob1 = {
//   name: "abhishek",
//   age: 22,
//   greeting() {
//     return console.log("hello abhishek");
//   },
// };

// console.log(ob1.age);
// console.log(ob1.name);
// console.log(ob1.greeting());

// array
arr = [1, 2, 3, 45, 5];
console.log(arr);
arr2 = [1, 2.3, "abh", true];
console.log(arr2);
