import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../servies/auth.service';


interface Client {
  row_id: string; // Client ID as a string
  name: string;
  description: string;
}

interface Documentsconfig {
  name: any;
  size: any;
  photourl:any;
  client_id: string;
  row_id: string;
  user_id: string;
}

@Component({
  selector: 'app-file-own',
  templateUrl: './file-own.component.html',
  styleUrls: ['./file-own.component.css'],
})
export class FileOwnComponent {
  private uploadUrl = 'http://localhost:3000/common/uploads';
  constructor(private http: HttpClient, 
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private route: ActivatedRoute,

    private authService: AuthService) {}

  // async onFileSelected(event: Event): Promise<void> {
  //   const input = event.target as HTMLInputElement;
  //   if (input.files && input.files.length > 0) {
  //     const files = Array.from(input.files);

  //     files.forEach((file) => {
  //       const formData = new FormData();
  //       formData.append('file', file);

  //       this.http.post(this.uploadUrl, formData).subscribe({
  //         next: (response: any) => {
  //           console.log('Upload successful:', response);
  //           this.uploadedFiles1.push({ name: file.name, size: file.size });
  //           this.uploadSuccessMessage = `File "${file.name}" uploaded successfully!`;
  //           setTimeout(() => (this.uploadSuccessMessage = ''), 5000); // Clear after 5 seconds
  //         },
  //         error: (error) => {
  //           console.error('Upload failed:', error);
  //           this.uploadErrorMessage = `Failed to upload "${file.name}". Please try again.`;
  //           setTimeout(() => (this.uploadErrorMessage = ''), 5000); // Clear after 5 seconds
  //         },
  //       });



  //     });
  //   }

  //   const userId = this.authService.getUserId();
      

  //     // Include uploaded file path in the form data
  //     const clientData = { 
  //       userId: userId,
  //       documentsConfig:this.uploadedFiles1
  //       photourl: this.uploadedFilePath // Include file path from the upload response
  //     };

  //     const resp = await this.Apicontroller.createClient(clientData);

  // }

  clientId!: string | null; // Holds the client ID from the route
  projectId!: string | null; // Holds the project  ID from the route

  userId!:string |null;

  client!: Client; // Holds the client details

  // Simulated data source (replace with actual service)
  clients: Client[] = [];

  Documentsconfig: Documentsconfig[] = []; // Array of password


  async ngOnInit(): Promise<void> {
    this.clientId = this.route.snapshot.paramMap.get('clientId');
    console.log("clientid",this.clientId)
    this.projectId = this.route.snapshot.paramMap.get('projectId');
    console.log("projectId",this.projectId)
    const userId = this.authService.getUserId(); // Fetch the user ID

    this.userId = userId;
    
    if (!this.clientId) {
      console.error('Client ID not provided');
      this.router.navigate(['/']); // Redirect if ID is missing
      return;
    }

    console.log('Client ID:', this.clientId);

    await this.fetchClients(); // Fetch client data
    await this.fetchDocumentsconfig(); // Fetch links for the client

    this.loadClientData(this.clientId); // Load client data

    
  }



  async fetchClients(): Promise<void> {
    try {
      const response = await this.Apicontroller.fetchClient();
      this.clients = response.data || []; // Ensure `data` exists in the API response
    } catch (error) {
      console.error('Error fetching clients:', error);
    }
  }


  loadClientData(id: string): void {
    const client = this.clients.find((client) => client.row_id === id);
    if (client) {
      this.client = client;
      console.log('Found client:', this.client);
    } else {
      console.error(`Client with ID "${id}" not found`);
      // this.router.navigate(['/show-client']); // Redirect if client not found
    }
  }


  async fetchDocumentsconfig(): Promise<void> {
    try {
      const response = await this.Apicontroller.fetchdocumentsConfig(this.projectId);
      console.log('Response from documentsConfig:', response);
  
      // Process the response to flatten and map the documentsConfig
      this.Documentsconfig = response?.data?.flatMap((item: any) => 
        item.documentsconfig.map((doc: any) => ({
          name: doc.name,
          size: doc.size,
          photourl: doc.photourl,
          client_id: item.client_id,
          row_id: item.row_id,
          user_id: item.user_id,
        }))
      ) || []; // Default to an empty array if `data` or `documentsconfig` is undefined
  
      console.log('Processed documentsConfig for client:', this.Documentsconfig);
    } catch (error) {
      console.error('Error fetching documentsConfig:', error);
      this.Documentsconfig = []; // Default to an empty array in case of an error
    }
  }
  














  uploadedFiles1: { name: string; size: number;photourl?: string;}[] = [];

 // uploadedFiles1: Array<{ name: string; size: number; photourl?: string }> = []; // Array to store uploaded file details with photourl
uploadSuccessMessage: string = ''; // Message for successful uploads
uploadErrorMessage: string = ''; // Message for failed uploads

// onFileSelected(event: Event): void {
//   const input = event.target as HTMLInputElement;
//   if (input.files && input.files.length > 0) {
//     const files = Array.from(input.files); // Handle multiple files

//     files.forEach((file) => {
//       const formData = new FormData();
//       formData.append('file', file);

//       this.http.post('http://localhost:3000/common/uploads', formData).subscribe({
//         next: (response: any) => {
//           console.log('Upload successful:', response);

//           // Extract file path from server response
//           const filePath = response?.rsp?.data?.filesInfo?.[0]?.foPa;
//           if (filePath) {
//             // Add file details including photourl to uploadedFiles1
//             this.uploadedFiles1.push({ name: file.name, size: file.size, photourl: filePath});
//             this.uploadSuccessMessage = `File "${file.name}" uploaded successfully!`;

//             // Optional: Update client data with uploaded file info
//             const clientData = {
//               user_id: this.userId,
//               client_id: this.clientId,
//               project_id:this.projectId,
//               documentsConfig: this.uploadedFiles1, // Includes photourl now
//             };

//             this.Apicontroller.createDouments(clientData)
//               .then(async () => {
//                 console.log('Client data updated successfully.');
//                 // Clear the uploadedFiles1 array after database update
//                 this.uploadedFiles1 = [];
//                 await this.fetchDocumentsconfig(); // Fetch links for the client
//               })
//               .catch((error) => {
//                 console.error('Failed to update client data:', error);
//               });

//             setTimeout(() => (this.uploadSuccessMessage = ''), 5000); // Clear message
//           } else {
//             console.error('Unexpected response format:', response);
//             this.uploadErrorMessage = `File "${file.name}" upload failed. Invalid server response.`;
//             setTimeout(() => (this.uploadErrorMessage = ''), 5000); // Clear message
//           }
//         },
//         error: (error) => {
//           console.error('Upload failed:', error);
//           this.uploadErrorMessage = `Failed to upload "${file.name}". Please try again.`;
//           setTimeout(() => (this.uploadErrorMessage = ''), 5000); // Clear message
//         },
//       });
//     });
//   }
// }



onFileSelected(event: Event): void {
  const input = event.target as HTMLInputElement;

  if (input.files && input.files.length > 0) {
    const files = Array.from(input.files); // Handle multiple files

    files.forEach((file) => {
      // Check for duplicates in uploadedFiles1 array
      const isDuplicate = this.uploadedFiles1.some(
        (uploadedFile) => uploadedFile.name === file.name && uploadedFile.size === file.size
      );

      if (isDuplicate) {
        console.warn(`File "${file.name}" is already uploaded.`);
        this.uploadErrorMessage = `File "${file.name}" is already uploaded.`;
        setTimeout(() => (this.uploadErrorMessage = ''), 5000);
        return;
      }

      const formData = new FormData();
      formData.append('file', file);

      this.http.post('http://localhost:3000/common/uploads', formData).subscribe({
        next: (response: any) => {
          console.log('Upload successful:', response);

          // Extract file path from server response
          const filePath = response?.rsp?.data?.filesInfo?.[0]?.foPa;
          if (filePath) {
            const newFile = { name: file.name, size: file.size, photourl: filePath };

            // Add file details to uploadedFiles1 array
            this.uploadedFiles1.push(newFile);
            this.uploadSuccessMessage = `File "${file.name}" uploaded successfully!`;

            // Prepare client data for database
            const clientData = {
              user_id: this.userId,
              client_id: this.clientId,
              project_id: this.projectId,
              documentsConfig: [newFile], // Push only the newly uploaded file
            };

            this.Apicontroller.createDouments(clientData)
              .then(async () => {
                console.log(`File "${file.name}" added to the database successfully.`);
                await this.fetchDocumentsconfig(); // Refresh document list
              })
              .catch((error) => {
                console.error('Failed to update client data in the database:', error);
              });

            setTimeout(() => (this.uploadSuccessMessage = ''), 5000);
          } else {
            console.error('Unexpected response format:', response);
            this.uploadErrorMessage = `File "${file.name}" upload failed. Invalid server response.`;
            setTimeout(() => (this.uploadErrorMessage = ''), 5000);
          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
          this.uploadErrorMessage = `Failed to upload "${file.name}". Please try again.`;
          setTimeout(() => (this.uploadErrorMessage = ''), 5000);
        },
      });
    });
  } else {
    console.warn('No files selected.');
  }
}



  deleteFile(index: number): void {
    this.uploadedFiles1.splice(index, 1);
  }

  // downloadFile(file: { name: string }): void {
  //   window.open(`${this.uploadUrl}/${file.name}`, '_blank');
  // }


  
  

  downloadFile(documentsconfig: { name: string; photourl: string }): void {
    if (!documentsconfig.photourl) {
      console.error('File URL is missing for', documentsconfig.name);
      return;
    }
  
    // Construct the full file URL
    const fileUrl = `http://localhost:3000/uploads/${documentsconfig.photourl}`;
  
    // Create an anchor element to trigger the download
    const link = document.createElement('a');
    link.href = fileUrl;
    link.download = documentsconfig.name; // Suggests a filename
    // link.target = '_blank'; // Optional: opens in a new tab
    link.click();
  }
  
  
  
  
  

  getFileLogo(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return 'assets/icons/p1.png';
      case 'doc':
      case 'docx':
        return 'assets/icons/d1.jpg';
      case 'txt':
        return 'assets/icons/txt-icon.png';
      case 'png':
      case 'jpg':
      case 'jpeg':
        return 'assets/icons/i1.jpg';
      default:
        return 'assets/icons/default-icon.png';
    }
  }
}
