import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileOwnComponent } from './file-own.component';

describe('FileOwnComponent', () => {
  let component: FileOwnComponent;
  let fixture: ComponentFixture<FileOwnComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FileOwnComponent]
    });
    fixture = TestBed.createComponent(FileOwnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
