import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApicontrollerService } from '../controller/apicontroller.service';
interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
}

@Component({
  selector: 'app-client-show',
  templateUrl: './client-show.component.html',
  styleUrls: ['./client-show.component.css']
})
export class ClientShowComponent {
  clients: Client[] = [
    
    // { id: 1, name: 'John Doe', email: 'john@example.com', phone: '123-456-7890' },
    // { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '098-765-4321' },
    // Add more clients as needed
  ];

  constructor(private router: Router,private Apicontroller: ApicontrollerService) {
   
    this.fetch()

    
  }
  
  async fetch(){
    const resp = await this.Apicontroller.fetchClient();
    this.clients = resp.data
  }

  editClient(clientId: number) {
    this.router.navigate(['edit-client', clientId]);
  }

  viewClientDetails(clientId: number) {
    this.router.navigate(['/client-details', clientId]);
  }


}
