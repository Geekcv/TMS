import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { AuthService } from '../servies/auth.service';


interface Client {
  row_id: string; // Client ID as a string
  name: string;
  description: string;
}

interface Credentials {
  username: string;
  password: string;
  client_id: string;
  row_id: string;
  user_id: string;
}

@Component({
  selector: 'app-credentials',
  templateUrl: './credentials.component.html',
  styleUrls: ['./credentials.component.css']
})
export class CredentialsComponent {

  clientId!: string | null; // Holds the client ID from the route
  projectId!: string | null; // Holds the project  ID from the route

  client!: Client; // Holds the client details

  // Simulated data source (replace with actual service)
  clients: Client[] = [];
  Credentials: Credentials[] = []; // Array of password






  credentials = [{ username: 'ABCD', password: '****' }];

  isCredentialDialogVisible = false;

  currentCredential: Credentials = { username: '', password: '', client_id: '', row_id: '', user_id: '' }; // Default empty values


  editIndex = -1;


  showPassword: boolean = false;  // Toggle password visibility
  
  // Toggle password visibility
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }



  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService
  ) {}



  async ngOnInit(): Promise<void> {
    this.clientId = this.route.snapshot.paramMap.get('clientId');
    console.log("clientid",this.clientId)
    this.projectId = this.route.snapshot.paramMap.get('projectId');
    console.log("projectId",this.projectId)

    if (!this.clientId) {
      console.error('Client ID not provided');
      this.router.navigate(['/']); // Redirect if ID is missing
      return;
    }

    console.log('Client ID:', this.clientId);

    await this.fetchClients(); // Fetch client data
    await this.fetchcredentials(); // Fetch links for the client

    this.loadClientData(this.clientId); // Load client data
  }


  async fetchClients(): Promise<void> {
    try {
      const response = await this.apiController.fetchClient();
      this.clients = response.data || []; // Ensure `data` exists in the API response
    } catch (error) {
      console.error('Error fetching clients:', error);
    }
  }


  loadClientData(id: string): void {
    const client = this.clients.find((client) => client.row_id === id);
    if (client) {
      this.client = client;
      console.log('Found client:', this.client);
    } else {
      console.error(`Client with ID "${id}" not found`);
      // this.router.navigate(['/show-client']); // Redirect if client not found
    }
  }


  async fetchcredentials(): Promise<void> {
    try {
      const response = await this.apiController.fetchCredentialsclient(this.clientId);
      console.log('Response from fetchcredential:', response);

      // Process the response to extract links
      this.Credentials = response?.data?.map((item: any) => ({
        ...item.credentials, // Extract the `links` object properties
        client_id: item.client_id, // Add the client_id
        row_id: item.row_id, // Add the row_id
        user_id: item.user_id, // Add the user_id
      })) || []; // Default to an empty array if `data` or `links` is undefined

      console.log('Processed credential for client:======', this.Credentials);
    } catch (error) {
      console.error('Error fetching credential:', error);
      this.Credentials = []; // Default to an empty array in case of an error
    }
  }

  openCredentialDialog() {
    this.currentCredential  = { username: '', password: '', client_id: '', row_id: '', user_id: '' }; // Default empty values

    this.editIndex = -1;
    this.isCredentialDialogVisible = true;
  }

  editCredential(credential: any, index: number) {
    this.currentCredential = { ...credential };
    this.editIndex = index;
    this.isCredentialDialogVisible = true;
  }

  async saveCredential() {
    if (!this.currentCredential.username || !this.currentCredential.password) {
      console.error('username and password fields are required.');
      return;
    }
  
    try {
      const userId = this.authService.getUserId();
    var project_id = this.route.snapshot.paramMap.get('id');

      const credentialsData = {
        credentials: this.currentCredential,
        userId,
        client_id: this.clientId,
        // project_id:project_id
        row_id: this.currentCredential.row_id, // Ensure the row_id is included
      };
  
      // Log the data to make sure it's correct
      console.log('credential data being sent:', credentialsData);
  
      if (this.editIndex >= 0) {
        // Edit existing link
        this.credentials[this.editIndex] = this.currentCredential;
      } else {
        // Add new link
        this.credentials.push(this.currentCredential);
      }
  
      // Save links to the backend
      const response = await this.apiController.createCredentials(credentialsData);
      console.log('credential saved successfully:', response);
    } catch (error) {
      console.error('Failed to save credential:', error);
    } finally {
      this.closeCredentialDialog();
    }
  }

  closeCredentialDialog() {
    this.isCredentialDialogVisible = false;
  }

}
