import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  menuItems: any[] = [];
  isLoggedIn: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Check if user is logged in by checking the token in localStorage
    this.isLoggedIn = !!localStorage.getItem('token'); // if token exists, user is logged in

    // Define the menu items
    this.menuItems = [
      { label: 'Home', icon: 'pi pi-home', command: () => this.router.navigate(['/']) },
      { label: 'Add Client', icon: 'pi pi-plus', command: () => this.router.navigate(['/add-client']) },
      { label: 'Show Clients', icon: 'pi pi-users', command: () => this.router.navigate(['/show-client']) },
      // { label: 'Client Details', icon: 'pi pi-info-circle', command: () => this.router.navigate(['/client-details/1']) },
      // { label: 'Edit Client', icon: 'pi pi-pencil', command: () => this.router.navigate(['/edit-client/1']) },
    ];
  }

  logout(): void {
    // Remove token from localStorage
    localStorage.removeItem('token');

    // Set isLoggedIn to false to hide the logout button
    this.isLoggedIn = false;

    // Redirect to login page
    this.router.navigate(['/login']);
  }
}
