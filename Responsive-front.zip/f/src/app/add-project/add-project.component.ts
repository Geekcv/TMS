import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../servies/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {
  projectForm: FormGroup;
  clientId!: string | null; // Holds the client ID from the route

  
  statusOptions: { label: string, value: string }[] = [
    { label: 'Pending', value: 'Pending' },
    { label: 'In Progress', value: 'In Progress' },
    { label: 'Completed', value: 'Completed' }
  ]; // Define status options for the dropdown


  constructor(private fb: FormBuilder,    private Apicontroller: ApicontrollerService,
    private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,

    private authService: AuthService  // Inject AuthService
) {
    // Initialize the form
    this.projectForm = this.fb.group({
      project_name: ['', Validators.required],
      description: ['', Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      status: ['', Validators.required]  // Make sure to add 'status' control to your form group
    });
  }

  ngOnInit(): void {

    this.clientId = this.route.snapshot.paramMap.get('id');
    console.log("clientid",this.clientId)
  }

  uploadedFilePath: string = ''; // To store the uploaded file's path
  errorMessage: string = '';

onFileSelected(event: Event): void {
  const input = event.target as HTMLInputElement;
  if (input.files && input.files.length > 0) {
    const file = input.files[0];
    const formData = new FormData();
    formData.append('file', file);

    this.http.post('http://localhost:3000/common/uploads', formData).subscribe({
      next: (response: any) => {
        console.log('Upload successful:', response);
        // Extract the file path from the response
        if (response?.rsp?.data?.filesInfo?.[0]?.foPa) {
          this.uploadedFilePath = response.rsp.data.filesInfo[0].foPa;
          console.log('Uploaded File Path:', this.uploadedFilePath);
        } else {
          console.error('Unexpected response format:', response);
          this.errorMessage = 'File upload failed. Invalid server response.';
        }
      },
      error: (error) => {
        console.error('Upload failed:', error);
        this.errorMessage = 'File upload failed. Please try again.';
      },
    });
  }
}

  async onSubmit(): Promise<void> {
    // Handle form submission
    const userId = this.authService.getUserId();
    
    const projectData = { 
      ...this.projectForm.value,
      user_id: userId,
      client_id:this.clientId,
      photo_path:this.uploadedFilePath
    };
    console.log(this.projectForm.value);
    const resp = await this.Apicontroller.createProject(projectData)
    console.log(resp)

    if (resp.status === 0) {
      console.log('project added successfully!')
      setTimeout(() => {
        this.router.navigate(['/client-details',this.clientId]);
      }, 1000);
    } else {
      console.log('Failed to add project. Please try again.')

    }
    
  }

  
}
