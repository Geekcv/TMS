
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { AuthService } from '../servies/auth.service';

interface Client {
  row_id: string; // Client ID as a string
  name: string;
  description: string;
}

interface Link {
  title: string;
  link: string;
  client_id: string;
  row_id: string;
  user_id: string;
}
@Component({
  selector: 'app-projectdetails',
  templateUrl: './projectdetails.component.html',
  styleUrls: ['./projectdetails.component.css']
})
export class ProjectdetailsComponent {
  clientId!: string | null; // Holds the client ID from the route
  projectId!: string | null; // Holds the client ID from the route

  client!: Client; // Holds the client details

  // Simulated data source (replace with actual service)
  clients: Client[] = [];
  links: Link[] = []; // Array of links

  // Dialog Flags
  isLinkDialogVisible = false;

  // Temporary Objects for Dialogs
  currentLink: Link = { title: '', link: '', client_id: '', row_id: '', user_id: '' }; // Default empty values
  // currentLink: Link = { title: '', link: '' }; // Default empty values

  editIndex = -1;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService
  ) {}

  async ngOnInit(): Promise<void> {
    this.clientId = this.route.snapshot.paramMap.get('clientId');
    console.log("clientid",this.clientId)
    this.projectId = this.route.snapshot.paramMap.get('projectId');
    console.log("projectId",this.projectId)

    if (!this.clientId) {
      console.error('Client ID not provided');
      this.router.navigate(['/']); // Redirect if ID is missing
      return;
    }

    console.log('Client ID:', this.clientId);

    await this.fetchClients(); // Fetch client data
    await this.fetchLinks(); // Fetch links for the client

    this.loadClientData(this.clientId); // Load client data
  }

  // Fetch all clients from the API
  async fetchClients(): Promise<void> {
    try {
      const response = await this.apiController.fetchClient();
      this.clients = response.data || []; // Ensure `data` exists in the API response
    } catch (error) {
      console.error('Error fetching clients:', error);
    }
  }

  // Load a specific client's data based on ID
  loadClientData(id: string): void {
    const client = this.clients.find((client) => client.row_id === id);
    if (client) {
      this.client = client;
      console.log('Found client:', this.client);
    } else {
      console.error(`Client with ID "${id}" not found`);
      // this.router.navigate(['/show-client']); // Redirect if client not found
    }
  }

  // Fetch links associated with the client
  async fetchLinks(): Promise<void> {
    try {
      const response = await this.apiController.fetchlinksclient(this.clientId);
      console.log('Response from fetchLinks:', response);

      // Process the response to extract links
      this.links = response?.data?.map((item: any) => ({
        ...item.links, // Extract the `links` object properties
        client_id: item.client_id, // Add the client_id
        row_id: item.row_id, // Add the row_id
        user_id: item.user_id, // Add the user_id
      })) || []; // Default to an empty array if `data` or `links` is undefined

      console.log('Processed links for client:', this.links);
    } catch (error) {
      console.error('Error fetching links:', error);
      this.links = []; // Default to an empty array in case of an error
    }
  }

  // Open the dialog for adding a new link
  openLinkDialog(): void {
    this.currentLink = { title: '', link: '', client_id: '', row_id: '', user_id: '' }; // Clear the current link object
    // this.currentLink = { title: '', link: '' }; // Clear the current link object
    
    this.editIndex = -1; // Reset edit index to indicate adding a new link
    this.isLinkDialogVisible = true; // Open the dialog
  }

  // Open the dialog for editing an existing link
  editLink(link: Link, index: number): void {
    this.currentLink = { ...link }; // Clone the selected link
    this.editIndex = index; // Set the index for editing
    this.isLinkDialogVisible = true; // Open the dialog
  }

  // Save a new or edited link
  async saveLink() {
    if (!this.currentLink.title || !this.currentLink.link) {
      console.error('Title and Link fields are required.');
      return;
    }
  
    try {
      const userId = this.authService.getUserId();
    var project_id = this.projectId

      const linkData = {
        links: this.currentLink,
        userId,
        client_id: this.clientId,
        project_id:project_id,
        row_id: this.currentLink.row_id, // Ensure the row_id is included
      };
  
      // Log the data to make sure it's correct
      console.log('Link data being sent:', linkData);
  
      if (this.editIndex >= 0) {
        // Edit existing link
        this.links[this.editIndex] = this.currentLink;
      } else {
        // Add new link
        this.links.push(this.currentLink);
      }
  
      // Save links to the backend
      const response = await this.apiController.createlinks(linkData);
      console.log('Links saved successfully:', response);
    } catch (error) {
      console.error('Failed to save link:', error);
    } finally {
      this.closeLinkDialog();
    }
  }
  
  
  // Close the dialog
  closeLinkDialog(): void {
    this.isLinkDialogVisible = false;
  }

  goBackToClientDetails() {
    if (this.clientId) {
      this.router.navigate(['/client-details', this.clientId]); // Navigate back to client details page
    }
  }
}
