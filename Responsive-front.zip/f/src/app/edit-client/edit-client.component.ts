import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApicontrollerService } from '../controller/apicontroller.service';
import { HttpClient } from '@angular/common/http';

interface Client {
  row_id: string; // Client ID as a string
  name: string;
  description: string;
  photourl: string | null;  // Client image path
}

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.css']
})
export class EditClientComponent implements OnInit {
  clientForm!: FormGroup;
  clientId!: string | null; // Holds the client ID from the route
  clients: Client[] = []; // Clients fetched from the API
  clientImage: string | null = null; // Holds the current client image URL

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private http: HttpClient,

    private router: Router,
    private apiController: ApicontrollerService // Corrected service casing
  ) {
    // Initialize the form with validation rules
    this.clientForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      photourl: [null]  // Add this field to store the uploaded image
    });
  }

  async ngOnInit(): Promise<void> {
    // Get the client ID from the route
    this.clientId = this.route.snapshot.paramMap.get('id');
  
    if (!this.clientId) {
      console.error('Client ID not provided');
      this.router.navigate(['/']); // Redirect if ID is missing
      return;
    }
  
    console.log('Client ID:', this.clientId);
  
    // Fetch clients and load the form data
    await this.fetchClients();
    this.loadClientData(this.clientId);
  }
  

  async fetchClients(): Promise<void> {
    try {
      const response = await this.apiController.fetchClient();
      this.clients = response.data; // Assuming the API response includes a `data` property
    } catch (error) {
      console.error('Error fetching clients:', error);
      // Handle error, e.g., show an error message or redirect
    }
  }

  loadClientData(id: string): void {
    // Find the client by row_id
    const client = this.clients.find(client => client.row_id === id);

    if (client) {
      console.log('Found client:', client);
      // Populate the form with existing client data
      this.clientForm.patchValue(client);
      this.clientImage = client.photourl || null;  // Set the client's image if available
    } else {
      console.error(`Client with ID "${id}" not found`);
      // Redirect if the client is not found
      this.router.navigate(['/show-client']);
    }
  }

  uploadedFilePath: string = ''; // To store the uploaded file's path
  errorMessage: string = '';
  successMessage: string = '';

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);
  
      this.http.post('http://localhost:3000/common/uploads', formData).subscribe({
        next: (response: any) => {
          console.log('Upload successful:', response);
          // Extract the file path from the response
          if (response?.rsp?.data?.filesInfo?.[0]?.foPa) {
            this.uploadedFilePath = response.rsp.data.filesInfo[0].foPa;
            console.log('Uploaded File Path:', this.uploadedFilePath);
          } else {
            console.error('Unexpected response format:', response);
            this.errorMessage = 'File upload failed. Invalid server response.';
          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
          this.errorMessage = 'File upload failed. Please try again.';
        },
      });
    }
  }



  async onSubmit(): Promise<void> {
    if (this.clientForm.valid) {
      try {

        const photourl = this.uploadedFilePath || this.clientImage;

        const updatedClientData = { row_id: this.clientId, ...this.clientForm.value, photourl };
        console.log('Updated Client Data:', updatedClientData);

        // Call the API to update the client data
        const response = await this.apiController.createClient(updatedClientData);

        if (response.status == 0) {
          console.log('Client updated successfully');
          // Navigate to the client list after a successful update
          this.router.navigate(['/show-client']);
        } else {
          console.error('Failed to update client:', response.message);
        }
      } catch (error) {
        console.error('Error updating client:', error);
      }
    } else {
      console.error('Form is invalid');
    }
  }

  }