edit only
index.js

npm i  
npm start
