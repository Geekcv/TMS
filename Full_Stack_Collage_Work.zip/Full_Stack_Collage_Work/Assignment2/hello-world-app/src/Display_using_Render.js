// src/App.js

import React, { Component } from "react";
import "./App.css";

class Display_using_Render extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1>Display content using render function.</h1>
        </header>
      </div>
    );
  }
}

export default Display_using_Render;
