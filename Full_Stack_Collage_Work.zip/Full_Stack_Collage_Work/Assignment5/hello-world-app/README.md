npm install -g @angular/cli
ng --version
ng generate component component-name
ng serve --open

edit only
app.component.app
