import { Component } from '@angular/core';

@Component({
  selector: 'app-angular-expressions-binding',
  standalone: true,
  imports: [],
  templateUrl: './angular-expressions-binding.component.html',
  styleUrl: './angular-expressions-binding.component.css'
})
export class AngularExpressionsBindingComponent {
  name="abhishek";
  age=21;
  Course="MCA";

}
