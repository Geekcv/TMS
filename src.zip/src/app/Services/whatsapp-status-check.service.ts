import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WhatsappStatusCheckService {


    private whatsappStatus: any;

     setwhatsappStatus(Status: any) {
    this.whatsappStatus = Status;
    console.log("set whats appp status",this.whatsappStatus)
  }

  getwhatsappStatus() {
    // console.log("inside get whatsappStatus in whatsapp service",this.whatsappStatus)
    return this.whatsappStatus;
  }



   private role: string | null = null;
  private permissions: string[] = [];

  setPermissions(role: string, permissions: string[]) {
    this.role = role;
    this.permissions = permissions;
  }

  hasPermission(permission: string) {
    return this.permissions.includes(permission);
  }

  setRole(roleName: string) {
    // console.log("before set role: setep 1",this.role,"rolename:",roleName)
    this.role = roleName;
  }

  getRole() {
    // console.log("fetch role : step 2",this.role)
    return this.role;
  }

   isLoggedIn(): boolean {
    return this.role !== 'guest';
  }


  clear(){
    this.role = '';
    this.permissions = [];
    this.whatsappStatus = ''

  }

  // constructor() { }
}
