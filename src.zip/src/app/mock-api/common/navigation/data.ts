/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    // Super Admin - Full Access

        if (role === 'admin') {
    navigation.push(
        {
            id: 'dashboard',
            title: 'Dashboard',
            type: 'basic',
            icon: 'mat_solid:dashboard',
            link: '/dashboard',
        },
        {
            id: 'contacts',
            title: 'Contacts',
            type: 'basic',
            icon: 'heroicons_outline:user-group',
            link: '/contacts',
        },
        //  {
        //     id: 'Wallet',
        //     title: 'Wallet',
        //     type: 'basic',
        //     icon: 'heroicons_outline:wallet',
        //     link: '/wallet',
        // },

            {
                id: 'messaging',
                title: 'Messaging',
                type: 'collapsable',
                icon: 'heroicons_outline:chat-bubble-bottom-center-text', 
                children: [
                    {
                        id: 'campaigns',
                        title: 'Campaigns',
                        type: 'basic',
                        icon: 'heroicons_outline:radio',
                        link: '/campaign',
                    },
                    {
                        id: 'templates',
                        title: 'Templates',
                        type: 'basic',
                        icon: 'heroicons_outline:document-chart-bar', 
                        link: '/templates',
                    },
                    {
                        id: 'conversations',
                        title: 'Conversations',
                        type: 'basic',
                        icon: 'heroicons_outline:chat-bubble-left-right',
                        link: '/conversations',
                    },
                    {
                        id: 'Medialibray',
                        title: 'Media Library',
                        type: 'basic',
                        icon: 'heroicons_outline:document-duplicate', 
                        link: '/medialibrary',
                    }
                ],
            },

            //     {
            //     id: 'automations',
            //     title: 'Automations',
            //     type: 'collapsable',
            //     icon: 'heroicons_outline:academic-cap', 
            //     children: [
            //         {
            //             id: 'Flows',
            //             title: 'Flows',
            //             type: 'basic',
            //             icon: 'heroicons_outline:building-library',
            //             link: '/flows',
            //         },
            //         {
            //             id: 'webhooks',
            //             title: 'Webhooks',
            //             type: 'basic',
            //             icon: 'heroicons_outline:globe-alt', 
            //             // link: '/addboard',
            //         },
            //         {
            //             id: 'chatbots',
            //             title: 'Chatbots',
            //             type: 'basic',
            //             icon: 'heroicons_outline:chat-bubble-bottom-center-text',
            //             link: '/chatbots',
            //         },
            //         {
            //             id: 'broadcasts',
            //             title: 'Broadcasts',
            //             type: 'basic',
            //             icon: 'heroicons_outline:book-open', 
            //             link: '/broadcasts',
            //         }
            //     ],
            // },

            
            //    {
            //     id: 'Business',
            //     title: 'Business',
            //     type: 'collapsable',
            //     icon: 'heroicons_outline:briefcase', 
            //     children: [
            //         {
            //             id: 'Businessprofile',
            //             title: 'Business Profile',
            //             type: 'basic',
            //             icon: 'heroicons_outline:user-circle',
            //             // link: '/addschool',
            //         },
            //         {
            //             id: 'productcatalog',
            //             title: 'Product Catalog',
            //             type: 'basic',
            //             icon: 'heroicons_outline:tag', 
            //             link: '/catalog',
            //         },
            //         {
            //             id: 'phoneNumbers',
            //             title: 'Phone Numbers',
            //             type: 'basic',
            //             icon: 'heroicons_outline:calculator',
            //             link: '/phonenumbers',
            //         }
            //     ],
            // },

        // {
        //     id: 'chat',
        //     title: 'Inbox',
        //     type: 'basic',
        //     icon: 'heroicons_outline:chat-bubble-bottom-center-text',
        //     link: '/apps/chat',
        // },
        // {
        //     id: 'user',
        //     title: 'Users',
        //     type: 'basic',
        //     icon: 'heroicons_outline:users',
        //      link: '/apps/contacts',
        // },
        //  {
        //     id: 'voicecalling',
        //     title: 'Voice & Calling',
        //     type: 'collapsable',
        //     icon: 'heroicons_outline:speaker-wave',
        //     // link: '/addboard',
        //     children: [
        //             {
        //                 id: 'callbutton',
        //                 title: 'Call Button',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:building-library',
        //                 link: '/callbuttons',
        //             },
        //             {
        //                 id: 'callingapi',
        //                 title: 'Calling API',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:clipboard-document-check', 
        //                 link: '/callapi',
        //             }
        //         ],
        // },

        // {
        //     id: 'analytics',
        //     title: 'Analytics',
        //     type: 'basic',
        //     icon: 'heroicons_outline:chart-bar-square',
        //     link: '/analytics',
        // },

       
        // {
        //     id: 'developertools',
        //     title: 'Developer Tools',
        //    type: 'collapsable',
        //     icon: 'heroicons_outline:wrench-screwdriver',
        //     // link: '/addboard',
        //     children: [
        //             {
        //                 id: 'apimanagment',
        //                 title: 'API Management',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:building-library',
        //                 link: '/apimanagement',
        //             },
        //             {
        //                 id: 'webhookdebugger',
        //                 title: 'Webhook Debugger',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:clipboard-document-check', 
        //                 link: '/webhookdebugger',
        //             },
        //             {
        //                 id: 'sandbox',
        //                 title: 'Sandbox',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:rectangle-stack',
        //                 link: '/sandbox',
        //             },
        //              {
        //                 id: 'documentation',
        //                 title: 'Documentation',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:rectangle-stack',
        //                 link: '/documentation',
        //             }
        //         ],
        // },
        // {
        //     id: 'integrations',
        //     title: 'Integrations',
        //    type: 'collapsable',
        //     icon: 'heroicons_outline:rocket-launch',
        //     // link: '/addboard',
        //     children: [
        //             {
        //                 id: 'crm',
        //                 title: 'CRM / ERP',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:building-library',
        //                 // link: '/addschool',
        //             },
        //             {
        //                 id: 'paymentlink',
        //                 title: 'Payment Links',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:clipboard-document-check', 
        //                 // link: '/addboard',
        //             },
        //             {
        //                 id: 'metaBusiness',
        //                 title: 'Meta Bussiness',
        //                 type: 'basic',
        //                 icon: 'heroicons_outline:rectangle-stack',
        //                 // link: '/addclass',
        //             }
        //         ],
        // },
        // {
        //     id: 'setting',
        //     title: 'Settings',
        //     type: 'basic',
        //     icon: 'heroicons_outline:cog-8-tooth',
        //     link: '/settings',
        // },

     

           



    );
}else if(role === 'super_admin'){
  navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'organization',
                title: 'Organization',
                type: 'basic',
                icon: 'heroicons_outline:building-office-2', 
                link: '/apps/contacts',
            },
            {
                id: 'subscriptions',
                title: 'Subscriptions',
                type: 'basic',
                icon: 'heroicons_outline:currency-dollar', 
                // link: '/showExam',
            },
            {
            id: 'contacts',
            title: 'Contacts',
            type: 'basic',
            icon: 'heroicons_outline:user-group',
            link: '/contacts',
        },
        );
}

    return navigation;
};