import { Injectable } from '@angular/core';
import { ApiService } from '../Services/api.service';

@Injectable({
    providedIn: 'root',
})
export class ApicontrollerService {
    constructor(private apiService: ApiService) { }

    async loginuser(logindata: any, url: string = 'common/user') {
        const data = {
            fn: 'common_fn',
            se: 'lo_us',
            data: logindata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    // --------------------------------

    async createOrgnization(Orgnizationdata: any, url: string = 'common/user') {
        const data = {
            fn: 'common_fn',
            se: 'or_reg',
            data: Orgnizationdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    
    async fetchApiCredentials(organization_id:string,url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_crd',
            data: {row_id:organization_id},
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchApiRoleAndPermission(url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_role_per',
            data: " ",
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async createContact(contactdata: any, url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'cr_cont',
            data: contactdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }


     async fetchUsersContacts(organization_id:string,url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_user',
            data: {row_id:organization_id},
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

      async bulkUserImport(contactdata: any, url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'bulk_usr',
            data: contactdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async SendMessage(msgdata: any, url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'se_msg',
            data: msgdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchUsersMessage(phone:string,url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_msg',
            data: {row_id:phone},
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

   async fetchTemplates(url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_temp',
            data: "",
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async CreateTemplates(templatedata: any, url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'cr_tem',
            data: templatedata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async updateTemplates(templatedata: any, url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'up_tem',
            data: templatedata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchapprovedTemplates(url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_app_temp',
            data: "",
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }


    async fetchMediafile(url: string = 'common/') {
        const data = {
            fn: 'common_fn',
            se: 'fe_media_fil',
            data: "",
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

}
