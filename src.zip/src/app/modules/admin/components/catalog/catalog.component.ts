import { Component, TemplateRef, ViewChild, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { LucideAngularModule, Plus, Search, Package, Upload, Edit, Trash2, Eye, DollarSign, Tag, Star, ShoppingCart, Download } from 'lucide-angular';

type ProductStatus = 'active' | 'out_of_stock' | 'draft';

interface ProductItem {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: 'USD' | 'EUR' | 'GBP' | string;
  category: string;
  brand: string;
  sku: string;
  stock: number;
  status: ProductStatus;
  images: string[];
  rating: number;
  reviews: number;
  tags: string[];
  createdAt: string; // ISO
  lastUpdated: string; // ISO
}
@Component({
  selector: 'app-catalog',
  imports: [CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgOptimizedImage,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatDialogModule,
    MatSlideToggleModule,
    LucideAngularModule],
  templateUrl: './catalog.component.html',
  styleUrl: './catalog.component.scss'
})
export class CatalogComponent {
  @ViewChild('addDialogTpl') addDialogTpl!: TemplateRef<unknown>;

  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconPackage = Package;
  readonly IconUpload = Upload;
  readonly IconEdit = Edit;
  readonly IconTrash = Trash2;
  readonly IconEye = Eye;
  readonly IconDollar = DollarSign;
  readonly IconTag = Tag;
  readonly IconStar = Star;
  readonly IconCart = ShoppingCart;
  readonly IconDownload = Download;

  placeholderImg = '/api/placeholder/300/300';

  // Filters
  searchTerm = '';
  selectedCategory = 'All';
  selectedBrand = 'All';
  selectedStatus: 'all' | ProductStatus = 'all';

  categories = ['All', 'Smartphones', 'Laptops', 'Audio', 'Accessories', 'Gaming'];
  brands = ['All', 'Apple', 'Samsung', 'Sony', 'TechGear', 'Others'];

  // Add dialog form
  addForm: FormGroup;
  private selectedImages = signal<string[]>([]);

  // In-memory data (mirrors React demo)
  products: ProductItem[] = [
    {
      id: '1',
      name: 'iPhone 15 Pro',
      description: 'Latest iPhone with advanced camera system and titanium design',
      price: 999.0,
      currency: 'USD',
      category: 'Smartphones',
      brand: 'Apple',
      sku: 'IPH15PRO128',
      stock: 45,
      status: 'active',
      images: ['/api/placeholder/300/300'],
      rating: 4.8,
      reviews: 1250,
      tags: ['premium', 'new', 'bestseller'],
      createdAt: '2024-01-10',
      lastUpdated: '2024-01-15'
    },
    {
      id: '2',
      name: 'Samsung Galaxy S24',
      description: 'Flagship Android phone with AI features and excellent camera',
      price: 899.0,
      currency: 'USD',
      category: 'Smartphones',
      brand: 'Samsung',
      sku: 'SGS24256',
      stock: 32,
      status: 'active',
      images: ['/api/placeholder/300/300'],
      rating: 4.6,
      reviews: 850,
      tags: ['android', 'premium'],
      createdAt: '2024-01-08',
      lastUpdated: '2024-01-14'
    },
    {
      id: '3',
      name: 'MacBook Air M3',
      description: 'Ultra-thin laptop with M3 chip for exceptional performance',
      price: 1299.0,
      currency: 'USD',
      category: 'Laptops',
      brand: 'Apple',
      sku: 'MBA13M3512',
      stock: 18,
      status: 'active',
      images: ['/api/placeholder/300/300'],
      rating: 4.9,
      reviews: 650,
      tags: ['laptop', 'premium', 'bestseller'],
      createdAt: '2024-01-05',
      lastUpdated: '2024-01-12'
    },
    {
      id: '4',
      name: 'AirPods Pro 2',
      description: 'Premium wireless earbuds with active noise cancellation',
      price: 249.0,
      currency: 'USD',
      category: 'Audio',
      brand: 'Apple',
      sku: 'APP2GEN2',
      stock: 0,
      status: 'out_of_stock',
      images: ['/api/placeholder/300/300'],
      rating: 4.7,
      reviews: 2100,
      tags: ['audio', 'wireless'],
      createdAt: '2024-01-03',
      lastUpdated: '2024-01-11'
    },
    {
      id: '5',
      name: 'Gaming Keyboard RGB',
      description: 'Mechanical gaming keyboard with customizable RGB lighting',
      price: 149.0,
      currency: 'USD',
      category: 'Accessories',
      brand: 'TechGear',
      sku: 'KBRGB01',
      stock: 75,
      status: 'draft',
      images: ['/api/placeholder/300/300'],
      rating: 4.4,
      reviews: 320,
      tags: ['gaming', 'mechanical'],
      createdAt: '2024-01-01',
      lastUpdated: '2024-01-10'
    }
  ];

  constructor(private fb: FormBuilder, private dialog: MatDialog) {
    this.addForm = this.fb.group({
      name: ['', Validators.required],
      sku: ['', Validators.required],
      description: [''],
      price: [0, [Validators.required, Validators.min(0)]],
      currency: ['USD', Validators.required],
      stock: [0, [Validators.required, Validators.min(0)]],
      category: [this.categories[1], Validators.required],
      brand: ['', Validators.required],
      tagsCsv: [''],
      publish: [true]
    });
  }

  // Stats
  get activeProducts(): number {
    return this.products.filter(p => p.status === 'active').length;
  }
  get totalValue(): number {
    return this.products.reduce((sum, p) => sum + p.price * p.stock, 0);
  }
  get outOfStock(): number {
    return this.products.filter(p => p.status === 'out_of_stock').length;
  }

  // Filtering
  get filteredProducts(): ProductItem[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.products.filter(p => {
      const matchesSearch = !term ||
        p.name.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term) ||
        p.sku.toLowerCase().includes(term);
      const matchesCategory = this.selectedCategory === 'All' || p.category === this.selectedCategory;
      const matchesBrand = this.selectedBrand === 'All' || p.brand === this.selectedBrand;
      const matchesStatus = this.selectedStatus === 'all' || p.status === this.selectedStatus;
      return matchesSearch && matchesCategory && matchesBrand && matchesStatus;
    });
  }

  statusClass(status: ProductStatus): string {
    if (status === 'active') return 'status status-active';
    if (status === 'out_of_stock') return 'status status-out';
    return 'status status-draft';
  }

  statusIcon(status: ProductStatus) {
    return status === 'active' ? Eye : status === 'out_of_stock' ? Package : Edit;
  }

  // Actions
  openAddDialog(tpl: TemplateRef<unknown>) {
    this.dialog.open(tpl, { width: '680px' });
  }

  addProduct() {
    if (this.addForm.invalid) return;
    const v = this.addForm.value;
    const tags = (v.tagsCsv as string)?.split(',').map(t => t.trim()).filter(Boolean) ?? [];
    const now = new Date().toISOString().slice(0, 10);
    const newItem: ProductItem = {
      id: (Math.max(0, ...this.products.map(p => +p.id)) + 1).toString(),
      name: v.name!,
      description: v.description || '',
      price: Number(v.price),
      currency: (v.currency as any) ?? 'USD',
      category: v.category!,
      brand: v.brand!,
      sku: v.sku!,
      stock: Number(v.stock),
      status: (v.publish ? 'active' : 'draft'),
      images: this.selectedImages(),
      rating: 0,
      reviews: 0,
      tags,
      createdAt: now,
      lastUpdated: now
    };
    this.products = [newItem, ...this.products];
    this.addForm.reset({ currency: 'USD', stock: 0, category: this.categories[1], publish: true });
    this.selectedImages.set([]);
    this.dialog.closeAll();
  }

  onImageSelect(e: Event) {
    const files = (e.target as HTMLInputElement).files;
    if (!files || !files.length) return;
    // For demo, we won't upload; just store object URLs
    const urls: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const f = files.item(i)!;
      urls.push(URL.createObjectURL(f));
    }
    this.selectedImages.set(urls);
  }

  deleteProduct(p: ProductItem) {
    this.products = this.products.filter(x => x.id !== p.id);
  }
  viewProduct(_p: ProductItem) { /* TODO: preview dialog */ }
  editProduct(_p: ProductItem) { /* TODO: edit dialog */ }

  onImportCsv() {
    console.log('Import CSV clicked');
  }
  onExport() {
    console.log('Export catalog clicked');
  }
}