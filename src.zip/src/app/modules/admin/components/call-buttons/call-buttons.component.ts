import { Component, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { LucideAngularModule, Plus, Search, Phone, Video, Edit, Trash2, Eye, BarChart3, Copy, Settings, PhoneCall, Users, Clock } from 'lucide-angular';

type CallType = 'voice' | 'video';
type CallStatus = 'active' | 'paused';

interface CallButtonItem {
  id: string;
  name: string;
  description: string;
  buttonText: string;
  phoneNumber: string;
  type: CallType;
  status: CallStatus;
  clicks: number;
  conversions: number;
  averageCallDuration: string; // mm:ss
  createdAt: string; // ISO date
  lastUsed: string; // ISO datetime
  placement: Array<'chat' | 'menu' | 'catalog'>;
  businessHours: boolean;
  autoResponse: string;
}

@Component({
  selector: 'app-call-buttons',
  imports: [
     CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDialogModule,
    MatChipsModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    LucideAngularModule
  ],
  templateUrl: './call-buttons.component.html',
  styleUrl: './call-buttons.component.scss'
})
export class CallButtonsComponent {
  @ViewChild('createTpl') createTpl!: TemplateRef<unknown>;

  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconPhone = Phone;
  readonly IconVideo = Video;
  readonly IconEdit = Edit;
  readonly IconTrash = Trash2;
  readonly IconEye = Eye;
  readonly IconChart = BarChart3;
  readonly IconCopy = Copy;
  readonly IconSettings = Settings;
  readonly IconPhoneCall = PhoneCall;
  readonly IconUsers = Users;
  readonly IconClock = Clock;

  // Filters
  searchTerm = '';
  selectedType: 'all' | CallType = 'all';
  selectedStatus: 'all' | CallStatus = 'all';

  // Create form
  createForm: FormGroup;

  // In-memory items mirroring the React demo
  items: CallButtonItem[] = [
    {
      id: '1',
      name: 'Customer Support Call',
      description: 'Direct line to customer support team',
      buttonText: 'Call Support',
      phoneNumber: '+1-555-0123',
      type: 'voice',
      status: 'active',
      clicks: 1250,
      conversions: 890,
      averageCallDuration: '4:30',
      createdAt: '2024-01-10',
      lastUsed: '2024-01-15T10:30:00Z',
      placement: ['chat', 'menu'],
      businessHours: true,
      autoResponse: "Thanks for calling! We'll connect you shortly."
    },
    {
      id: '2',
      name: 'Sales Video Call',
      description: 'Video consultation with sales team',
      buttonText: 'Video Consultation',
      phoneNumber: '+1-555-0456',
      type: 'video',
      status: 'active',
      clicks: 650,
      conversions: 520,
      averageCallDuration: '12:45',
      createdAt: '2024-01-08',
      lastUsed: '2024-01-15T08:45:00Z',
      placement: ['chat', 'catalog'],
      businessHours: true,
      autoResponse: 'Starting video call for product consultation...'
    },
    {
      id: '3',
      name: 'Emergency Support',
      description: '24/7 emergency technical support line',
      buttonText: 'Emergency Call',
      phoneNumber: '+1-555-0789',
      type: 'voice',
      status: 'active',
      clicks: 320,
      conversions: 310,
      averageCallDuration: '8:15',
      createdAt: '2024-01-05',
      lastUsed: '2024-01-14T22:15:00Z',
      placement: ['chat'],
      businessHours: false,
      autoResponse: 'Emergency support - connecting immediately...'
    },
    {
      id: '4',
      name: 'Product Demo Call',
      description: 'Schedule a product demonstration call',
      buttonText: 'Schedule Demo',
      phoneNumber: '+1-555-0321',
      type: 'video',
      status: 'paused',
      clicks: 180,
      conversions: 145,
      averageCallDuration: '25:30',
      createdAt: '2024-01-03',
      lastUsed: '2024-01-10T16:20:00Z',
      placement: ['menu'],
      businessHours: true,
      autoResponse: "Let's schedule your personalized product demo!"
    }
  ];

  constructor(private fb: FormBuilder, private dialog: MatDialog) {
    this.createForm = this.fb.group({
      name: ['', Validators.required],
      buttonText: ['', Validators.required],
      description: [''],
      phoneNumber: ['', Validators.required],
      type: ['voice', Validators.required],
      placeChat: [true],
      placeMenu: [true],
      placeCatalog: [false],
      autoResponse: [''],
      businessHours: [true],
      activate: [true]
    });
  }

  // Derived metrics
  get activeCount(): number { return this.items.filter(i => i.status === 'active').length; }
  get totalClicks(): number { return this.items.reduce((s, i) => s + i.clicks, 0); }
  get avgConversionRate(): number {
    if (!this.items.length) return 0;
    const total = this.items.reduce((s, i) => s + (i.conversions / Math.max(1, i.clicks)) * 100, 0);
    return Math.round(total / this.items.length);
  }

  // Filtering
  get filteredItems(): CallButtonItem[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.items.filter(b => {
      const matchesSearch = !term || b.name.toLowerCase().includes(term) || b.description.toLowerCase().includes(term);
      const matchesType = this.selectedType === 'all' || b.type === this.selectedType;
      const matchesStatus = this.selectedStatus === 'all' || b.status === this.selectedStatus;
      return matchesSearch && matchesType && matchesStatus;
    });
  }

  // UI helpers
  typeIcon(t: CallType) { return t === 'video' ? Video : Phone; }
  statusIcon(s: CallStatus) { return s === 'active' ? PhoneCall : Clock; }
  statusBadgeClass(s: CallStatus): string { return s === 'active' ? 'badge green' : 'badge yellow'; }
  conversionRate(b: CallButtonItem): number { return Math.round((b.conversions / Math.max(1, b.clicks)) * 100); }
  lastUsedDate(iso: string): string { return new Date(iso).toLocaleDateString(); }

  // Actions
  openCreateDialog(tpl: TemplateRef<unknown>) { this.dialog.open(tpl, { width: '720px' }); }
  createButton() {
    if (this.createForm.invalid) return;
    const v = this.createForm.value;
    const placement: Array<'chat' | 'menu' | 'catalog'> = [];
    if (v.placeChat) placement.push('chat');
    if (v.placeMenu) placement.push('menu');
    if (v.placeCatalog) placement.push('catalog');

    const now = new Date();
    const newItem: CallButtonItem = {
      id: (Math.max(0, ...this.items.map(i => +i.id)) + 1).toString(),
      name: v.name!,
      description: v.description || '',
      buttonText: v.buttonText!,
      phoneNumber: v.phoneNumber!,
      type: v.type as CallType,
      status: v.activate ? 'active' as CallStatus : 'paused',
      clicks: 0,
      conversions: 0,
      averageCallDuration: '0:00',
      createdAt: now.toISOString().slice(0, 10),
      lastUsed: now.toISOString(),
      placement,
      businessHours: !!v.businessHours,
      autoResponse: v.autoResponse || ''
    };
    this.items = [newItem, ...this.items];
    this.dialog.closeAll();
    this.createForm.reset({ type: 'voice', placeChat: true, placeMenu: true, placeCatalog: false, businessHours: true, activate: true });
  }

  deleteButton(b: CallButtonItem) { this.items = this.items.filter(x => x.id !== b.id); }
}