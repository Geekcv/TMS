import { Routes } from '@angular/router';
import { CallButtonsComponent } from './call-buttons.component';

export default [
    {
        path: '',
        component: CallButtonsComponent,
    },
] as Routes;
