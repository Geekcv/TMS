import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { LucideAngularModule, TestTube, Phone, MessageSquare, Users, Settings, Play } from 'lucide-angular';

interface TestNumber {
  number: string;
  region: string;
}
@Component({
  selector: 'app-sandbox',
  imports: [CommonModule, MatCardModule, MatButtonModule, LucideAngularModule],
  templateUrl: './sandbox.component.html',
  styleUrl: './sandbox.component.scss'
})
export class SandboxComponent {
  readonly IconTestTube = TestTube;
  readonly IconPhone = Phone;
  readonly IconMessage = MessageSquare;
  readonly IconUsers = Users;
  readonly IconSettings = Settings;
  readonly IconPlay = Play;

  testNumbers: TestNumber[] = [
    { number: '+1-555-TEST-001', region: 'US' },
    { number: '+44-555-TEST-002', region: 'UK' },
    { number: '+49-555-TEST-003', region: 'DE' },
  ];

  getNewTestNumber() {
    const regions = ['US','UK','DE','IN','SG','BR'];
    const r = regions[Math.floor(Math.random()*regions.length)];
    const id = Math.floor(100 + Math.random()*900).toString();
    const num = `+${Math.floor(10+Math.random()*89)}-555-TEST-${id}`;
    this.testNumbers = [...this.testNumbers, { number: num, region: r }];
  }

  runFeature(name: 'message'|'contacts'|'webhook') {
    console.log('Run sandbox feature:', name);
  }
}