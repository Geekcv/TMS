import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WebhookDebuggerComponent } from './webhook-debugger.component';

describe('WebhookDebuggerComponent', () => {
  let component: WebhookDebuggerComponent;
  let fixture: ComponentFixture<WebhookDebuggerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WebhookDebuggerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WebhookDebuggerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
