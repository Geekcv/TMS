import { Component, Input, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { LucideAngularModule, Plus, Search, Users, Send, Play, BarChart3, Eye, Edit, Pause } from 'lucide-angular';
import { User } from '../../components/contacts/user.model';

type CampaignStatus = 'Active' | 'Completed' | 'Scheduled' | 'Draft' | 'Paused';

interface Campaign {
  id: number;
  name: string;
  status: CampaignStatus;
  audience: string;
  template: string;
  sent: number;
  delivered: number;
  opened: number;
  clicks: number;
  created: string; // ISO date
  scheduled: string; // ISO date-time or empty
  deliveryRate: number; // percent
  openRate: number; // percent
  clickRate: number; // percent
}

@Component({
  selector: 'app-campaign',
  imports: [
      CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatDialogModule,
    MatProgressBarModule,
    LucideAngularModule
  ],
  templateUrl: './campaign.component.html',
  styleUrl: './campaign.component.scss'
})
export class CampaignsComponent {
  @Input() user: User | null = null;
  @ViewChild('createDialog') createDialogTpl!: TemplateRef<unknown>;

  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconUsers = Users;
  readonly IconSend = Send;
  readonly IconPlay = Play;
  readonly IconBarChart = BarChart3;
  readonly IconEye = Eye;
  readonly IconEdit = Edit;
  readonly IconPause = Pause;

  searchTerm = '';
  displayedColumns = ['campaign', 'status', 'audience', 'sent', 'deliveryRate', 'openRate', 'clickRate', 'created', 'actions'];

  createForm!: FormGroup;

  templates = [
    { id: 1, name: 'Promotional Offer', category: 'Marketing' },
    { id: 2, name: 'Product Announcement', category: 'Product' },
    { id: 3, name: 'Newsletter Template', category: 'Newsletter' },
    { id: 4, name: 'Survey Request', category: 'Feedback' }
  ];

  audiences = [
    { id: 1, name: 'All Customers', count: 12459 },
    { id: 2, name: 'VIP Customers', count: 1250 },
    { id: 3, name: 'New Subscribers', count: 3456 },
    { id: 4, name: 'Recent Customers', count: 2890 }
  ];

  campaigns: Campaign[] = [
    { id: 1, name: 'Summer Sale 2024', status: 'Active', audience: 'All Customers', template: 'Promotional', sent: 1250, delivered: 1198, opened: 890, clicks: 234, created: '2024-06-15', scheduled: '2024-06-15T10:00:00', deliveryRate: 95.8, openRate: 71.2, clickRate: 18.7 },
    { id: 2, name: 'Product Launch Announcement', status: 'Completed', audience: 'VIP Customers', template: 'Announcement', sent: 3500, delivered: 3456, opened: 2890, clicks: 867, created: '2024-06-10', scheduled: '2024-06-10T14:00:00', deliveryRate: 98.7, openRate: 82.6, clickRate: 24.8 },
    { id: 3, name: 'Newsletter June', status: 'Scheduled', audience: 'All Subscribers', template: 'Newsletter', sent: 0, delivered: 0, opened: 0, clicks: 0, created: '2024-06-18', scheduled: '2024-06-20T09:00:00', deliveryRate: 0, openRate: 0, clickRate: 0 },
    { id: 4, name: 'Feedback Request', status: 'Draft', audience: 'Recent Customers', template: 'Survey', sent: 0, delivered: 0, opened: 0, clicks: 0, created: '2024-06-18', scheduled: '', deliveryRate: 0, openRate: 0, clickRate: 0 }
  ];

  constructor(private fb: FormBuilder, private dialog: MatDialog) {
    this.createForm = this.fb.group({
      name: ['', Validators.required],
      templateId: ['', Validators.required],
      audience: ['', Validators.required],
      scheduledDate: ['']
    });
  }

  // Derived values
  get filteredCampaigns(): Campaign[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.campaigns.filter(c => !term || c.name.toLowerCase().includes(term));
  }
  get totalCampaigns(): number { return this.campaigns.length; }
  get activeCampaigns(): number { return this.campaigns.filter(c => c.status === 'Active').length; }
  get totalMessages(): number { return this.campaigns.reduce((sum, c) => sum + c.sent, 0); }
  get avgOpenRate(): string {
    const withOpens = this.campaigns.filter(c => c.openRate > 0);
    const avg = withOpens.length ? withOpens.reduce((sum, c) => sum + c.openRate, 0) / withOpens.length : 0;
    return avg.toFixed(1);
  }

  // Helpers
  statusClass(status: CampaignStatus): string {
    switch (status) {
      case 'Active': return 'badge badge-active';
      case 'Completed': return 'badge badge-completed';
      case 'Scheduled': return 'badge badge-scheduled';
      case 'Draft': return 'badge badge-draft';
      case 'Paused': return 'badge badge-paused';
      default: return 'badge';
    }
  }

  rateColor(value: number, allowGray = false): string {
    if (value <= 0) return allowGray ? 'rate-gray' : 'rate-red';
    if (value > 70) return 'rate-green';
    if (value > 50) return 'rate-yellow';
    return 'rate-red';
  }

  sentProgress(c: Campaign): number {
    if (!c.sent) return 0;
    const pct = (c.delivered / c.sent) * 100;
    return Math.max(0, Math.min(100, pct));
  }

  openCreateDialog(template: TemplateRef<unknown>) {
    this.dialog.open(template, { width: '640px' });
  }

  saveDraft() {
    if (!this.createForm.controls['name'].value) return;
    const nextId = Math.max(...this.campaigns.map(c => c.id)) + 1;
    const t = this.templates.find(t => t.id === this.createForm.value.templateId);
    const newCampaign: Campaign = {
      id: nextId,
      name: this.createForm.value.name,
      status: 'Draft',
      audience: this.createForm.value.audience,
      template: t ? t.name : 'Custom',
      sent: 0,
      delivered: 0,
      opened: 0,
      clicks: 0,
      created: new Date().toISOString().slice(0, 10),
      scheduled: this.createForm.value.scheduledDate ? new Date(this.createForm.value.scheduledDate).toISOString() : '',
      deliveryRate: 0,
      openRate: 0,
      clickRate: 0
    };
    this.campaigns = [newCampaign, ...this.campaigns];
    this.createForm.reset();
    this.dialog.closeAll();
  }

  createAndSend() {
    if (this.createForm.invalid) return;
    const nextId = Math.max(...this.campaigns.map(c => c.id)) + 1;
    const t = this.templates.find(t => t.id === this.createForm.value.templateId);
    const newCampaign: Campaign = {
      id: nextId,
      name: this.createForm.value.name,
      status: 'Active',
      audience: this.createForm.value.audience,
      template: t ? t.name : 'Custom',
      sent: 0,
      delivered: 0,
      opened: 0,
      clicks: 0,
      created: new Date().toISOString().slice(0, 10),
      scheduled: this.createForm.value.scheduledDate ? new Date(this.createForm.value.scheduledDate).toISOString() : '',
      deliveryRate: 0,
      openRate: 0,
      clickRate: 0
    };
    this.campaigns = [newCampaign, ...this.campaigns];
    this.createForm.reset();
    this.dialog.closeAll();
  }
}
