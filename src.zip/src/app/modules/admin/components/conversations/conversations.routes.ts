import { Routes } from '@angular/router';
import { ConversationsComponent } from 'app/modules/admin/components/conversations/conversations.component';

export default [
    {
        path: '',
        component: ConversationsComponent,
    },
] as Routes;
