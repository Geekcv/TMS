import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, computed, signal, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import {
  LucideAngularModule,
  Search,
  Send,
  Paperclip,
  MoreVertical,
  Phone,
  Video,
  MessageCircle,
  Clock,
  CheckCheck,
  Smile
} from 'lucide-angular';
import { config } from '../../../../../../config';

interface ConversationItem {
  row_id: string;
  first_name: string;
  phone_no: string;
}



interface ChatMessage {
  // id:string;
  row_id?: string;
  phone?: string;
  direction?: string;
  body?: string;
  cr_on?:any;
   mediaUrl?:any
   mimeType?:any
}



@Component({
  selector: 'app-conversations',
  standalone: true,
  imports: [CommonModule, FormsModule, LucideAngularModule],
  templateUrl: './conversations.component.html',
  styleUrls: ['./conversations.component.css']
})
export class ConversationsComponent {

      @ViewChild('choosetemplate') addContactDialogTpl!: TemplateRef<unknown>;
    config:any ;  
  organization_id: any;
  userdata: any;
approvedTemplates: any[] = [];
selectedTemplate: any = null;


  // Signals
  readonly conversations = signal<ConversationItem[]>([]);
  // readonly messages = signal<ChatMessage[]>(MESSAGES);
    readonly messages = signal<ChatMessage[]>([]); // start empty

  readonly selectedConversation = signal<ConversationItem | null>(null);
  readonly searchTerm = signal('');
  readonly messageText = signal('');
  readonly isLoading = signal<boolean>(false);

  readonly filteredConversations = computed(() => {
    const term = this.searchTerm().toLowerCase();
    return this.conversations().filter(conv =>
      conv.first_name.toLowerCase().includes(term) || conv.phone_no.includes(term)
    );
  });

    readonly messageContact = computed(() => {
    const term = this.searchTerm().toLowerCase();

    // console.log("readonly--->",this.messages().filter(conv =>
    //   conv.body.toLowerCase()
    // ))

    return this.messages().filter(conv =>
      conv.body.toLowerCase()
    );
  });


  readonly icons = {
    search: Search,
    send: Send,
    paperclip: Paperclip,
    more: MoreVertical,
    phone: Phone,
    video: Video,
    conversation: MessageCircle,
    clock: Clock,
    check: CheckCheck,
    smile: Smile
  };
 
  //  CONVERSATION_MESSAGES: ChatMessage[] =[]



  constructor(private Apicontroller: ApicontrollerService,private dialog: MatDialog,private cdRef: ChangeDetectorRef, private http: HttpClient) {
    this.userdata = JSON.parse(localStorage.getItem('userDeatials') || '{}');
    this.organization_id = this.userdata.organization_id;
    this.config = config.apiBaseURL

          //  this.fetchmediafile()

    console.log("imagurl",this.imgUrl)


  }

imgUrl:any;

  ngOnInit(): void {
    this.fetchUserContacts();
    this.fetchapprovedTemplates()
    this.fetchmediafile()
  }

  async fetchapprovedTemplates(){
          const resp = await this.Apicontroller.fetchapprovedTemplates();
          // console.log("resp---->",resp)
           if (resp && resp.data) {
    this.approvedTemplates = resp.data;

    // console.log("approvedTemplates--------------",this.approvedTemplates)
  }

  

  }

  async fetchUserContacts() {
    try {
      this.isLoading.set(true);
      const resp = await this.Apicontroller.fetchUsersContacts(this.organization_id);

      if (resp && resp.data && Array.isArray(resp.data)) {
        const mappedData = resp.data.map((item: any) => ({
          row_id: item.row_id,
          first_name: item.first_name,
          phone_no: item.phone_no
        }));
        this.conversations.set(mappedData);

        // Automatically select first conversation if exists
        if (mappedData.length > 0) {
          this.selectedConversation.set(mappedData[0]);
        }
      }
    } catch (err) {
      console.error('Error fetching user contacts:', err);
    } finally {
      this.isLoading.set(false);
    }
  }

  tempdata:any

  async onSelectConversation(conversation: ConversationItem) {
  console.log("Selected conversation phone_no:", conversation.phone_no);
  this.selectedConversation.set(conversation);
  this.isLoading.set(true);

  try {
    const resp = await this.Apicontroller.fetchUsersMessage(conversation.phone_no);
    // console.log("Fetched messages:", resp);

      // console.log("msg---->",this.messages())


    if (resp  && Array.isArray(resp)) {
      const mappedData = resp.map((item: any) => ({
        id: item.id,
        row_id: item.row_id,
        phone: item.phone,
        direction: item.direction,
        body: item.body,
        mediaUrl:item.media_url,
        mimeType:item.media_type,
        cr_on:item.cr_on
      }));

      // console.log("mappedData-->",mappedData)
      //  Set the messages properly as an array
      this.messages.set(mappedData);
    } else {
      this.messages.set([]); // No messages found
    }
  } catch (err) {
    console.error("Error fetching messages:", err);
    this.messages.set([]);
  } finally {
    this.isLoading.set(false);
  }

  //  Save current selected conversation
  this.tempdata = conversation;
}


  onSearch(value: string) {
    this.searchTerm.set(value);
  }

  onMessageInput(value: string) {
    // console.log("onMessageInput",value)
    this.messageText.set(value);
  }

  // handleSendMessage() {
  //   const text = this.messageText().trim();
  //   if (!text) return;

  //   console.log('Sending message:', text);
  //   this.messageText.set('');
  // }

  onTextareaKeydown(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.handleSendMessage();
    }
  }

  getInitials(name: string) {
    return name
      .split(' ')
      .filter(Boolean)
      .map(part => part[0])
      .join('')
      .toUpperCase();
  }

  // readonly attachedFiles = signal<File[]>([]);
readonly showEmojiPicker = signal(false);

readonly attachedFiles = signal<File[]>([]);
filePreviewUrls: string[] = [];

// File selection
// onFileSelected(event: any) {
//   const files: FileList = event.target.files;
//   if (files.length > 0) {
//     const currentFiles = [...this.attachedFiles()];
//     for (let i = 0; i < files.length; i++) {
//       currentFiles.push(files[i]);
//     }
//     this.attachedFiles.set(currentFiles);
//   }
// }

onFileSelected(event: any) {
  const files: FileList = event.target.files;
  if (files.length > 0) {
    const currentFiles = [...this.attachedFiles()];
    for (let i = 0; i < files.length; i++) {
      currentFiles.push(files[i]);
      this.filePreviewUrls.push(URL.createObjectURL(files[i])); // generate preview URL
    }
    this.attachedFiles.set(currentFiles);
  }
}

// Remove file
removeFile(index: number) {
  const files = [...this.attachedFiles()];
  files.splice(index, 1);
  this.filePreviewUrls.splice(index, 1);
  this.attachedFiles.set(files);
}


mediaPreview: any;
      filepath:any;
mediatype:any;


 

toggleEmojiPicker() {
  this.showEmojiPicker.set(!this.showEmojiPicker());
}

// Send message with text or files
// async handleSendMessage() {
//   const text = this.messageText().trim();
//   const files = this.attachedFiles();

//   if (!text && files.length === 0) return;

//   const phone_no = this.tempdata?.phone_no;
//   if (!phone_no) {
//     console.warn("No conversation selected!");
//     return;
//   }

//   // console.log("handleSendMessage ---->", text, "phone no --->", phone_no);

//   // Create a temporary message to show in the chat UI immediately
//   const newMessage: ChatMessage = {
//     row_id: `temp_${Date.now()}`,
//     phone: phone_no,
//     direction: 'out', // sent by user (agent)
//     body: text,
//     cr_on:new Date()

//   };

//   // Update messages instantly in UI
//   this.messages.update(curr => [...curr, newMessage]);

//   // Prepare message object for API
//   const sendMgs = {
//     phone_no,
//     msg: text
//   };
//   this.messageText.set('');
//   this.attachedFiles.set([]);

//   try {
//     const resp = await this.Apicontroller.SendMessage(sendMgs);
//     // console.log("resp when send msg", resp);

//     // (Optional) If your API returns saved message with row_id or id, you can update it here
//     // Example:
//     // if (resp.data) {
//     //   this.messages.update(curr => curr.map(m => 
//     //     m.row_id === newMessage.row_id ? { ...m, row_id: resp.data.row_id } : m
//     //   ));
//     // }
//      // Reset input and files
//   // this.messageText.set('');
//   // this.attachedFiles.set([]);
//   } catch (err) {
//     console.error("Error sending message:", err);
//   }

 
  
// }


async handleSendMessage() {
  const text = this.messageText().trim();
  const files = this.attachedFiles();

  if (!text && files.length === 0) return;

  const phone_no = this.tempdata?.phone_no;
  const formData = new FormData();

  formData.append('phone_no', phone_no);
  formData.append('msg', text);
  formData.append('organization_id',this.organization_id)

  files.forEach(file => formData.append('media', file));

  try {
    this.http.post(`${this.config}/common/send-message`, formData).subscribe({
                next: (response: any) => {
                    if (response) {
                      console.log("rs",response)
                    }
                },
                error: (err) => console.error('Upload failed', err),
            });

    // Add sent message to UI instantly
    if (text) {
      this.messages.update(curr => [
        ...curr,
        { body: text, direction: 'out', cr_on: new Date() }
      ]);
    }

    files.forEach((file) => {
      this.messages.update(curr => [
        ...curr,
        { body: file.name, direction: 'out', cr_on: new Date(), mediaUrl: URL.createObjectURL(file), mimeType: file.type }
      ]);
    });

    // Reset after send
    this.messageText.set('');
    this.attachedFiles.set([]);
    this.filePreviewUrls = [];

  } catch (err) {
    console.error('Send message error:', err);
  }
}


getTime(messagtime:any){
  // console.log("messagtime---",messagtime)
  const now = new Date(messagtime);
const hours = now.getHours();
const minutes = now.getMinutes();
const seconds = now.getSeconds();
const milliseconds = now.getMilliseconds();

// console.log(`Current time: ${hours}:${minutes}:${seconds}.${milliseconds}`);

return { hours, minutes, seconds };

}


groupMessagesByDate(messages: any[]) {
  console.log("msg",messages)
  const grouped: any[] = [];
  let lastDateLabel = '';

  for (const msg of messages) {
    const msgDate = new Date(msg.cr_on);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    let label = '';

    if (
      msgDate.toDateString() === today.toDateString()
    ) {
      label = 'Today';
    } else if (
      msgDate.toDateString() === yesterday.toDateString()
    ) {
      label = 'Yesterday';
    } else {
      label = msgDate.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
    }

    // Add a date separator if label changes
    if (label !== lastDateLabel) {
      grouped.push({ type: 'date', label });
      lastDateLabel = label;
    }

    // Push actual message
    grouped.push({ type: 'message', ...msg });
  }

  return grouped;
}


// templatePicker(){
//   console.log("choose templates")
// }

placeholders: string[] = [];
placeholderValues: { [key: string]: string } = {};
previewBody: string = '';


selectTemplate(template: any) {
  this.selectedTemplate = template;

  const body: string = String(template.body || '');

  // Match placeholders like {{1}}, {{2}}, etc.
  const matches = body.match(/\{\{\d+\}\}/g) as string[] || [];

  // Remove duplicates and sort numerically
  this.placeholders = [...new Set(matches)].sort((a: string, b: string) => {
    const numA = parseInt(a.replace(/\D/g, ''), 10);
    const numB = parseInt(b.replace(/\D/g, ''), 10);
    return numA - numB;
  });

  
  // Initialize placeholderValues object
  this.placeholderValues = {};
  this.placeholders.forEach(ph => (this.placeholderValues[ph] = ''));
}


updatePreviewBody() {
  if (!this.selectedTemplate) return;

  let body = String(this.selectedTemplate.body || '');

  // Replace placeholders with current input values
  for (const [ph, val] of Object.entries(this.placeholderValues)) {
    const regex = new RegExp(ph.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'); // escape regex
    body = body.replace(regex, val || ph);
  }

  this.previewBody = body;
}



// useTemplate() {
//   if (!this.selectedTemplate) return;

//   const { header, body, footer } = this.selectedTemplate;

//   // Replace {{1}}, {{2}}, ... with entered values
//   let processedBody = body;
//   for (const [ph, val] of Object.entries(this.placeholderValues)) {
//     const regex = new RegExp(ph, 'g');
//     processedBody = processedBody.replace(regex, val || ph);
//   }

//   const formattedMessage = `
// ${header ? header + '\n\n' : ''}
// ${processedBody || ''}
// ${footer ? '\n\n' + footer : ''}
//   `.trim();

//   this.messageText.set(formattedMessage);
//   this.dialog.closeAll();
// }

useTemplate() {
  if (!this.selectedTemplate) return;

  const header = this.selectedTemplate.header || '';
  const footer = this.selectedTemplate.footer || '';

  const formattedMessage = `
${header ? header + '\n' : ''}
${this.previewBody || this.selectedTemplate.body || ''}
${footer ? '\n' + footer : ''}
  `.trim();

  this.messageText.set(formattedMessage);
  this.dialog.closeAll();
}



templatePicker(template: TemplateRef<unknown>) {
  this.dialog.open(template, { width: '1000px',height:'700px' });
}


async fetchmediafile(){

//   let resp = await this.Apicontroller.fetchMediafile()
//   console.log("resp",resp.url)
// // this.imgUrl = resp.url

//  this.imgUrl = this.http.get(`${this.configup}/common/media-stream/2062199480853250`).subscribe()


 const mediaId = '1495209658364156'; // or get from message
  const resp = await  this.http.get(`${config.apiBaseURL}/common/fetch-media/${mediaId}`).toPromise();
  console.log('resp-----', resp);
  // this.imgUrl = `${this.config}${resp.localUrl}`;  // full path to serve image



}


}
