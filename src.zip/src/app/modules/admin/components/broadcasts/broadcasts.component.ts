import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, computed, signal } from '@angular/core';
import {
  LucideAngularModule,
  Plus,
  Search,
  Send,
  Users,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Copy,
  Trash2,
  BarChart3,
  Calendar,
  Filter
} from 'lucide-angular';

interface Broadcast {
  id: string;
  name: string;
  message: string;
  template: string;
  status: 'sent' | 'scheduled' | 'draft' | 'failed';
  scheduledAt: string | null;
  sentAt: string | null;
  audienceSize: number;
  delivered: number;
  read: number;
  clicked: number;
  failed: number;
  tags: string[];
}

const BROADCASTS: Broadcast[] = [
  {
    id: '1',
    name: 'New Product Launch',
    message: 'Exciting news! Our new smartphone is now available. Get 20% off for early birds!',
    template: 'product_launch_template',
    status: 'sent',
    scheduledAt: '2024-01-15T10:00:00Z',
    sentAt: '2024-01-15T10:00:00Z',
    audienceSize: 15420,
    delivered: 14890,
    read: 12340,
    clicked: 2890,
    failed: 530,
    tags: ['product', 'promotion']
  },
  {
    id: '2',
    name: 'Weekly Newsletter',
    message: 'Your weekly update with the latest tech news and product updates.',
    template: 'newsletter_template',
    status: 'scheduled',
    scheduledAt: '2024-01-20T09:00:00Z',
    sentAt: null,
    audienceSize: 18700,
    delivered: 0,
    read: 0,
    clicked: 0,
    failed: 0,
    tags: ['newsletter', 'weekly']
  },
  {
    id: '3',
    name: 'Flash Sale Alert',
    message: '⚡ Flash Sale! 50% off selected items. Limited time offer - ends midnight!',
    template: 'flash_sale_template',
    status: 'draft',
    scheduledAt: null,
    sentAt: null,
    audienceSize: 8950,
    delivered: 0,
    read: 0,
    clicked: 0,
    failed: 0,
    tags: ['sale', 'urgent']
  },
  {
    id: '4',
    name: 'Customer Survey',
    message: 'Help us improve! Take our 2-minute survey and get a discount on your next purchase.',
    template: 'survey_template',
    status: 'failed',
    scheduledAt: '2024-01-14T14:00:00Z',
    sentAt: '2024-01-14T14:00:00Z',
    audienceSize: 5200,
    delivered: 3100,
    read: 2450,
    clicked: 890,
    failed: 2100,
    tags: ['survey', 'feedback']
  }
];

@Component({
  selector: 'app-broadcasts',
  standalone: true,
  imports: [CommonModule, FormsModule, DecimalPipe, LucideAngularModule],
  templateUrl: './broadcasts.component.html',
  styleUrls: ['./broadcasts.component.css']
})
export class BroadcastsComponent {
  readonly broadcasts = signal<Broadcast[]>(BROADCASTS);
  readonly searchTerm = signal('');
  readonly selectedStatus = signal<'all' | Broadcast['status']>('all');
  readonly isCreateDialogOpen = signal(false);
  readonly selectedAudience = signal('all');
  readonly scheduleOption = signal<'now' | 'schedule' | 'draft'>('now');

  // Create form model (ngModel-backed)
  newName = '';
  newTemplate = '';
  newMessage = '';
  newTagsCsv = '';
  newScheduledAt = '';

  readonly audienceSegments = [
    { value: 'all', label: 'All Contacts (18,750)' },
    { value: 'active', label: 'Active Customers (12,500)' },
    { value: 'new', label: 'New Subscribers (3,200)' },
    { value: 'vip', label: 'VIP Customers (850)' },
    { value: 'custom', label: 'Custom Segment' }
  ];

  readonly scheduleOptions = [
    { value: 'now', label: 'Send Immediately' },
    { value: 'schedule', label: 'Schedule for Later' },
    { value: 'draft', label: 'Save as Draft' }
  ];

  readonly filteredBroadcasts = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const status = this.selectedStatus();
    return this.broadcasts().filter(broadcast => {
      const matchesSearch =
        broadcast.name.toLowerCase().includes(term) ||
        broadcast.message.toLowerCase().includes(term);
      const matchesStatus = status === 'all' || broadcast.status === status;
      return matchesSearch && matchesStatus;
    });
  });

  readonly stats = computed(() => {
    const data = this.broadcasts();
    const sent = data.filter(item => item.status === 'sent');
    return {
      total: data.length,
      sent: sent.length,
      audience: data.reduce((sum, item) => sum + item.audienceSize, 0),
      deliveryRate: sent.length
        ? Math.round(sent.reduce((sum, item) => sum + (item.delivered / item.audienceSize) * 100, 0) / sent.length)
        : 0
    };
  });

  onSearch(value: string) {
    this.searchTerm.set(value);
  }

  onStatusChange(value: string) {
    this.selectedStatus.set(value as 'all' | Broadcast['status']);
  }

  toggleCreateDialog(open: boolean) {
    this.isCreateDialogOpen.set(open);
  }

  onSelectAudience(value: string) {
    this.selectedAudience.set(value);
  }

  onSelectSchedule(value: string) {
    this.scheduleOption.set(value as 'now' | 'schedule' | 'draft');
  }

  createBroadcast() {
    const name = this.newName.trim();
    if (!name) {
      this.toggleCreateDialog(false);
      return;
    }
    const statusMap = this.scheduleOption();
    const nowIso = new Date().toISOString();
    const scheduledIso = this.newScheduledAt
      ? new Date(this.newScheduledAt).toISOString()
      : new Date(Date.now() + 60 * 60 * 1000).toISOString();
    const audienceCount = this.parseAudienceCount(this.selectedAudience());
    const nextId = (Math.max(0, ...this.broadcasts().map(b => Number(b.id))) + 1).toString();
    const tags = this.newTagsCsv.split(',').map(s => s.trim()).filter(Boolean);

    const payload: Broadcast = {
      id: nextId,
      name,
      message: this.newMessage.trim(),
      template: this.newTemplate || 'custom_template',
      status: statusMap === 'now' ? 'sent' : statusMap === 'schedule' ? 'scheduled' : 'draft',
      scheduledAt: statusMap === 'schedule' ? scheduledIso : null,
      sentAt: statusMap === 'now' ? nowIso : null,
      audienceSize: audienceCount,
      delivered: 0,
      read: 0,
      clicked: 0,
      failed: 0,
      tags
    };
    this.broadcasts.set([payload, ...this.broadcasts()]);
    // reset form
    this.newName = '';
    this.newTemplate = '';
    this.newMessage = '';
    this.newTagsCsv = '';
    this.newScheduledAt = '';
    this.selectedAudience.set('all');
    this.scheduleOption.set('now');
    this.toggleCreateDialog(false);
  }

  duplicateBroadcast(b: Broadcast) {
    const nextId = (Math.max(0, ...this.broadcasts().map(x => Number(x.id))) + 1).toString();
    const copy: Broadcast = {
      ...b,
      id: nextId,
      name: `${b.name} (Copy)`,
      status: 'draft',
      scheduledAt: null,
      sentAt: null,
      delivered: 0,
      read: 0,
      clicked: 0,
      failed: 0
    };
    this.broadcasts.set([copy, ...this.broadcasts()]);
  }

  deleteBroadcast(id: string) {
    this.broadcasts.set(this.broadcasts().filter(b => b.id !== id));
  }

  private parseAudienceCount(value: string): number {
    // Try to infer count from predefined segments; fallback to a reasonable default
    const map: Record<string, number> = { all: 18750, active: 12500, new: 3200, vip: 850 };
    if (value in map) return map[value];
    return 0;
  }

  trackByBroadcastId(_: number, broadcast: Broadcast) {
    return broadcast.id;
  }

  getStatusConfig(status: Broadcast['status']) {
    return {
      sent: { label: 'Sent', class: 'badge badge-success', icon: CheckCircle },
      scheduled: { label: 'Scheduled', class: 'badge badge-primary', icon: Clock },
      draft: { label: 'Draft', class: 'badge badge-secondary', icon: Edit },
      failed: { label: 'Failed', class: 'badge badge-danger', icon: XCircle }
    }[status];
  }

  getDeliveryRate(broadcast: Broadcast): number {
    if (!broadcast.audienceSize) {
      return 0;
    }
    return Math.round((broadcast.delivered / broadcast.audienceSize) * 100);
  }

  getReadRate(broadcast: Broadcast): number {
    if (!broadcast.delivered) {
      return 0;
    }
    return Math.round((broadcast.read / broadcast.delivered) * 100);
  }

  getClickRate(broadcast: Broadcast): number {
    if (!broadcast.read) {
      return 0;
    }
    return Math.round((broadcast.clicked / broadcast.read) * 100);
  }

  formatDate(value: string | null): string {
    if (!value) {
      return '';
    }
    return new Date(value).toLocaleString();
  }

  readonly icons = {
    plus: Plus,
    search: Search,
    filter: Filter,
    users: Users,
    send: Send,
    check: CheckCircle,
    stats: BarChart3,
    calendar: Calendar,
    eye: Eye,
    edit: Edit,
    copy: Copy,
    delete: Trash2
  };
}
