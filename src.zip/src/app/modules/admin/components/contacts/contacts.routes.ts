import { Routes } from '@angular/router';
import { ContactsComponent } from 'app/modules/admin/components/contacts/contacts.component';

export default [
    {
        path: '',
        component: ContactsComponent,
    },
] as Routes;
