import { Routes } from '@angular/router';
import { TemplatesComponent } from 'app/modules/admin/components/templates/templates.component';

export default [
    {
        path: '',
        component: TemplatesComponent,
    },
] as Routes;
