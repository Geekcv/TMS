import { CommonModule, DatePipe } from '@angular/common';
import { Component, computed, signal, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { LucideAngularModule, Plus, FileText, MessageSquare, CheckCircle, Clock, XCircle, AlertCircle, Search, Eye, Copy, Edit, Trash2 } from 'lucide-angular';

interface TemplateButton {
  type: 'url' | 'phone' | 'quick_reply';
  text: string;
  url?: string;
  phone?: string;
}

interface MessageTemplate {
  id: number;
  name: string;
  category: string;
  language: string;
  status: 'APPROVED' | 'PENDING' | 'REJECTED';
  header: string;
  body: string;
  footer: string;
  buttons: TemplateButton[];
  created: string;
  lastUsed: string | null;
  usageCount: number;
}

interface NewTemplateForm {
  name: string;
  category: string;
  language: string;
  header: string;
  body: string;
  footer: string;
}

const TEMPLATES: MessageTemplate[] = [];

const LANGUAGES = [
  { value: 'en_US', label: 'English (US)' },
  { value: 'es_ES', label: 'Spanish (Spain)' },
  { value: 'fr_FR', label: 'French (France)' },
  { value: 'de_DE', label: 'German (Germany)' }
];

@Component({
  selector: 'app-templates',
  standalone: true,
  imports: [CommonModule, DatePipe, LucideAngularModule,
     CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatCardModule,
        MatTabsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatTableModule,
        MatChipsModule,
        MatDialogModule,
  ],
  templateUrl: './templates.component.html',
  styleUrls: ['./templates.component.css']
})
export class TemplatesComponent {
  readonly templates = signal<MessageTemplate[]>(TEMPLATES);
  readonly searchTerm = signal('');
  readonly selectedCategory = signal('all');
  readonly isCreateDialogOpen = signal(false);
  readonly previewTemplate = signal<MessageTemplate | null>(null);

    @ViewChild('addtemplateDialog') addContactDialogTpl!: TemplateRef<unknown>;
  
  readonly newTemplate = signal<NewTemplateForm>({
    name: '',
    category: '',
    language: 'en_US',
    header: '',
    body: '',
    footer: ''
  });

  readonly categories = computed(() => {
    const data = this.templates();
    return [
      { value: 'all', label: 'All Categories', count: data.length },
      { value: 'Utility', label: 'Utility', count: data.filter(t => t.category === 'Utility').length },
      { value: 'Marketing', label: 'Marketing', count: data.filter(t => t.category === 'Marketing').length },
      { value: 'Authentication', label: 'Authentication', count: data.filter(t => t.category === 'Authentication').length }
    ];
  });

  readonly filteredTemplates = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const category = this.selectedCategory();
    return this.templates().filter(template => {
      const matchesSearch = template.name.toLowerCase().includes(term);
      const matchesCategory = category === 'all' || template.category === category;
      return matchesSearch && matchesCategory;
    });
  });

  readonly stats = computed(() => {
    const data = this.templates();
    return {
      total: data.length,
      approved: data.filter(t => t.status === 'APPROVED').length,
      pending: data.filter(t => t.status === 'PENDING').length,
      usage: data.reduce((sum, template) => sum + template.usageCount, 0)
    };
  });

  readonly languageOptions = LANGUAGES;
  readonly templateVariableExample = '{{variable_name}}';

    addContactForm!: FormGroup;
  

    constructor(  
        private api: ApicontrollerService, 
        private _router: Router,
        private dialog: MatDialog,
        private fb: FormBuilder
    ) {
       this.fetchtemplates();

        this.addContactForm = this.fb.group({
  template_name: ['', Validators.required],
  header: [''],
  header_format: ['TEXT'], // default to TEXT
  sample_media_url: [''],
  messageBody: ['', Validators.required],
  footer: [''],
  category: ['', Validators.required],
  language:['']
});
       
    }

total:any;
APPROVED:any;
REJECTED:any;
PENDING:any;
displayedColumns = ['name', 'category', 'language', 'status','actions'];


 async fetchtemplates() {
  const resp = await this.api.fetchTemplates();
  console.log("Response from API →", resp);

  //  Summary
  this.total = resp.summary.total;
  this.APPROVED = resp.summary.APPROVED;
  this.REJECTED = resp.summary.REJECTED;
  this.PENDING = resp.summary.PENDING;

  //  Templates list for table
  if (resp.data && Array.isArray(resp.data)) {
    this.templates.set(
      resp.data.map((tpl: any) => ({
        id: tpl.id,
        name: tpl.name,
        category: tpl.category || '-',
        language: tpl.language || 'en_US',
        status: tpl.status || 'PENDING',
        header: tpl.components?.find((c: any) => c.type === 'HEADER')?.text || '',
        body: tpl.components?.find((c: any) => c.type === 'BODY')?.text || '',
        footer: tpl.components?.find((c: any) => c.type === 'FOOTER')?.text || '',
        buttons: tpl.components?.find((c: any) => c.type === 'BUTTONS')?.buttons || [],
        created: tpl.cr_on,
        lastUsed: tpl.up_on,
        usageCount: 0,
      }))
    );
  }
}





  getStatusConfig(status: MessageTemplate['status']) {
    return {
      APPROVED: { class: 'badge badge-success', icon: CheckCircle },
      PENDING: { class: 'badge badge-warning', icon: Clock },
      REJECTED: { class: 'badge badge-danger', icon: XCircle },
    }[status];
  }

  onSearch(value: string) {
    this.searchTerm.set(value);
  }

  onSelectCategory(value: string) {
    this.selectedCategory.set(value);
  }

  toggleCreateDialog(open: boolean) {
    this.isCreateDialogOpen.set(open);
  }

  updateNewTemplate<K extends keyof NewTemplateForm>(key: K, value: NewTemplateForm[K]) {
    this.newTemplate.update(current => ({ ...current, [key]: value }));
  }


  openPreview(t: MessageTemplate) {
    this.previewTemplate.set(t);
  }

  closePreview() {
    this.previewTemplate.set(null);
  }


  readonly icons = {
    plus: Plus,
    file: FileText,
    message: MessageSquare,
    approved: CheckCircle,
    pending: Clock,
    rejected: XCircle,
    draft: AlertCircle,
    search: Search,
    eye: Eye,
    copy: Copy,
    edit: Edit,       // ← added
    trash: Trash2     // ← added
  };
  

    openAddDialog(template: TemplateRef<unknown>) {
      this.dialog.open(template, { width: '560px' });
    }

    async handleAddTemplate() {
      const value = this.addContactForm.value;
      console.log("Template Form Value →", value);
    
      // Validate media URL if header type is not TEXT
      if (value.header_format !== 'TEXT' && !value.sample_media_url) {
        alert('Sample media URL is required for media headers.');
        return;
      }
    
      let resp;
    
      if (this.isEditMode && this.editingTemplateId) {
        // Call API to update template
        resp = await this.api.updateTemplates(value);
        console.log("Template updated →", resp);
            } else {
        // Call API to create template
        resp = await this.api.CreateTemplates(value);
        console.log("Template created →", resp);
      }
    
      // Reset form
      this.addContactForm.reset({ header_format: 'TEXT', language: 'en_US' });
      this.isEditMode = false;
      this.editingTemplateId = null;
    
      // Refresh list
      this.fetchtemplates();
      this.dialog.closeAll();
    }
    



addVariable() {
  const control = this.addContactForm.get('messageBody');
  if (!control) return;

  let currentValue = control.value || '';
  const matches = currentValue.match(/\{\{\d+\}\}/g) || [];
  const nextIndex = matches.length + 1;
  const appendText = (currentValue.endsWith(' ') || currentValue === '') 
    ? `{{${nextIndex}}}` 
    : ` {{${nextIndex}}}`;

  control.setValue(currentValue + appendText);
}

isEditMode = false;
editingTemplateId: number | null = null;

editTemplate(template: MessageTemplate) {
  console.log('Edit', template);

  // Open the same dialog used for "Add Template"
  const dialogRef = this.dialog.open(this.addContactDialogTpl, { width: '560px' });

  // Pre-fill the form with template data
  this.addContactForm.patchValue({
    template_name: template.name,
    header: template.header || '',
    header_format: template.header ? 'TEXT' : 'TEXT', // or handle IMAGE/VIDEO/DOCUMENT if needed
    sample_media_url: '', // set URL if media exists
    messageBody: template.body,
    footer: template.footer || '',
    category: template.category,
    language: template.language,
  });

  // Set a flag to indicate editing mode
  this.isEditMode = true;
  this.editingTemplateId = template.id;

  // Override the submit handler for this dialog
  dialogRef.afterClosed().subscribe(() => {
    this.isEditMode = false;
    this.editingTemplateId = null;
    this.addContactForm.reset({ header_format: 'TEXT', language: 'en_US' });
  });
}

deleteTemplate(template: any) {
  if (confirm(`Are you sure you want to delete template "${template.name}"?`)) {
    console.log('Delete', template);
    // Call API to delete template
  }
}


}
