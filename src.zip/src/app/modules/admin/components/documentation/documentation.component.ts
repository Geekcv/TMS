import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { LucideAngularModule, Book, Code, Video, ExternalLink, Download, Users, Zap, FileText } from 'lucide-angular';

@Component({
  selector: 'app-documentation',
  imports: [CommonModule, MatCardModule, MatButtonModule, LucideAngularModule],
  templateUrl: './documentation.component.html',
  styleUrl: './documentation.component.scss'
})
export class DocumentationComponent {
  readonly IconBook = Book;
  readonly IconCode = Code;
  readonly IconVideo = Video;
  readonly IconExternal = ExternalLink;
  readonly IconDownload = Download;
  readonly IconUsers = Users;
  readonly IconZap = Zap;
  readonly IconFile = FileText;

  nodeInstallCmd = 'npm install @whatsapp/cloud-api';
  pythonInstallCmd = 'pip install whatsapp-cloud-api';
  phpInstallCmd = 'composer require whatsapp/cloud-api';

  openLink(path: string) {
    console.log('Open link:', path);
  }

  download(sdk: 'node'|'python'|'php') {
    console.log('Download SDK:', sdk);
  }
}
