import { Component, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { MatMenuModule } from '@angular/material/menu';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { LucideAngularModule, Upload, Search, Download, Trash2, Eye, Copy, FileImage, FileVideo, FileAudio, FileText, File, MoreHorizontal } from 'lucide-angular';

type MediaType = 'image' | 'video' | 'audio' | 'document' | 'other';

interface MediaFile {
  id: string;
  name: string;
  type: MediaType;
  size: string; // e.g. "2.4 MB"
  dimensions?: string;
  duration?: string;
  pages?: number;
  uploadDate: string; // yyyy-mm-dd
  url: string;
  used: number;
  tags: string[];
}

@Component({
  selector: 'app-media-library',
  imports: [
     CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTabsModule,
    MatMenuModule,
    MatChipsModule,
    MatDialogModule,
    MatProgressBarModule,
    LucideAngularModule
  ],
  templateUrl: './media-library.component.html',
  styleUrl: './media-library.component.scss'
})
export class MediaLibraryComponent {
  // Icons
  readonly IconUpload = Upload;
  readonly IconSearch = Search;
  readonly IconDownload = Download;
  readonly IconTrash = Trash2;
  readonly IconEye = Eye;
  readonly IconCopy = Copy;
  readonly IconFileImage = FileImage;
  readonly IconFileVideo = FileVideo;
  readonly IconFileAudio = FileAudio;
  readonly IconFileText = FileText;
  readonly IconFile = File;
  readonly IconMore = MoreHorizontal;

  @ViewChild('previewDialog') previewDialogTpl!: TemplateRef<unknown>;

  tabIndex = 0;
  selectedTab: 'all' | 'image' | 'video' | 'audio' | 'document' = 'all';
  searchTerm = '';
  sortBy: 'newest' | 'oldest' | 'name' | 'size' | 'usage' = 'newest';
  selectedIds: string[] = [];

  isUploading = false;
  uploadProgress = 0;
  private _uploadTimer: any = null;

  previewFile: MediaFile | null = null;

  mediaFiles: MediaFile[] = [
    { id: '1', name: 'product-showcase.jpg', type: 'image', size: '2.4 MB', dimensions: '1920x1080', uploadDate: '2024-01-15', url: '/api/placeholder/300/200', used: 15, tags: ['product', 'showcase'] },
    { id: '2', name: 'welcome-video.mp4', type: 'video', size: '15.2 MB', duration: '00:02:30', uploadDate: '2024-01-14', url: '/api/placeholder/300/200', used: 8, tags: ['welcome', 'onboarding'] },
    { id: '3', name: 'notification-sound.mp3', type: 'audio', size: '1.1 MB', duration: '00:00:15', uploadDate: '2024-01-13', url: '', used: 22, tags: ['notification', 'sound'] },
    { id: '4', name: 'terms-and-conditions.pdf', type: 'document', size: '850 KB', pages: 12, uploadDate: '2024-01-12', url: '', used: 5, tags: ['legal', 'terms'] },
    { id: '5', name: 'product-catalog.pdf', type: 'document', size: '3.2 MB', pages: 24, uploadDate: '2024-01-10', url: '', used: 45, tags: ['catalog', 'products'] }
  ];

  get counts() {
    return {
      image: this.mediaFiles.filter(f => f.type === 'image').length,
      video: this.mediaFiles.filter(f => f.type === 'video').length,
      audio: this.mediaFiles.filter(f => f.type === 'audio').length,
      document: this.mediaFiles.filter(f => f.type === 'document').length
    };
  }

  onTabIndexChange(index: number) {
    this.tabIndex = index;
    this.selectedTab = ['all', 'image', 'video', 'audio', 'document'][index] as any;
  }

  get filteredFiles(): MediaFile[] {
    const term = this.searchTerm.trim().toLowerCase();
    const filtered = this.mediaFiles.filter(file => {
      const matchesSearch = !term || file.name.toLowerCase().includes(term) || file.tags.some(t => t.toLowerCase().includes(term));
      const matchesTab = this.selectedTab === 'all' || file.type === this.selectedTab;
      return matchesSearch && matchesTab;
    });
    return this.sortFiles(filtered);
  }

  private sortFiles(files: MediaFile[]): MediaFile[] {
    const byDate = (a: MediaFile, b: MediaFile) => new Date(a.uploadDate).getTime() - new Date(b.uploadDate).getTime();
    const byName = (a: MediaFile, b: MediaFile) => a.name.localeCompare(b.name);
    const bySize = (a: MediaFile, b: MediaFile) => this.sizeToBytes(a.size) - this.sizeToBytes(b.size);
    const byUsage = (a: MediaFile, b: MediaFile) => a.used - b.used;
    const arr = [...files];
    switch (this.sortBy) {
      case 'newest':
        return arr.sort((a, b) => byDate(b, a));
      case 'oldest':
        return arr.sort(byDate);
      case 'name':
        return arr.sort(byName);
      case 'size':
        return arr.sort(bySize).reverse();
      case 'usage':
        return arr.sort(byUsage).reverse();
      default:
        return arr;
    }
  }

  private sizeToBytes(size: string): number {
    const m = size.trim().match(/([\d.]+)\s*(KB|MB|GB|B)/i);
    if (!m) return 0;
    const value = parseFloat(m[1]);
    const unit = m[2].toUpperCase();
    const map: Record<string, number> = { B: 1, KB: 1024, MB: 1024 ** 2, GB: 1024 ** 3 };
    return value * (map[unit] || 1);
  }

  fileTypeClass(type: MediaType): string {
    switch (type) {
      case 'image': return 'badge image';
      case 'video': return 'badge video';
      case 'audio': return 'badge audio';
      case 'document': return 'badge document';
      default: return 'badge';
    }
  }

  getTypeIcon(type: MediaType) {
    switch (type) {
      case 'image': return this.IconFileImage;
      case 'video': return this.IconFileVideo;
      case 'audio': return this.IconFileAudio;
      case 'document': return this.IconFileText;
      default: return this.IconFile;
    }
  }

  isSelected(id: string): boolean {
    return this.selectedIds.includes(id);
  }

  toggleSelect(id: string) {
    if (this.isSelected(id)) {
      this.selectedIds = this.selectedIds.filter(x => x !== id);
    } else {
      this.selectedIds = [...this.selectedIds, id];
    }
  }

  downloadSelected() {
    const files = this.mediaFiles.filter(f => this.selectedIds.includes(f.id));
    console.log('Download selected', files.map(f => f.name));
  }

  deleteSelected() {
    const ids = new Set(this.selectedIds);
    this.mediaFiles = this.mediaFiles.filter(f => !ids.has(f.id));
    this.selectedIds = [];
  }

  deleteFile(id: string) {
    this.mediaFiles = this.mediaFiles.filter(f => f.id !== id);
    this.selectedIds = this.selectedIds.filter(x => x !== id);
  }

  openPreview(file: MediaFile) {
    this.previewFile = file;
    this.dialog.open(this.previewDialogTpl, { width: '640px' });
  }

  copyUrl(file: MediaFile) {
    if (!file?.url) return;
    try {
      // navigator.clipboard may not be available in all contexts
      (navigator as any).clipboard?.writeText(file.url);
      console.log('Copied URL to clipboard:', file.url);
    } catch {
      console.log('URL:', file.url);
    }
  }

  downloadFile(file: MediaFile) {
    console.log('Download file', file.name);
  }

  handleFileUpload(event: Event) {
    const input = event.target as HTMLInputElement;
    const files = Array.from(input.files ?? []);
    if (!files.length) return;
    this.isUploading = true;
    this.uploadProgress = 0;
    if (this._uploadTimer) {
      clearInterval(this._uploadTimer);
    }
    this._uploadTimer = setInterval(() => {
      this.uploadProgress += 10;
      if (this.uploadProgress >= 100) {
        clearInterval(this._uploadTimer);
        this.isUploading = false;
        this.uploadProgress = 0;
        // Demo: add the uploaded file names as placeholders
        const nextId = () => (Math.max(0, ...this.mediaFiles.map(f => Number(f.id))) + 1).toString();
        for (const f of files) {
          this.mediaFiles = [
            {
              id: nextId(),
              name: f.name,
              type: this.inferTypeFromName(f.name),
              size: this.humanSize(f.size),
              uploadDate: new Date().toISOString().slice(0, 10),
              url: '',
              used: 0,
              tags: []
            },
            ...this.mediaFiles
          ];
        }
      }
    }, 200);
  }

  private inferTypeFromName(name: string): MediaType {
    const ext = name.split('.').pop()?.toLowerCase();
    if (!ext) return 'other';
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext)) return 'image';
    if (['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(ext)) return 'video';
    if (['mp3', 'wav', 'ogg', 'm4a'].includes(ext)) return 'audio';
    if (['pdf', 'doc', 'docx', 'txt', 'rtf'].includes(ext)) return 'document';
    return 'other';
  }

  private humanSize(bytes: number): string {
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    let n = bytes;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(n < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
  }

  constructor(private dialog: MatDialog) {}
}