import { Routes } from '@angular/router';
import { FlowsComponent } from './flow.component';

export default [
    {
        path: '',
        component: FlowsComponent,
    },
] as Routes;
