import { Component, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LucideAngularModule, Plus, Search, Play, Pause, Edit, Copy, BarChart3, Users, MessageSquare, CheckCircle, XCircle, Clock, Zap, ArrowRight, Settings } from 'lucide-angular';

type FlowStatus = 'active' | 'paused' | 'draft' | 'error';
type FlowType = 'onboarding' | 'support' | 'survey' | 'commerce';

interface FlowStep { id: number; type: string; content: string; }
interface FlowItem {
  id: string;
  name: string;
  description: string;
  status: FlowStatus;
  type: FlowType;
  triggers: string[];
  completionRate: number; // 0-100
  totalSessions: number;
  averageTime: string; // mm:ss
  lastUpdated: string; // yyyy-mm-dd
  steps: FlowStep[];
}


@Component({
  selector: 'app-flow',
  imports: [
      CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDialogModule,
    LucideAngularModule
  ],
  templateUrl: './flow.component.html',
  styleUrl: './flow.component.scss'
})
export class FlowsComponent {
  // Icons
  readonly IconPlus = Plus;
  readonly IconSearch = Search;
  readonly IconPlay = Play;
  readonly IconPause = Pause;
  readonly IconEdit = Edit;
  readonly IconCopy = Copy;
  readonly IconBarChart3 = BarChart3;
  readonly IconUsers = Users;
  readonly IconMessageSquare = MessageSquare;
  readonly IconCheckCircle = CheckCircle;
  readonly IconXCircle = XCircle;
  readonly IconClock = Clock;
  readonly IconZap = Zap;
  readonly IconArrowRight = ArrowRight;
  readonly IconSettings = Settings;

  @ViewChild('createDialog') createDialogTpl!: TemplateRef<unknown>;

  searchTerm = '';
  selectedType: 'all' | FlowType = 'all';
  selectedStatus: 'all' | FlowStatus = 'all';

  // Create dialog model
  newFlow: { name: string; description: string; type: FlowType; active: boolean } = {
    name: '',
    description: '',
    type: 'onboarding',
    active: true
  };

  flowTypes: { value: FlowType; label: string; colorClass: string }[] = [
    { value: 'onboarding', label: 'Onboarding', colorClass: 'type onboarding' },
    { value: 'support', label: 'Support', colorClass: 'type support' },
    { value: 'survey', label: 'Survey', colorClass: 'type survey' },
    { value: 'commerce', label: 'Commerce', colorClass: 'type commerce' }
  ];

  flows: FlowItem[] = [
    {
      id: '1',
      name: 'Customer Onboarding',
      description: 'Welcome new customers and collect basic information',
      status: 'active',
      type: 'onboarding',
      triggers: ['keyword_hello', 'menu_option'],
      completionRate: 85,
      totalSessions: 1250,
      averageTime: '3:45',
      lastUpdated: '2024-01-15',
      steps: [
        { id: 1, type: 'message', content: "Welcome! Let's get you set up." },
        { id: 2, type: 'form', content: 'Please provide your name and email' },
        { id: 3, type: 'condition', content: 'Valid email?' },
        { id: 4, type: 'message', content: "Thank you! You're all set." }
      ]
    },
    {
      id: '2',
      name: 'Order Status Check',
      description: 'Allow customers to check their order status',
      status: 'active',
      type: 'support',
      triggers: ['keyword_order', 'menu_order_status'],
      completionRate: 92,
      totalSessions: 850,
      averageTime: '1:30',
      lastUpdated: '2024-01-14',
      steps: [
        { id: 1, type: 'message', content: 'Please provide your order number' },
        { id: 2, type: 'input', content: 'Order number input' },
        { id: 3, type: 'api', content: 'Fetch order details' },
        { id: 4, type: 'message', content: 'Display order status' }
      ]
    },
    {
      id: '3',
      name: 'Product Survey',
      description: 'Collect customer feedback on products',
      status: 'draft',
      type: 'survey',
      triggers: ['menu_feedback'],
      completionRate: 0,
      totalSessions: 0,
      averageTime: '0:00',
      lastUpdated: '2024-01-13',
      steps: [
        { id: 1, type: 'message', content: 'Help us improve our products!' },
        { id: 2, type: 'form', content: 'Rating and feedback form' },
        { id: 3, type: 'message', content: 'Thank you for your feedback!' }
      ]
    },
    {
      id: '4',
      name: 'Checkout Process',
      description: 'Complete purchase within WhatsApp',
      status: 'paused',
      type: 'commerce',
      triggers: ['menu_buy', 'button_checkout'],
      completionRate: 78,
      totalSessions: 420,
      averageTime: '5:20',
      lastUpdated: '2024-01-12',
      steps: [
        { id: 1, type: 'message', content: "Let's complete your purchase" },
        { id: 2, type: 'form', content: 'Shipping information' },
        { id: 3, type: 'payment', content: 'Payment processing' },
        { id: 4, type: 'message', content: 'Order confirmation' }
      ]
    }
  ];

  get stats() {
    return {
      totalFlows: this.flows.length,
      activeFlows: this.flows.filter(f => f.status === 'active').length,
      totalSessions: this.flows.reduce((sum, f) => sum + f.totalSessions, 0),
      avgCompletionRate: Math.round(this.flows.reduce((sum, f) => sum + f.completionRate, 0) / (this.flows.length || 1))
    };
  }

  get filteredFlows(): FlowItem[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.flows.filter(f => {
      const matchesSearch = !term || f.name.toLowerCase().includes(term) || f.description.toLowerCase().includes(term);
      const matchesType = this.selectedType === 'all' || f.type === this.selectedType;
      const matchesStatus = this.selectedStatus === 'all' || f.status === this.selectedStatus;
      return matchesSearch && matchesType && matchesStatus;
    });
  }

  typeLabel(type: FlowType): string {
    return this.flowTypes.find(t => t.value === type)?.label ?? type;
  }
  typeClass(type: FlowType): string {
    return this.flowTypes.find(t => t.value === type)?.colorClass ?? '';
  }
  statusClass(status: FlowStatus): string {
    return `badge ${status}`;
  }
  getTypeIcon(type: FlowType) {
    switch (type) {
      case 'onboarding': return this.IconUsers;
      case 'support': return this.IconMessageSquare;
      case 'survey': return this.IconBarChart3;
      case 'commerce': return this.IconCheckCircle;
    }
  }
  getStatusIcon(status: FlowStatus): string {
    switch (status) {
      case 'active': return '▶';
      case 'paused': return '⏸';
      case 'draft': return '⏱';
      default: return '✖';
    }
  }

  openCreateDialog(tpl: TemplateRef<unknown>) {
    this.dialog.open(tpl, { width: '560px' });
  }

  createFlow() {
    const name = this.newFlow.name.trim();
    if (!name) return;
    const newItem: FlowItem = {
      id: (Math.max(0, ...this.flows.map(f => Number(f.id))) + 1).toString(),
      name,
      description: this.newFlow.description.trim(),
      type: this.newFlow.type,
      status: this.newFlow.active ? 'active' : 'draft',
      triggers: [],
      completionRate: 0,
      totalSessions: 0,
      averageTime: '0:00',
      lastUpdated: new Date().toISOString().slice(0, 10),
      steps: [ { id: 1, type: 'message', content: 'New flow created' } ]
    };
    this.flows = [newItem, ...this.flows];
    this.newFlow = { name: '', description: '', type: 'onboarding', active: true };
    this.dialog.closeAll();
  }

  constructor(private dialog: MatDialog) {}
}