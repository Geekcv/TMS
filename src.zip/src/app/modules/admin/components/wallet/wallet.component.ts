import { Component, TemplateRef, ViewChild } from '@angular/core';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LucideAngularModule, CreditCard, DollarSign, TrendingUp, FileDown, RefreshCcw } from 'lucide-angular';


type TxnType = 'credit' | 'debit';
type TxnStatus = 'success' | 'pending' | 'failed';

interface TransactionItem {
  id: string;
  date: string; // ISO date
  description: string;
  amount: number; // positive for credits, negative for debits
  type: TxnType;
  status: TxnStatus;
}

interface InvoiceItem {
  id: string;
  period: string; // e.g., "Aug 2025"
  date: string;   // ISO date
  amount: number;
  status: 'paid' | 'due';
}

interface DailyCostItem {
  date: string; // ISO date
  messages: number;
  cost: number; // absolute positive value
}

@Component({
  selector: 'app-wallet',
  imports: [
     CommonModule,
    FormsModule,
    MatCardModule,
    MatTabsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatDialogModule,
    LucideAngularModule,
    CurrencyPipe,
    DatePipe
  ],
  templateUrl: './wallet.component.html',
  styleUrl: './wallet.component.scss'
})


export class WalletComponent {
  // Icons
  readonly IconCreditCard = CreditCard;
  readonly IconDollar = DollarSign;
  readonly IconTrendingUp = TrendingUp;
  readonly IconFileDown = FileDown;
  readonly IconRefresh = RefreshCcw;

  @ViewChild('rechargeTpl') rechargeTpl!: TemplateRef<unknown>;

  currencyCode = 'USD';
  balance = 2450.75;
  monthSpend = 312.4;
  monthMessages = 18420;

  get avgCostPerMessage() {
    const msgs = this.monthMessages || 1;
    return this.monthSpend / msgs;
  }

  dailyDisplayed = ['date', 'messages', 'cost'];
  txnDisplayed = ['date', 'description', 'amount', 'status'];
  invDisplayed = ['id', 'period', 'date', 'amount', 'status', 'actions'];

  dailyCosts: DailyCostItem[] = [
    { date: new Date().toISOString(), messages: 820, cost: 12.3 },
    { date: new Date(Date.now() - 864e5).toISOString(), messages: 1040, cost: 15.6 },
    { date: new Date(Date.now() - 2*864e5).toISOString(), messages: 920, cost: 13.8 },
    { date: new Date(Date.now() - 3*864e5).toISOString(), messages: 760, cost: 11.1 }
  ];

  transactions: TransactionItem[] = [
    { id: 't-1045', date: new Date().toISOString(), description: 'Messaging usage - Daily billing', amount: -15.6, type: 'debit', status: 'success' },
    { id: 't-1044', date: new Date(Date.now() - 864e5).toISOString(), description: 'Messaging usage - Daily billing', amount: -13.8, type: 'debit', status: 'success' },
    { id: 't-1043', date: new Date(Date.now() - 2*864e5).toISOString(), description: 'Wallet recharge', amount: 500.0, type: 'credit', status: 'success' },
    { id: 't-1042', date: new Date(Date.now() - 3*864e5).toISOString(), description: 'Messaging usage - Daily billing', amount: -11.1, type: 'debit', status: 'success' }
  ];

  invoices: InvoiceItem[] = [
    { id: 'INV-2025-08', period: 'Aug 2025', date: '2025-09-01', amount: 289.4, status: 'paid' },
    { id: 'INV-2025-07', period: 'Jul 2025', date: '2025-08-01', amount: 302.2, status: 'paid' },
    { id: 'INV-2025-06', period: 'Jun 2025', date: '2025-07-01', amount: 275.9, status: 'paid' }
  ];

  rechargeAmount = 100;
  paymentMethod: 'card' | 'bank' | 'upi' = 'card';

  constructor(private dialog: MatDialog) {}

  openRecharge(tpl: TemplateRef<unknown>) {
    this.dialog.open(tpl, { width: '520px' });
  }

  confirmRecharge() {
    const amt = Math.max(0, Number(this.rechargeAmount) || 0);
    if (!amt) return;
    // Simulate recharge success
    this.balance = Number((this.balance + amt).toFixed(2));
    this.transactions = [
      { id: 't-' + (1000 + Math.floor(Math.random()*9000)), date: new Date().toISOString(), description: 'Wallet recharge', amount: amt, type: 'credit', status: 'success' },
      ...this.transactions
    ];
    this.dialog.closeAll();
  }

  refreshBalance() {
    // Placeholder for API call
    console.log('Refreshing balance…');
  }

  downloadInvoice(inv: InvoiceItem) {
    // Placeholder for actual download; integrate with backend as needed
    console.log('Download invoice', inv.id);
  }
}