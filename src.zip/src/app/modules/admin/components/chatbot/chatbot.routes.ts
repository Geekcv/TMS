import { Routes } from '@angular/router';
import { ChatbotsComponent } from './chatbot.component';

export default [
    {
        path: '',
        component: ChatbotsComponent,
    },
] as Routes;
