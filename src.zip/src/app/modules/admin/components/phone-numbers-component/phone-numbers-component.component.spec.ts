import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PhoneNumbersComponentComponent } from './phone-numbers-component.component';

describe('PhoneNumbersComponentComponent', () => {
  let component: PhoneNumbersComponentComponent;
  let fixture: ComponentFixture<PhoneNumbersComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PhoneNumbersComponentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PhoneNumbersComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
