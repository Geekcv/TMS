import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-sign-up-organization',
  imports: [
      RouterLink,
        // FuseAlertComponent,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
  ],
  templateUrl: './sign-up-organization.component.html',
  styleUrl: './sign-up-organization.component.scss'
})

export class SignUpOrganizationComponent {
    @ViewChild('organizationNgForm') organizationNgForm: NgForm;

    organizationForm: UntypedFormGroup;

    signUpForm: UntypedFormGroup;
    showAlert: boolean = false;
    role: any = '';
    config: any;

    /**
     * Constructor
     */

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
    }

    private _snackBar = inject(MatSnackBar);

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        this.organizationForm = this._formBuilder.group({
            name: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            password: ['', Validators.required],
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign up
     */



    async addorganization(): Promise<void> {
        if (this.organizationForm.invalid) {
            this.organizationForm.markAllAsTouched();
            return;
        }

        const payload = {
            ...this.organizationForm.value,
        };

        const resp = await this.api.createOrgnization(payload);

        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });

            this.organizationNgForm.resetForm();
        this._router.navigate(['/sign-in'])

        } else {
            this._snackBar.open(resp.msg || 'Failed to add Orgnization', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }

  
}